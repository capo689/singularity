<?php
/**
 * Plugin Name: Singularity SEO
 * Plugin URI: https://singularity-mauve-phi.vercel.app/
 * Description: AI-managed SEO control plane for WordPress sites, including approved metadata, JSON-LD schema, robots controls, sitemap behavior, live audits, proposals and rollback.
 * Version: 3.0
 * Author: Agency689
 * Author URI: https://agency689.com/
 * Developer: Agency689
 * Developer URI: https://agency689.com/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: singularity-seo
 * Domain Path: /languages
 * WC requires at least: 8.0
 * WC tested up to: 10.0
 */

defined( 'ABSPATH' ) || exit;

define( 'SMSEO_VERSION', '3.0' );
define( 'SMSEO_PLUGIN_FILE', __FILE__ );
define( 'SMSEO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SMSEO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-registry.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-product-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-validation.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-campaign-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-context.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-title-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-meta-renderer.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-schema-renderer.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-robots-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-sitemap-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-robots-txt-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-cache-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-audit-service.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-takeover-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-metrics-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-health-scheduler.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-visibility-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-visibility-scheduler.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-report-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-api.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-admin.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-plugin.php';

add_action(
    'before_woocommerce_init',
    function() {
        if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
        }
    }
);

register_activation_hook( __FILE__, array( '\SMSEO\Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( '\SMSEO\Plugin', 'deactivate' ) );

add_action( 'plugins_loaded', array( '\SMSEO\Plugin', 'boot' ), 20 );
