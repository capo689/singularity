<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Registry {
    const OVERRIDES_OPTION = 'smseo_overrides';
    const MANAGED_PAGES_OPTION = 'smseo_managed_pages';

    private $pages = array();
    private $overrides = array();
    private $source = 'scan_first';

    public function __construct() {
        $stored_pages = get_option( self::MANAGED_PAGES_OPTION, array() );
        if ( is_array( $stored_pages ) && ! empty( $stored_pages ) ) {
            $this->pages = $this->sanitize_pages( $stored_pages );
            if ( $this->should_load_flagship_registry() ) {
                $flagship_pages = $this->sanitize_pages( $this->flagship_registry_pages() );
                $this->pages = $this->recover_flagship_customer_pages( $flagship_pages, $this->pages );
                update_option( self::MANAGED_PAGES_OPTION, $this->pages, false );
            }
            $this->source = 'customer_registry';
        } elseif ( $this->should_load_flagship_registry() ) {
            $this->pages = $this->flagship_registry_pages();
            $this->source = 'flagship_registry';
        } else {
            $this->pages = array();
            $this->source = 'scan_first';
        }

        $saved = get_option( self::OVERRIDES_OPTION, array() );
        $this->overrides = is_array( $saved ) ? $saved : array();
    }

    public function source() {
        return $this->source;
    }

    public function all() {
        return $this->pages;
    }

    public function keys() {
        return array_keys( $this->pages );
    }

    public function exists( $key ) {
        return isset( $this->pages[ $key ] );
    }

    public function get( $key ) {
        return isset( $this->pages[ $key ] ) ? $this->pages[ $key ] : null;
    }

    public function get_override( $key ) {
        return isset( $this->overrides[ $key ] ) && is_array( $this->overrides[ $key ] )
            ? $this->overrides[ $key ]
            : array();
    }

    public function get_by_path( $path ) {
        $path = $this->normalize_path( $path );

        foreach ( $this->pages as $key => $page ) {
            foreach ( $this->page_paths( $page ) as $page_path ) {
                if ( $page_path === $path ) {
                    $page['key'] = $key;
                    return $page;
                }
            }
        }

        return null;
    }

    public function key_for_post_id( $post_id ) {
        $post_id = (int) $post_id;
        if ( $post_id <= 0 ) {
            return '';
        }

        foreach ( $this->pages as $key => $page ) {
            if ( $this->resolve_post_id( $page ) === $post_id ) {
                return (string) $key;
            }
        }

        return '';
    }

    public function page_paths( $page ) {
        if ( ! is_array( $page ) ) {
            return array();
        }

        $raw_paths = array();

        if ( isset( $page['path'] ) && '' !== (string) $page['path'] ) {
            $raw_paths[] = $page['path'];
        }

        if ( isset( $page['path_aliases'] ) && is_array( $page['path_aliases'] ) ) {
            $raw_paths = array_merge( $raw_paths, $page['path_aliases'] );
        }

        $paths = array();
        foreach ( $raw_paths as $raw_path ) {
            $normalized = $this->normalize_path( $raw_path );
            if ( '' !== $normalized ) {
                $paths[] = $normalized;
            }
        }

        return array_values( array_unique( $paths ) );
    }

    public function get_effective( $key ) {
        $page = $this->get( $key );
        if ( ! is_array( $page ) ) {
            return null;
        }

        $page['key'] = $key;
        $page['_default_title'] = isset( $page['title'] ) ? (string) $page['title'] : '';
        $page['_default_description'] = isset( $page['description'] ) ? (string) $page['description'] : '';
        $override = $this->get_override( $key );

        foreach ( array( 'title', 'description', 'canonical' ) as $field ) {
            if ( isset( $override[ $field ] ) && '' !== $override[ $field ] ) {
                $page[ $field ] = $override[ $field ];
            }
        }

        foreach ( array( 'schema_json', 'schema_label' ) as $field ) {
            if ( isset( $override[ $field ] ) && '' !== $override[ $field ] ) {
                $page[ $field ] = $override[ $field ];
            }
        }

        if ( isset( $override['robots_preset'] ) && '' !== $override['robots_preset'] && 'default' !== $override['robots_preset'] ) {
            $page['robots_preset'] = $override['robots_preset'];
        }

        if ( isset( $page['og'] ) && is_array( $page['og'] ) ) {
            foreach ( array( 'title', 'description' ) as $field ) {
                $key_name = 'og_' . $field;
                if ( isset( $override[ $key_name ] ) && '' !== $override[ $key_name ] ) {
                    $page['og'][ $field ] = $override[ $key_name ];
                }
            }
        }

        if ( isset( $page['twitter'] ) && is_array( $page['twitter'] ) ) {
            foreach ( array( 'title', 'description' ) as $field ) {
                $key_name = 'twitter_' . $field;
                if ( isset( $override[ $key_name ] ) && '' !== $override[ $key_name ] ) {
                    $page['twitter'][ $field ] = $override[ $key_name ];
                }
            }
        }

        if ( isset( $page['campaign'] ) && is_array( $page['campaign'] ) ) {
            foreach (
                array(
                    'campaign_expires_on' => 'expires_on',
                    'campaign_active_description' => 'active_description',
                    'campaign_evergreen_description' => 'evergreen_description',
                    'campaign_active_hotel_description' => 'active_hotel_description',
                    'campaign_evergreen_hotel_description' => 'evergreen_hotel_description',
                ) as $override_key => $campaign_key
            ) {
                if ( isset( $override[ $override_key ] ) && '' !== $override[ $override_key ] ) {
                    $page['campaign'][ $campaign_key ] = $override[ $override_key ];
                }
            }
        }

        return $page;
    }

    public function update_overrides( $new_overrides ) {
        $clean = is_array( $new_overrides ) ? $new_overrides : array();
        update_option( self::OVERRIDES_OPTION, $clean, false );
        $this->overrides = $clean;
    }

    public function set_override( $key, $entry ) {
        if ( ! $this->exists( $key ) ) {
            return false;
        }

        $entry = is_array( $entry ) ? $entry : array();

        if ( empty( $entry ) ) {
            unset( $this->overrides[ $key ] );
        } else {
            $this->overrides[ $key ] = $entry;
        }

        update_option( self::OVERRIDES_OPTION, $this->overrides, false );
        return true;
    }

    public function reset_override( $key ) {
        if ( ! $this->exists( $key ) ) {
            return false;
        }

        unset( $this->overrides[ $key ] );
        update_option( self::OVERRIDES_OPTION, $this->overrides, false );
        return true;
    }

    public function reset_overrides() {
        delete_option( self::OVERRIDES_OPTION );
        $this->overrides = array();
    }

    public function replace_customer_pages_from_takeover_scan( $scan, $post_ids = array() ) {
        if ( ! is_array( $scan ) || empty( $scan['pages'] ) || ! is_array( $scan['pages'] ) ) {
            return 0;
        }

        $post_ids = array_values( array_unique( array_map( 'intval', is_array( $post_ids ) ? $post_ids : array() ) ) );
        $selected_lookup = array();
        foreach ( $post_ids as $post_id ) {
            if ( $post_id > 0 ) {
                $selected_lookup[ $post_id ] = true;
            }
        }

        $pages = array();
        foreach ( $scan['pages'] as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }

            $post_id = isset( $row['post_id'] ) ? (int) $row['post_id'] : 0;
            if ( ! empty( $selected_lookup ) && ( $post_id <= 0 || empty( $selected_lookup[ $post_id ] ) ) ) {
                continue;
            }

            $entry = $this->page_from_takeover_row( $row );
            if ( empty( $entry ) ) {
                continue;
            }

            $key = $this->page_key_from_row( $row, $entry, $pages );
            $pages[ $key ] = $entry;
        }

        $pages = $this->sanitize_pages( $pages );
        update_option( self::MANAGED_PAGES_OPTION, $pages, false );
        $this->pages = $pages;
        $this->source = ! empty( $pages ) ? 'customer_registry' : 'scan_first';

        return count( $pages );
    }

    public function merge_customer_pages_from_takeover_scan( $scan, $post_ids = array() ) {
        if ( ! is_array( $scan ) || empty( $scan['pages'] ) || ! is_array( $scan['pages'] ) ) {
            return 0;
        }

        $post_ids = array_values( array_unique( array_map( 'intval', is_array( $post_ids ) ? $post_ids : array() ) ) );
        $selected_lookup = array();
        foreach ( $post_ids as $post_id ) {
            if ( $post_id > 0 ) {
                $selected_lookup[ $post_id ] = true;
            }
        }

        $pages = $this->sanitize_pages( $this->pages );
        foreach ( $scan['pages'] as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }

            $post_id = isset( $row['post_id'] ) ? (int) $row['post_id'] : 0;
            if ( ! empty( $selected_lookup ) && ( $post_id <= 0 || empty( $selected_lookup[ $post_id ] ) ) ) {
                continue;
            }

            $entry = $this->page_from_takeover_row( $row );
            if ( empty( $entry ) ) {
                continue;
            }

            $entry['adopted_from_takeover'] = true;

            $existing_key = $this->find_existing_page_key( $pages, $entry );
            if ( '' !== $existing_key ) {
                continue;
            }

            $key = $this->page_key_from_row( $row, $entry, $pages );
            $pages[ $key ] = $entry;
        }

        $pages = $this->sanitize_pages( $pages );
        update_option( self::MANAGED_PAGES_OPTION, $pages, false );
        $this->pages = $pages;
        $this->source = ! empty( $pages ) ? 'customer_registry' : 'scan_first';

        return count( $pages );
    }

    public function normalize_path( $path ) {
        $path = is_string( $path ) ? $path : '/';
        $path = wp_parse_url( $path, PHP_URL_PATH ) ?: $path;
        $path = '/' . trim( $path, '/' );

        if ( '/' === $path ) {
            return '/';
        }

        return trailingslashit( $path );
    }

    public function resolve_post_id( $page ) {
        if ( ! is_array( $page ) ) {
            return 0;
        }

        if ( isset( $page['post_id'] ) && (int) $page['post_id'] > 0 ) {
            return (int) $page['post_id'];
        }

        foreach ( $this->page_paths( $page ) as $path ) {
            if ( '/' === $path ) {
                $front = (int) get_option( 'page_on_front' );
                if ( $front > 0 ) {
                    return $front;
                }
                continue;
            }

            $url = home_url( $path );
            $post_id = url_to_postid( $url );

            if ( $post_id ) {
                return (int) $post_id;
            }
        }

        return 0;
    }

    private function should_load_flagship_registry() {
        if ( function_exists( 'apply_filters' ) && (bool) apply_filters( 'smseo_enable_flagship_registry', false ) ) {
            return true;
        }

        if ( ! function_exists( 'home_url' ) || ! function_exists( 'wp_parse_url' ) ) {
            return false;
        }

        $host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
        $host = strtolower( $host );

        return '' !== $host && false !== strpos( $host, 'sunsetmarquis.com' );
    }

    private function flagship_registry_pages() {
        $pages = require SMSEO_PLUGIN_DIR . 'includes/config/seo-pages.php';
        return is_array( $pages ) ? $pages : array();
    }

    private function recover_flagship_customer_pages( $flagship_pages, $stored_pages ) {
        $pages = $this->sanitize_pages( $flagship_pages );
        $stored_pages = $this->sanitize_pages( $stored_pages );

        foreach ( $stored_pages as $key => $page ) {
            if ( ! is_array( $page ) ) {
                continue;
            }

            if ( '' !== $this->find_existing_page_key( $pages, $page ) ) {
                continue;
            }

            if ( ! $this->should_recover_flagship_customer_page( $page ) ) {
                continue;
            }

            $safe_key = sanitize_key( (string) $key );
            if ( '' === $safe_key || isset( $pages[ $safe_key ] ) ) {
                $safe_key = $this->page_key_from_row( array( 'post_id' => isset( $page['post_id'] ) ? (int) $page['post_id'] : 0 ), $page, $pages );
            }

            $pages[ $safe_key ] = $page;
        }

        return $this->sanitize_pages( $pages );
    }

    private function should_recover_flagship_customer_page( $page ) {
        if ( isset( $page['adopted_from_takeover'] ) && ! empty( $page['adopted_from_takeover'] ) ) {
            return true;
        }

        $approved_paths = array(
            '/west-hollywood-hotel-amenities/',
            '/west-hollywood-hotel-contact/',
            '/cavatina-restaurant/breakfast-in-hollywood/',
            '/cavatina-restaurant/brunch-west-hollywood/',
            '/cavatina-restaurant/dinner-west-hollywood/',
            '/cavatina-restaurant/cocktail-bars-hollywood/',
            '/cavatina-restaurant/chef-luis-morales/',
            '/cavatina-restaurant/dessert-in-west-hollywood/',
            '/events-rfp/',
            '/hotel-jobs-west-hollywood/',
            '/gifts/',
            '/about-west-hollywood-hotel/frequent-travelers/',
        );

        foreach ( $this->page_paths( $page ) as $path ) {
            if ( in_array( $path, $approved_paths, true ) ) {
                return true;
            }
        }

        return false;
    }

    private function find_existing_page_key( $pages, $entry ) {
        if ( ! is_array( $pages ) || ! is_array( $entry ) ) {
            return '';
        }

        $post_id = isset( $entry['post_id'] ) ? (int) $entry['post_id'] : 0;
        $paths = $this->page_paths( $entry );

        foreach ( $pages as $key => $page ) {
            if ( ! is_array( $page ) ) {
                continue;
            }

            if ( $post_id > 0 && isset( $page['post_id'] ) && (int) $page['post_id'] === $post_id ) {
                return (string) $key;
            }

            $existing_paths = $this->page_paths( $page );
            foreach ( $paths as $path ) {
                if ( in_array( $path, $existing_paths, true ) ) {
                    return (string) $key;
                }
            }
        }

        return '';
    }

    private function page_from_takeover_row( $row ) {
        $path = isset( $row['path'] ) ? $this->normalize_path( (string) $row['path'] ) : '';
        $url = isset( $row['url'] ) ? esc_url_raw( (string) $row['url'] ) : '';
        $post_id = isset( $row['post_id'] ) ? (int) $row['post_id'] : 0;

        if ( '' === $path && '' !== $url ) {
            $path = $this->normalize_path( $url );
        }
        if ( '' === $path ) {
            return array();
        }

        $title = isset( $row['title'] ) && '' !== (string) $row['title']
            ? sanitize_text_field( (string) $row['title'] )
            : ( isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : '' );
        $description = isset( $row['description'] ) ? sanitize_textarea_field( (string) $row['description'] ) : '';
        $canonical = isset( $row['canonical'] ) && '' !== (string) $row['canonical']
            ? esc_url_raw( (string) $row['canonical'] )
            : $url;

        $label = isset( $row['label'] ) && '' !== (string) $row['label']
            ? sanitize_text_field( (string) $row['label'] )
            : ( '' !== $title ? $title : $path );

        return array(
            'label'         => $label,
            'post_id'       => $post_id,
            'path'          => $path,
            'canonical'     => $canonical,
            'title'         => $title,
            'description'   => $description,
            'robots_preset' => 'index_follow',
            'og'            => array(
                'title'       => $title,
                'description' => $description,
                'image'       => '',
                'image_alt'   => '',
            ),
            'twitter'       => array(
                'card'        => 'summary_large_image',
                'title'       => $title,
                'description' => $description,
                'image'       => '',
                'image_alt'   => '',
            ),
        );
    }

    private function page_key_from_row( $row, $entry, $existing ) {
        if ( isset( $entry['path'] ) && '/' === $entry['path'] ) {
            return 'homepage';
        }

        $label = isset( $entry['label'] ) ? (string) $entry['label'] : '';
        $post_id = isset( $row['post_id'] ) ? (int) $row['post_id'] : 0;
        $base = sanitize_key( $label );
        if ( '' === $base && isset( $entry['path'] ) ) {
            $base = sanitize_key( trim( (string) $entry['path'], '/' ) );
        }
        if ( '' === $base && $post_id > 0 ) {
            $base = 'page_' . $post_id;
        }
        if ( '' === $base ) {
            $base = 'managed_page';
        }

        $key = $base;
        $index = 2;
        while ( isset( $existing[ $key ] ) ) {
            $key = $base . '_' . $index;
            $index++;
        }

        return $key;
    }

    private function sanitize_pages( $pages ) {
        $clean = array();
        foreach ( $pages as $key => $page ) {
            if ( ! is_array( $page ) ) {
                continue;
            }
            $key = sanitize_key( (string) $key );
            if ( '' === $key ) {
                continue;
            }
            $page['label'] = isset( $page['label'] ) ? sanitize_text_field( (string) $page['label'] ) : $key;
            $page['post_id'] = isset( $page['post_id'] ) ? (int) $page['post_id'] : 0;
            $page['path'] = isset( $page['path'] ) ? $this->normalize_path( (string) $page['path'] ) : '/';
            $page['canonical'] = isset( $page['canonical'] ) ? esc_url_raw( (string) $page['canonical'] ) : '';
            $page['title'] = isset( $page['title'] ) ? sanitize_text_field( (string) $page['title'] ) : '';
            $page['description'] = isset( $page['description'] ) ? sanitize_textarea_field( (string) $page['description'] ) : '';
            $page['robots_preset'] = isset( $page['robots_preset'] ) ? sanitize_key( (string) $page['robots_preset'] ) : 'index_follow';
            $page['schema_label'] = isset( $page['schema_label'] ) ? sanitize_text_field( (string) $page['schema_label'] ) : '';
            $page['schema_json'] = isset( $page['schema_json'] ) ? (string) $page['schema_json'] : '';
            $page['og'] = isset( $page['og'] ) && is_array( $page['og'] ) ? $page['og'] : array();
            $page['twitter'] = isset( $page['twitter'] ) && is_array( $page['twitter'] ) ? $page['twitter'] : array();
            $page['adopted_from_takeover'] = ! empty( $page['adopted_from_takeover'] );
            $clean[ $key ] = $page;
        }

        return $clean;
    }
}
