<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Visibility_Scheduler {
    const HOOK = 'smseo_daily_visibility_snapshot';
    const GSC_LAST_RUN_OPTION = 'smseo_daily_visibility_last_run';
    const GSC_LAST_ERROR_OPTION = 'smseo_daily_visibility_last_error';
    const RANK_LAST_RUN_OPTION = 'smseo_daily_rank_last_run';
    const RANK_LAST_ERROR_OPTION = 'smseo_daily_rank_last_error';
    const RANK_LAST_RESULT_OPTION = 'smseo_daily_rank_last_result';
    const LAST_RUN_OPTION = self::GSC_LAST_RUN_OPTION;
    const LAST_ERROR_OPTION = self::GSC_LAST_ERROR_OPTION;

    public function __construct() {
        add_action( self::HOOK, array( $this, 'run_scheduled_snapshot' ) );
        self::schedule();
    }

    public static function schedule() {
        if ( ! wp_next_scheduled( self::HOOK ) ) {
            wp_schedule_event( time() + ( 2 * HOUR_IN_SECONDS ), 'daily', self::HOOK );
        }
    }

    public static function unschedule() {
        $timestamp = wp_next_scheduled( self::HOOK );
        while ( $timestamp ) {
            wp_unschedule_event( $timestamp, self::HOOK );
            $timestamp = wp_next_scheduled( self::HOOK );
        }
    }

    public static function status() {
        $next_run = wp_next_scheduled( self::HOOK );
        $gsc_last_run = (string) get_option( self::GSC_LAST_RUN_OPTION, '' );
        $gsc_last_error = (string) get_option( self::GSC_LAST_ERROR_OPTION, '' );
        $rank_last_run = (string) get_option( self::RANK_LAST_RUN_OPTION, '' );
        $rank_last_error = (string) get_option( self::RANK_LAST_ERROR_OPTION, '' );
        $rank_last_result = get_option( self::RANK_LAST_RESULT_OPTION, array() );
        $rank_last_result = is_array( $rank_last_result ) ? $rank_last_result : array();

        return array(
            'enabled'      => (bool) $next_run,
            'schedule'     => 'daily',
            'next_run_gmt' => $next_run ? gmdate( 'Y-m-d H:i:s', $next_run ) : '',
            'last_run_gmt' => $gsc_last_run,
            'last_error'   => $gsc_last_error,
            'search_console' => array(
                'last_run_gmt' => $gsc_last_run,
                'last_error'   => $gsc_last_error,
            ),
            'rank_tracking' => array(
                'last_run_gmt' => $rank_last_run,
                'last_error'   => $rank_last_error,
                'last_result'  => $rank_last_result,
            ),
        );
    }

    public function run_scheduled_snapshot() {
        $visibility_store = new Visibility_Store();
        $gsc_refreshed = false;
        $rank_refreshed = false;

        try {
            $gsc_refreshed = $this->refresh_hosted_search_console();
            if ( $gsc_refreshed ) {
                update_option( self::GSC_LAST_RUN_OPTION, current_time( 'mysql', true ), false );
                delete_option( self::GSC_LAST_ERROR_OPTION );
            }
        } catch ( \Throwable $throwable ) {
            update_option( self::GSC_LAST_ERROR_OPTION, $throwable->getMessage(), false );
        }

        try {
            $rank_refreshed = $this->refresh_hosted_rankings();
            if ( $rank_refreshed ) {
                update_option( self::RANK_LAST_RUN_OPTION, current_time( 'mysql', true ), false );
                delete_option( self::RANK_LAST_ERROR_OPTION );
            }
        } catch ( \Throwable $throwable ) {
            update_option( self::RANK_LAST_ERROR_OPTION, $throwable->getMessage(), false );
        }

        if ( ! $gsc_refreshed && ! $rank_refreshed ) {
            $visibility_store->create_snapshot( 'daily_cron' );
        }
    }

    public function run_search_console_refresh_now() {
        try {
            $config = ( new Visibility_Store() )->get_config();
            if ( empty( $config['google_search_console_connected'] ) ) {
                throw new \RuntimeException( 'Search Console is not connected.' );
            }

            $refreshed = $this->refresh_hosted_search_console();
            if ( ! $refreshed ) {
                throw new \RuntimeException( 'Search Console refresh did not run. Confirm the hosted connection, customer ID and bridge token are configured.' );
            }

            update_option( self::GSC_LAST_RUN_OPTION, current_time( 'mysql', true ), false );
            delete_option( self::GSC_LAST_ERROR_OPTION );

            return array(
                'ok'      => true,
                'message' => 'Search Console refreshed successfully.',
                'status'  => self::status(),
            );
        } catch ( \Throwable $throwable ) {
            update_option( self::GSC_LAST_ERROR_OPTION, $throwable->getMessage(), false );

            return array(
                'ok'      => false,
                'message' => $throwable->getMessage(),
                'status'  => self::status(),
            );
        }
    }

    public function run_rank_refresh_now() {
        try {
            $config = ( new Visibility_Store() )->get_config();
            if ( empty( $config['rank_provider_connected'] ) ) {
                throw new \RuntimeException( 'Rank provider is not connected.' );
            }

            $refreshed = $this->refresh_hosted_rankings();
            if ( ! $refreshed ) {
                throw new \RuntimeException( 'Rank refresh did not run. Confirm the hosted connection, customer ID, bridge token, rank provider and tracked keywords are configured.' );
            }

            update_option( self::RANK_LAST_RUN_OPTION, current_time( 'mysql', true ), false );
            delete_option( self::RANK_LAST_ERROR_OPTION );

            $last_result = get_option( self::RANK_LAST_RESULT_OPTION, array() );
            $last_result = is_array( $last_result ) ? $last_result : array();
            $message = isset( $last_result['message'] ) && '' !== (string) $last_result['message']
                ? (string) $last_result['message']
                : 'Rank tracking refreshed successfully.';

            return array(
                'ok'      => true,
                'message' => $message,
                'status'  => self::status(),
                'result'  => $last_result,
            );
        } catch ( \Throwable $throwable ) {
            update_option( self::RANK_LAST_ERROR_OPTION, $throwable->getMessage(), false );

            return array(
                'ok'      => false,
                'message' => $throwable->getMessage(),
                'status'  => self::status(),
            );
        }
    }

    private function refresh_hosted_search_console() {
        $config = ( new Visibility_Store() )->get_config();
        if ( empty( $config['google_search_console_connected'] ) ) {
            return false;
        }

        $customer_id = sanitize_key( (string) get_option( Admin::CUSTOMER_ID_OPTION, '' ) );
        $controller_url = trim( (string) get_option( Admin::CONTROLLER_URL_OPTION, 'https://controller-nq6p.onrender.com/sse/' ) );
        $origin = $this->controller_origin( $controller_url );
        $token = trim( (string) get_option( API::BRIDGE_TOKEN_OPTION, '' ) );
        if ( '' === $customer_id || '' === $origin || strlen( $token ) < 24 ) {
            return false;
        }

        $site_url = home_url( '/' );
        $timestamp = (string) time();
        $message = $customer_id . '|' . $timestamp . '|' . $site_url;
        $response = wp_remote_post(
            $origin . '/integrations/google/search-console/refresh',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode(
                    array(
                        'customer_id' => $customer_id,
                        'site_url' => $site_url,
                        'ts' => $timestamp,
                        'signature' => hash_hmac( 'sha256', $message, $token ),
                    )
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            throw new \RuntimeException( 'Search Console refresh failed: ' . $response->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        if ( $code >= 400 ) {
            $detail = $this->response_error_detail( $response );
            throw new \RuntimeException( 'Search Console refresh returned HTTP ' . $code . ( '' !== $detail ? ': ' . $detail : '.' ) );
        }

        $body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        return is_array( $body ) && ! empty( $body['ok'] );
    }

    private function refresh_hosted_rankings() {
        $config = ( new Visibility_Store() )->get_config();
        if ( empty( $config['rank_provider_connected'] ) ) {
            return false;
        }

        $keywords = isset( $config['target_keywords'] ) && is_array( $config['target_keywords'] ) ? array_filter( $config['target_keywords'] ) : array();
        if ( empty( $keywords ) ) {
            return false;
        }

        $customer_id = sanitize_key( (string) get_option( Admin::CUSTOMER_ID_OPTION, '' ) );
        $controller_url = trim( (string) get_option( Admin::CONTROLLER_URL_OPTION, 'https://controller-nq6p.onrender.com/sse/' ) );
        $origin = $this->controller_origin( $controller_url );
        $token = trim( (string) get_option( API::BRIDGE_TOKEN_OPTION, '' ) );
        if ( '' === $customer_id || '' === $origin || strlen( $token ) < 24 ) {
            return false;
        }

        $site_url = home_url( '/' );
        $timestamp = (string) time();
        $message = $customer_id . '|' . $timestamp . '|' . $site_url;
        $response = wp_remote_post(
            $origin . '/integrations/rankings/refresh',
            array(
                'timeout' => 45,
                'headers' => array(
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode(
                    array(
                        'customer_id' => $customer_id,
                        'site_url' => $site_url,
                        'ts' => $timestamp,
                        'signature' => hash_hmac( 'sha256', $message, $token ),
                        'max_keywords' => Visibility_Store::STANDARD_KEYWORD_LIMIT,
                    )
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            throw new \RuntimeException( 'Rank refresh failed: ' . $response->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        if ( $code >= 400 ) {
            $detail = $this->response_error_detail( $response );
            throw new \RuntimeException( 'Rank refresh returned HTTP ' . $code . ( '' !== $detail ? ': ' . $detail : '.' ) );
        }

        $body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( is_array( $body ) ) {
            update_option(
                self::RANK_LAST_RESULT_OPTION,
                array(
                    'message' => isset( $body['message'] ) ? sanitize_text_field( (string) $body['message'] ) : '',
                    'searches_used' => isset( $body['searches_used'] ) ? (int) $body['searches_used'] : 0,
                    'keywords' => isset( $body['keywords'] ) && is_array( $body['keywords'] ) ? array_values( array_map( 'sanitize_text_field', $body['keywords'] ) ) : array(),
                    'quota' => isset( $body['quota'] ) && is_array( $body['quota'] ) ? $this->clean_scalar_map( $body['quota'] ) : array(),
                    'status' => isset( $body['status'] ) ? sanitize_key( (string) $body['status'] ) : '',
                ),
                false
            );
        }

        return is_array( $body ) && ! empty( $body['ok'] );
    }

    private function clean_scalar_map( $payload ) {
        $clean = array();
        foreach ( (array) $payload as $key => $value ) {
            if ( is_scalar( $value ) || null === $value ) {
                $clean[ sanitize_key( (string) $key ) ] = sanitize_text_field( (string) $value );
            }
        }

        return $clean;
    }

    private function response_error_detail( $response ) {
        $body = (string) wp_remote_retrieve_body( $response );
        if ( '' === trim( $body ) ) {
            return '';
        }

        $decoded = json_decode( $body, true );
        if ( is_array( $decoded ) ) {
            foreach ( array( 'message', 'error_description', 'error' ) as $key ) {
                if ( ! empty( $decoded[ $key ] ) && is_scalar( $decoded[ $key ] ) ) {
                    return $this->clean_error_detail( (string) $decoded[ $key ] );
                }
            }
        }

        return $this->clean_error_detail( $body );
    }

    private function clean_error_detail( $message ) {
        $message = wp_strip_all_tags( (string) $message );
        $message = preg_replace( '/\s+/', ' ', $message );
        $message = trim( $message );

        if ( strlen( $message ) > 500 ) {
            $message = substr( $message, 0, 497 ) . '...';
        }

        return $message;
    }

    private function controller_origin( $controller_url ) {
        $parts = wp_parse_url( (string) $controller_url );
        if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
            return '';
        }

        $port = isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '';
        return $parts['scheme'] . '://' . $parts['host'] . $port;
    }
}
