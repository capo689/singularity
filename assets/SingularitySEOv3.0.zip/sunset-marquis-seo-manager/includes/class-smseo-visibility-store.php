<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Visibility_Store {
    const SNAPSHOTS_OPTION = 'smseo_visibility_snapshots';
    const CONFIG_OPTION = 'smseo_visibility_config';
    const MAX_SNAPSHOTS = 90;
    const STANDARD_KEYWORD_LIMIT = 3;

    public function get_metrics() {
        $snapshots = $this->get_snapshots();
        $baseline = ! empty( $snapshots ) ? reset( $snapshots ) : null;
        $current = ! empty( $snapshots ) ? end( $snapshots ) : null;
        $effective_current = is_array( $current ) ? $current : null;
        if ( is_array( $effective_current ) ) {
            $latest_search_console = $this->latest_search_console( $snapshots );
            if ( ! empty( $latest_search_console ) ) {
                $effective_current['search_console'] = $latest_search_console;
            }
            $latest_rankings = $this->latest_rankings( $snapshots );
            if ( ! empty( $latest_rankings ) ) {
                $effective_current['rankings'] = $latest_rankings;
            }
        }

        $providers = $this->provider_status();

        return array(
            'baseline'       => $baseline,
            'current'        => $effective_current,
            'latest_snapshot' => $current,
            'snapshot_count' => count( $snapshots ),
            'history'        => $this->history_points( $snapshots ),
            'deltas'         => $this->deltas( $baseline, $effective_current ),
            'goals'          => $this->goals( $baseline, $effective_current ),
            'providers'      => $providers,
            'config'         => $this->public_config(),
            'data_state'     => $this->data_state( $effective_current, $providers ),
            'automation'     => class_exists( '\SMSEO\Visibility_Scheduler' ) ? Visibility_Scheduler::status() : array(),
        );
    }

    public function create_snapshot( $source = 'manual', $payload = array() ) {
        $config = $this->get_config();
        $providers = $this->provider_status();
        $has_provider = ! empty( $providers['google_search_console']['connected'] ) || ! empty( $providers['rank_provider']['connected'] );
        $now = current_time( 'mysql', true );
        $search_console = $this->search_console_payload( isset( $payload['search_console'] ) ? $payload['search_console'] : array() );
        $rankings = $this->rankings_payload( isset( $payload['rankings'] ) ? $payload['rankings'] : array(), $config );
        $status = isset( $payload['status'] ) ? sanitize_key( (string) $payload['status'] ) : '';
        if ( '' === $status ) {
            $status = $this->has_visibility_data( $search_console, $rankings )
                ? 'ingested'
                : ( $has_provider ? 'ready_for_ingestion' : 'provider_not_connected' );
        }

        $snapshot = array(
            'id'             => 'visibility_' . gmdate( 'YmdHis' ),
            'captured_at'    => $now,
            'source'         => sanitize_key( (string) $source ),
            'status'         => $status,
            'cadence'        => $this->cadence_for_plan( $config ),
            'property_url'   => isset( $config['google_search_console_property_url'] ) ? (string) $config['google_search_console_property_url'] : '',
            'keyword_count'  => count( $this->target_keywords( $config ) ),
            'search_console' => $search_console,
            'rankings'       => $rankings,
            'message'        => isset( $payload['message'] ) && '' !== trim( (string) $payload['message'] )
                ? sanitize_textarea_field( (string) $payload['message'] )
                : $this->snapshot_message( $status, $has_provider ),
        );

        $snapshots = $this->get_snapshots();
        $snapshots[] = $snapshot;
        if ( count( $snapshots ) > self::MAX_SNAPSHOTS ) {
            $snapshots = array_slice( $snapshots, -1 * self::MAX_SNAPSHOTS );
        }
        update_option( self::SNAPSHOTS_OPTION, $snapshots, false );

        return $snapshot;
    }

    public function update_config( $payload ) {
        $current = $this->get_config();
        $next = $current;

        if ( array_key_exists( 'plan', (array) $payload ) ) {
            $plan = sanitize_key( (string) $payload['plan'] );
            $next['plan'] = in_array( $plan, array( 'standard', 'enterprise' ), true ) ? $plan : 'standard';
        }

        if ( array_key_exists( 'google_search_console_property_url', (array) $payload ) ) {
            $property_url = Validation::sanitize_search_console_property( (string) $payload['google_search_console_property_url'] );
            $next['google_search_console_property_url'] = false === $property_url ? '' : $property_url;
        }

        if ( array_key_exists( 'google_search_console_connected', (array) $payload ) ) {
            $next['google_search_console_connected'] = (bool) $payload['google_search_console_connected'];
        }

        if ( array_key_exists( 'rank_provider', (array) $payload ) ) {
            $next['rank_provider'] = sanitize_text_field( (string) $payload['rank_provider'] );
        }

        if ( array_key_exists( 'ranking_target_domain', (array) $payload ) ) {
            $next['ranking_target_domain'] = $this->clean_domain( (string) $payload['ranking_target_domain'] );
        }

        if ( array_key_exists( 'rank_provider_connected', (array) $payload ) ) {
            $next['rank_provider_connected'] = (bool) $payload['rank_provider_connected'];
        }

        if ( array_key_exists( 'target_keywords', (array) $payload ) ) {
            $next['target_keywords'] = $this->clean_keywords( $payload['target_keywords'] );
        }

        update_option( self::CONFIG_OPTION, $next, false );

        return $this->public_config();
    }

    public function get_snapshots() {
        $snapshots = get_option( self::SNAPSHOTS_OPTION, array() );
        return is_array( $snapshots ) ? array_values( $snapshots ) : array();
    }

    public function get_config() {
        $config = get_option( self::CONFIG_OPTION, array() );
        $config = is_array( $config ) ? $config : array();

        return array_merge(
            array(
                'plan'                               => 'standard',
                'google_search_console_property_url' => '',
                'google_search_console_connected'    => false,
                'rank_provider'                      => '',
                'ranking_target_domain'              => $this->clean_domain( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ),
                'rank_provider_connected'            => false,
                'target_keywords'                    => array( $this->starter_keyword() ),
            ),
            $config
        );
    }

    private function public_config() {
        $config = $this->get_config();
        unset( $config['google_access_token'], $config['google_refresh_token'], $config['rank_provider_api_key'] );
        $config['target_keywords'] = $this->target_keywords( $config );
        $config['cadence'] = $this->cadence_for_plan( $config );

        return $config;
    }

    private function provider_status() {
        $config = $this->get_config();

        return array(
            'google_search_console' => array(
                'connected'    => ! empty( $config['google_search_console_connected'] ),
                'property_url' => isset( $config['google_search_console_property_url'] ) ? (string) $config['google_search_console_property_url'] : '',
                'cadence'      => $this->cadence_for_plan( $config ),
            ),
            'rank_provider'         => array(
                'connected' => ! empty( $config['rank_provider_connected'] ),
                'provider'  => isset( $config['rank_provider'] ) ? (string) $config['rank_provider'] : '',
                'target_domain' => isset( $config['ranking_target_domain'] ) ? (string) $config['ranking_target_domain'] : '',
                'cadence'   => $this->cadence_for_plan( $config ),
            ),
        );
    }

    private function cadence_for_plan( $config ) {
        $plan = isset( $config['plan'] ) ? sanitize_key( (string) $config['plan'] ) : 'standard';
        if ( 'enterprise' === $plan ) {
            return array(
                'frequency' => 'twice_daily',
                'max_runs_per_day' => 2,
            );
        }

        return array(
            'frequency' => 'daily',
            'max_runs_per_day' => 1,
        );
    }

    private function target_keywords( $config ) {
        $keywords = isset( $config['target_keywords'] ) && is_array( $config['target_keywords'] )
            ? array_values( $config['target_keywords'] )
            : array();
        $keywords = array_values( array_filter( $keywords ) );
        if ( empty( $keywords ) ) {
            $keywords[] = $this->starter_keyword();
        }

        return array_slice( $keywords, 0, self::STANDARD_KEYWORD_LIMIT );
    }

    private function clean_keywords( $keywords ) {
        $clean = array();
        foreach ( (array) $keywords as $keyword ) {
            $keyword = trim( sanitize_text_field( (string) $keyword ) );
            if ( '' !== $keyword ) {
                $clean[] = $keyword;
            }
        }

        $clean = array_values( array_unique( $clean ) );
        if ( empty( $clean ) ) {
            $clean[] = $this->starter_keyword();
        }

        return array_slice( $clean, 0, self::STANDARD_KEYWORD_LIMIT );
    }

    private function latest_search_console( $snapshots ) {
        $snapshots = is_array( $snapshots ) ? array_reverse( $snapshots ) : array();
        foreach ( $snapshots as $snapshot ) {
            if ( ! is_array( $snapshot ) || empty( $snapshot['search_console'] ) || ! is_array( $snapshot['search_console'] ) ) {
                continue;
            }
            $search_console = $snapshot['search_console'];
            $has_rows = null !== ( isset( $search_console['clicks'] ) ? $search_console['clicks'] : null )
                || null !== ( isset( $search_console['impressions'] ) ? $search_console['impressions'] : null )
                || null !== ( isset( $search_console['average_position'] ) ? $search_console['average_position'] : null );
            if ( ! $has_rows ) {
                continue;
            }
            $search_console['snapshot_id'] = isset( $snapshot['id'] ) ? (string) $snapshot['id'] : '';
            $search_console['captured_at'] = isset( $snapshot['captured_at'] ) ? (string) $snapshot['captured_at'] : '';
            return $search_console;
        }

        return array();
    }

    private function latest_rankings( $snapshots ) {
        $snapshots = is_array( $snapshots ) ? array_reverse( $snapshots ) : array();
        $target_keywords = $this->target_keywords( $this->get_config() );
        $target_keys = array();
        foreach ( $target_keywords as $keyword ) {
            $target_keys[] = strtolower( trim( (string) $keyword ) );
        }

        $latest_payload = array();
        $latest_rows = array();

        foreach ( $snapshots as $snapshot ) {
            if ( ! is_array( $snapshot ) || empty( $snapshot['rankings'] ) || ! is_array( $snapshot['rankings'] ) ) {
                continue;
            }
            $rankings = $snapshot['rankings'];
            $has_rows = null !== ( isset( $rankings['average_rank'] ) ? $rankings['average_rank'] : null )
                || ! empty( $rankings['keywords'] );
            if ( ! $has_rows ) {
                continue;
            }

            if ( empty( $latest_payload ) ) {
                $latest_payload = $rankings;
                $latest_payload['snapshot_id'] = isset( $snapshot['id'] ) ? (string) $snapshot['id'] : '';
                $latest_payload['captured_at'] = isset( $snapshot['captured_at'] ) ? (string) $snapshot['captured_at'] : '';
            }

            if ( empty( $rankings['keywords'] ) || ! is_array( $rankings['keywords'] ) ) {
                continue;
            }

            foreach ( $rankings['keywords'] as $row ) {
                if ( ! is_array( $row ) || empty( $row['keyword'] ) ) {
                    continue;
                }
                $keyword_key = strtolower( trim( (string) $row['keyword'] ) );
                if ( '' === $keyword_key || isset( $latest_rows[ $keyword_key ] ) ) {
                    continue;
                }
                if ( ! empty( $target_keys ) && ! in_array( $keyword_key, $target_keys, true ) ) {
                    continue;
                }
                $row['snapshot_id'] = isset( $snapshot['id'] ) ? (string) $snapshot['id'] : '';
                $row['captured_at'] = isset( $snapshot['captured_at'] ) ? (string) $snapshot['captured_at'] : '';
                if ( ! isset( $row['checked_depth'] ) || null === $row['checked_depth'] ) {
                    $row['checked_depth'] = isset( $rankings['result_depth'] ) ? $rankings['result_depth'] : null;
                }
                $latest_rows[ $keyword_key ] = $row;
            }

            if ( ! empty( $target_keys ) && count( $latest_rows ) >= count( $target_keys ) ) {
                break;
            }
        }

        if ( empty( $latest_payload ) ) {
            return array();
        }

        $ordered_rows = array();
        foreach ( $target_keys as $keyword_key ) {
            if ( isset( $latest_rows[ $keyword_key ] ) ) {
                $ordered_rows[] = $latest_rows[ $keyword_key ];
            }
        }
        if ( empty( $ordered_rows ) && ! empty( $latest_rows ) ) {
            $ordered_rows = array_values( $latest_rows );
        }

        $latest_payload['tracked_keywords'] = count( $target_keywords );
        $latest_payload['keywords'] = $ordered_rows;
        $rank_total = 0;
        $rank_count = 0;
        foreach ( $ordered_rows as $row ) {
            if ( isset( $row['rank'] ) && null !== $row['rank'] ) {
                $rank_total += (float) $row['rank'];
                $rank_count++;
            }
        }
        $latest_payload['average_rank'] = $rank_count > 0 ? round( $rank_total / $rank_count, 2 ) : null;

        return $latest_payload;
    }

    private function starter_keyword() {
        $name = strtolower( trim( wp_strip_all_tags( (string) get_bloginfo( 'name' ) ) ) );
        $name = preg_replace( '/[^a-z0-9\\s-]+/', ' ', $name );
        $name = preg_replace( '/\\s+/', ' ', (string) $name );
        $name = trim( (string) $name );
        if ( '' !== $name ) {
            return $name;
        }

        $host = $this->clean_domain( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
        return '' !== $host ? $host : 'primary website keyword';
    }

    private function clean_domain( $domain ) {
        $domain = strtolower( trim( (string) $domain ) );
        if ( '' === $domain ) {
            return '';
        }

        $host = wp_parse_url( false === strpos( $domain, '://' ) ? 'https://' . $domain : $domain, PHP_URL_HOST );
        $host = strtolower( trim( (string) $host, ". \t\n\r\0\x0B" ) );
        if ( 0 === strpos( $host, 'www.' ) ) {
            $host = substr( $host, 4 );
        }

        return preg_match( '/^[a-z0-9.-]+\.[a-z]{2,}$/', $host ) ? $host : '';
    }

    private function search_console_payload( $payload ) {
        $payload = is_array( $payload ) ? $payload : array();
        $clicks = $this->nullable_number( isset( $payload['clicks'] ) ? $payload['clicks'] : null );
        $impressions = $this->nullable_number( isset( $payload['impressions'] ) ? $payload['impressions'] : null );
        $ctr = $this->nullable_number( isset( $payload['ctr'] ) ? $payload['ctr'] : null );
        if ( null === $ctr && null !== $clicks && null !== $impressions && $impressions > 0 ) {
            $ctr = round( $clicks / $impressions, 4 );
        }

        return array(
            'clicks'           => $clicks,
            'impressions'      => $impressions,
            'ctr'              => $ctr,
            'average_position' => $this->nullable_number( isset( $payload['average_position'] ) ? $payload['average_position'] : null ),
        );
    }

    private function rankings_payload( $payload, $config ) {
        $payload = is_array( $payload ) ? $payload : array();
        $keywords = isset( $payload['keywords'] ) && is_array( $payload['keywords'] ) ? $this->ranking_keywords( $payload['keywords'] ) : array();
        $average_rank = $this->nullable_number( isset( $payload['average_rank'] ) ? $payload['average_rank'] : null );
        if ( null === $average_rank && ! empty( $keywords ) ) {
            $rank_total = 0;
            $rank_count = 0;
            foreach ( $keywords as $keyword ) {
                if ( null !== $keyword['rank'] ) {
                    $rank_total += $keyword['rank'];
                    $rank_count++;
                }
            }
            $average_rank = $rank_count > 0 ? round( $rank_total / $rank_count, 2 ) : null;
        }

        return array(
            'tracked_keywords' => count( $this->target_keywords( $config ) ),
            'average_rank'     => $average_rank,
            'result_depth'     => $this->nullable_number( isset( $payload['result_depth'] ) ? $payload['result_depth'] : null ),
            'provider'         => isset( $payload['provider'] ) ? sanitize_text_field( (string) $payload['provider'] ) : '',
            'target_domain'    => isset( $payload['target_domain'] ) ? $this->clean_domain( (string) $payload['target_domain'] ) : '',
            'keywords'         => $keywords,
            'gainers'          => isset( $payload['gainers'] ) && is_array( $payload['gainers'] ) ? $this->clean_keywords( $payload['gainers'] ) : array(),
            'decliners'        => isset( $payload['decliners'] ) && is_array( $payload['decliners'] ) ? $this->clean_keywords( $payload['decliners'] ) : array(),
        );
    }

    private function ranking_keywords( $keywords ) {
        $clean = array();
        foreach ( $keywords as $keyword ) {
            if ( ! is_array( $keyword ) ) {
                continue;
            }
            $query = isset( $keyword['keyword'] ) ? trim( sanitize_text_field( (string) $keyword['keyword'] ) ) : '';
            if ( '' === $query ) {
                continue;
            }
            $clean[] = array(
                'keyword'       => $query,
                'rank'          => $this->nullable_number( isset( $keyword['rank'] ) ? $keyword['rank'] : null ),
                'previous_rank' => $this->nullable_number( isset( $keyword['previous_rank'] ) ? $keyword['previous_rank'] : null ),
                'url'           => $this->clean_ranking_url( isset( $keyword['url'] ) ? (string) $keyword['url'] : '' ),
                'status'        => isset( $keyword['status'] ) ? sanitize_key( (string) $keyword['status'] ) : '',
                'checked_depth' => $this->nullable_number( isset( $keyword['checked_depth'] ) ? $keyword['checked_depth'] : null ),
                'result_count'  => $this->nullable_number( isset( $keyword['result_count'] ) ? $keyword['result_count'] : null ),
                'message'       => isset( $keyword['message'] ) ? sanitize_text_field( (string) $keyword['message'] ) : '',
            );
        }

        return $clean;
    }

    private function clean_ranking_url( $url ) {
        $clean = Validation::sanitize_absolute_http_url( $url );
        return false === $clean ? '' : $clean;
    }

    private function nullable_number( $value ) {
        if ( null === $value || '' === $value ) {
            return null;
        }
        if ( ! is_numeric( $value ) ) {
            return null;
        }

        return 0 + $value;
    }

    private function has_visibility_data( $search_console, $rankings ) {
        return null !== $search_console['clicks']
            || null !== $search_console['impressions']
            || null !== $search_console['average_position']
            || null !== $rankings['average_rank']
            || ! empty( $rankings['keywords'] );
    }

    private function snapshot_message( $status, $has_provider ) {
        if ( 'ingested' === $status ) {
            return 'Visibility data ingested and stored.';
        }

        return $has_provider
            ? 'Visibility providers are configured; ingestion adapter is ready.'
            : 'Connect Google Search Console and a rank provider to begin daily visibility updates.';
    }

    private function data_state( $current, $providers ) {
        $current = is_array( $current ) ? $current : array();
        $search = isset( $current['search_console'] ) && is_array( $current['search_console'] ) ? $current['search_console'] : array();
        $rankings = isset( $current['rankings'] ) && is_array( $current['rankings'] ) ? $current['rankings'] : array();
        $gsc_connected = ! empty( $providers['google_search_console']['connected'] );
        $rank_connected = ! empty( $providers['rank_provider']['connected'] );
        $has_gsc_rows = null !== ( isset( $search['clicks'] ) ? $search['clicks'] : null )
            || null !== ( isset( $search['impressions'] ) ? $search['impressions'] : null )
            || null !== ( isset( $search['average_position'] ) ? $search['average_position'] : null );
        $has_rank_rows = null !== ( isset( $rankings['average_rank'] ) ? $rankings['average_rank'] : null )
            || ! empty( $rankings['keywords'] );

        return array(
            'google_search_console' => array(
                'state'   => $gsc_connected ? ( $has_gsc_rows ? 'measured' : 'connected_no_rows_yet' ) : 'not_connected',
                'message' => $gsc_connected
                    ? ( $has_gsc_rows ? 'Search Console rows are available.' : 'Search Console is connected; Google has not returned measurable rows for this property/window yet.' )
                    : 'Google Search Console is not connected.',
            ),
            'rank_provider'         => array(
                'state'   => $rank_connected ? ( $has_rank_rows ? 'measured' : 'connected_no_rank_rows_yet' ) : 'not_connected',
                'message' => $rank_connected
                    ? ( $has_rank_rows ? 'Rank rows are available.' : 'Rank provider is connected; no measured rank rows are stored for the current snapshot yet.' )
                    : 'Rank provider is not connected.',
            ),
        );
    }

    private function deltas( $baseline, $current ) {
        if ( ! is_array( $baseline ) || ! is_array( $current ) ) {
            return array();
        }

        return array(
            'clicks'           => $this->delta_value( $baseline, $current, array( 'search_console', 'clicks' ) ),
            'impressions'      => $this->delta_value( $baseline, $current, array( 'search_console', 'impressions' ) ),
            'average_position' => $this->delta_value( $baseline, $current, array( 'search_console', 'average_position' ) ),
            'average_rank'     => $this->delta_value( $baseline, $current, array( 'rankings', 'average_rank' ) ),
        );
    }

    private function goals( $baseline, $current ) {
        $deltas = $this->deltas( $baseline, $current );

        return array(
            'traffic_trend' => isset( $deltas['clicks']['delta'] ) && null !== $deltas['clicks']['delta'] ? $this->trend_label( $deltas['clicks']['delta'], false ) : 'pending',
            'ranking_trend' => isset( $deltas['average_rank']['delta'] ) && null !== $deltas['average_rank']['delta'] ? $this->trend_label( $deltas['average_rank']['delta'], true ) : 'pending',
        );
    }

    private function delta_value( $baseline, $current, $path ) {
        $base = $this->nested_value( $baseline, $path );
        $now = $this->nested_value( $current, $path );
        if ( null === $base || null === $now ) {
            return array(
                'baseline' => $base,
                'current'  => $now,
                'delta'    => null,
            );
        }

        return array(
            'baseline' => $base,
            'current'  => $now,
            'delta'    => round( $now - $base, 4 ),
        );
    }

    private function nested_value( $payload, $path ) {
        $value = $payload;
        foreach ( $path as $key ) {
            if ( ! is_array( $value ) || ! array_key_exists( $key, $value ) ) {
                return null;
            }
            $value = $value[ $key ];
        }

        return is_numeric( $value ) ? 0 + $value : null;
    }

    private function trend_label( $delta, $lower_is_better ) {
        if ( 0 === (float) $delta ) {
            return 'flat';
        }
        $improved = $lower_is_better ? $delta < 0 : $delta > 0;

        return $improved ? 'improving' : 'declining';
    }

    private function history_points( $snapshots ) {
        $points = array();
        foreach ( $snapshots as $snapshot ) {
            $points[] = array(
                'captured_at'       => isset( $snapshot['captured_at'] ) ? (string) $snapshot['captured_at'] : '',
                'status'            => isset( $snapshot['status'] ) ? (string) $snapshot['status'] : '',
                'clicks'            => isset( $snapshot['search_console']['clicks'] ) ? $snapshot['search_console']['clicks'] : null,
                'impressions'       => isset( $snapshot['search_console']['impressions'] ) ? $snapshot['search_console']['impressions'] : null,
                'average_position'  => isset( $snapshot['search_console']['average_position'] ) ? $snapshot['search_console']['average_position'] : null,
                'average_rank'      => isset( $snapshot['rankings']['average_rank'] ) ? $snapshot['rankings']['average_rank'] : null,
            );
        }

        return $points;
    }
}
