<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Audit_Service {
    const FETCH_TIMEOUT_SECONDS = 10;
    private $registry;
    private $campaign_manager;

    public function __construct( Registry $registry, Campaign_Manager $campaign_manager ) {
        $this->registry = $registry;
        $this->campaign_manager = $campaign_manager;
    }

    public function run_live_head_audit() {
        $results = array();

        foreach ( $this->registry->keys() as $key ) {
            $page = $this->registry->get_effective( $key );
            $page = $this->campaign_manager->apply( $page );
            $results[] = $this->audit_page_head( $key, $page );
        }

        return $results;
    }

    private function audit_page_head( $key, $page ) {
        $label = isset( $page['label'] ) ? (string) $page['label'] : (string) $key;
        $post_id = $this->registry->resolve_post_id( $page );

        if ( $post_id > 0 ) {
            $url = get_permalink( $post_id );
        } else {
            $path = isset( $page['path'] ) ? (string) $page['path'] : '/';
            $url = home_url( $path );
        }

        $fetch_url = $this->cache_busted_url( $url, 'smseo_audit_bust' );
        $response = wp_remote_get(
            $fetch_url,
            $this->fresh_request_args( 'Singularity SEO Live Audit/' . ( defined( 'SMSEO_VERSION' ) ? SMSEO_VERSION : 'unknown' ) )
        );

        $row = array(
            'key'                       => $key,
            'label'                     => $label,
            'url'                       => $url,
            'fetch_url'                 => $fetch_url,
            'http_code'                 => 0,
            'status'                    => 'FAIL',
            'flags'                     => array(),
            'title'                     => '',
            'title_count'               => 0,
            'description_count'         => 0,
            'canonical_count'           => 0,
            'robots_count'              => 0,
            'og_title_count'            => 0,
            'og_description_count'      => 0,
            'og_url_count'              => 0,
            'twitter_title_count'       => 0,
            'twitter_description_count' => 0,
            'schema_count'              => 0,
            'schema_valid'              => 0,
            'schema_invalid'            => 0,
        );

        if ( is_wp_error( $response ) ) {
            $row['flags'][] = 'Fetch failed: ' . $response->get_error_message();
            return $row;
        }

        $row['http_code'] = (int) wp_remote_retrieve_response_code( $response );
        $html = (string) wp_remote_retrieve_body( $response );

        if ( $row['http_code'] < 200 || $row['http_code'] >= 400 ) {
            if ( 404 === $row['http_code'] ) {
                $row['status'] = 'SKIP';
                $row['flags'][] = 'Registry entry is not present in this WordPress environment';
                return $row;
            }

            $row['flags'][] = 'Unexpected HTTP response';
        }

        if ( '' === trim( $html ) ) {
            $row['flags'][] = 'Empty HTML response';
            return $row;
        }

        if ( ! class_exists( '\\DOMDocument' ) ) {
            $row['flags'][] = 'DOMDocument unavailable; audit parser cannot inspect HTML';
            return $row;
        }

        libxml_use_internal_errors( true );
        $dom = new \DOMDocument();
        $loaded = $dom->loadHTML( $html, LIBXML_NOWARNING | LIBXML_NOERROR );
        libxml_clear_errors();

        if ( ! $loaded ) {
            $row['flags'][] = 'HTML parser failed';
            return $row;
        }

        $xpath = new \DOMXPath( $dom );

        $titles = $xpath->query( '//head/title' );
        $row['title_count'] = $titles ? (int) $titles->length : 0;
        if ( $titles && $titles->length > 0 ) {
            $row['title'] = trim( (string) $titles->item( 0 )->textContent );
        }

        $row['description_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="description"]' );
        $row['canonical_count'] = $this->xpath_count( $xpath, '//head/link[translate(@rel,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="canonical"]' );
        $row['robots_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="robots"]' );
        $row['og_title_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@property,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="og:title"]' );
        $row['og_description_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@property,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="og:description"]' );
        $row['og_url_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@property,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="og:url"]' );
        $row['twitter_title_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="twitter:title"]' );
        $row['twitter_description_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="twitter:description"]' );

        $schema_nodes = $xpath->query( '//head/script[translate(@type,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="application/ld+json"]' );
        $row['schema_count'] = $schema_nodes ? (int) $schema_nodes->length : 0;

        if ( $schema_nodes ) {
            foreach ( $schema_nodes as $schema_node ) {
                $decoded = json_decode( trim( (string) $schema_node->textContent ), true );
                if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
                    $row['schema_valid']++;
                } else {
                    $row['schema_invalid']++;
                }
            }
        }

        $expected_title = isset( $page['title'] ) ? (string) $page['title'] : '';
        if ( 1 !== $row['title_count'] ) {
            $row['flags'][] = 'Expected exactly one title tag';
        }
        if ( '' !== $expected_title && $row['title'] !== $expected_title ) {
            $row['flags'][] = 'Title does not match registry';
        }
        if ( 1 !== $row['description_count'] ) {
            $row['flags'][] = 'Expected exactly one meta description';
        }
        if ( 1 !== $row['canonical_count'] ) {
            $row['flags'][] = 'Expected exactly one canonical';
        }
        if ( 1 !== $row['robots_count'] ) {
            $row['flags'][] = 'Expected exactly one robots meta';
        }
        if ( 1 !== $row['og_title_count'] || 1 !== $row['og_description_count'] || 1 !== $row['og_url_count'] ) {
            $row['flags'][] = 'Open Graph tag count issue';
        }
        if ( 1 !== $row['twitter_title_count'] || 1 !== $row['twitter_description_count'] ) {
            $row['flags'][] = 'Twitter/X tag count issue';
        }
        if ( $row['schema_count'] < 1 ) {
            $row['flags'][] = 'No JSON-LD schema found';
        }
        if ( $row['schema_invalid'] > 0 ) {
            $row['flags'][] = 'Invalid JSON-LD schema detected';
        }

        if ( empty( $row['flags'] ) ) {
            $row['status'] = 'PASS';
        }

        return $row;
    }

    private function xpath_count( \DOMXPath $xpath, $query ) {
        $nodes = $xpath->query( $query );
        return $nodes ? (int) $nodes->length : 0;
    }

    private function cache_busted_url( $url, $arg_name ) {
        return add_query_arg( $arg_name, rawurlencode( (string) microtime( true ) ), $url );
    }

    private function fresh_request_args( $user_agent ) {
        return array(
            'timeout'     => self::FETCH_TIMEOUT_SECONDS,
            'redirection' => 3,
            'user-agent'  => $user_agent,
            'headers'     => array(
                'Cache-Control' => 'no-cache, no-store, max-age=0',
                'Pragma'        => 'no-cache',
                'Expires'       => '0',
            ),
        );
    }
}
