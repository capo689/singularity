<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Robots_Txt_Manager {
    public function __construct() {
        add_filter( 'robots_txt', array( $this, 'filter_robots_txt' ), 20, 2 );
    }

    public function filter_robots_txt( $output, $public ) {
        if ( ! $public || '0' === (string) get_option( 'blog_public' ) ) {
            return $output;
        }

        $sitemap_line = 'Sitemap: ' . home_url( '/wp-sitemap.xml' );

        if ( false === strpos( $output, $sitemap_line ) ) {
            $output = rtrim( (string) $output ) . "\n\n" . $sitemap_line . "\n";
        }

        return $output;
    }
}
