<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Metrics_Store {
    const SNAPSHOTS_OPTION = 'smseo_health_snapshots';
    const MAX_SNAPSHOTS = 52;

    public function create_snapshot( $audit_results, $source = 'manual' ) {
        $audit_results = is_array( $audit_results ) ? $audit_results : array();
        $summary = $this->summarize_audit_results( $audit_results );
        $now = current_time( 'mysql', true );

        $snapshot = array(
            'id'                 => 'health_' . gmdate( 'YmdHis' ),
            'captured_at'        => $now,
            'source'             => sanitize_key( (string) $source ),
            'score'              => $summary['score'],
            'grade'              => $this->grade_for_score( $summary['score'] ),
            'summary'            => $summary,
            'top_issues'         => $this->top_issues( $audit_results ),
            'page_scores'        => $this->page_scores( $audit_results ),
            'managed_page_count' => count( $audit_results ),
        );

        $snapshots = $this->get_snapshots();
        $snapshots[] = $snapshot;
        if ( count( $snapshots ) > self::MAX_SNAPSHOTS ) {
            $snapshots = array_slice( $snapshots, -1 * self::MAX_SNAPSHOTS );
        }
        update_option( self::SNAPSHOTS_OPTION, $snapshots, false );

        return $snapshot;
    }

    public function get_metrics() {
        $snapshots = $this->get_snapshots();
        $baseline = ! empty( $snapshots ) ? reset( $snapshots ) : null;
        $current = ! empty( $snapshots ) ? end( $snapshots ) : null;

        return array(
            'baseline'       => $baseline,
            'current'        => $current,
            'delta'          => $this->score_delta( $baseline, $current ),
            'snapshot_count' => count( $snapshots ),
            'history'        => $this->history_points( $snapshots ),
            'automation'     => class_exists( '\SMSEO\Health_Scheduler' ) ? Health_Scheduler::status() : array(),
        );
    }

    public function get_snapshots() {
        $snapshots = get_option( self::SNAPSHOTS_OPTION, array() );
        return is_array( $snapshots ) ? array_values( $snapshots ) : array();
    }

    public function get_current_snapshot() {
        $snapshots = $this->get_snapshots();
        if ( empty( $snapshots ) ) {
            return null;
        }

        return end( $snapshots );
    }

    private function summarize_audit_results( $results ) {
        $total = count( $results );
        $passed = 0;
        $skipped = 0;
        $flagged = 0;
        $issue_count = 0;
        $checks_possible = 0;
        $checks_passed = 0;

        foreach ( $results as $row ) {
            $status = isset( $row['status'] ) ? (string) $row['status'] : 'FAIL';
            if ( 'PASS' === $status ) {
                $passed++;
            } elseif ( 'SKIP' === $status ) {
                $skipped++;
                continue;
            } else {
                $flagged++;
            }

            $flags = isset( $row['flags'] ) && is_array( $row['flags'] ) ? $row['flags'] : array();
            $issue_count += count( $flags );
            $checks = $this->score_page_checks( $row );
            $checks_possible += $checks['possible'];
            $checks_passed += $checks['passed'];
        }

        $score = $checks_possible > 0 ? (int) round( ( $checks_passed / $checks_possible ) * 100 ) : 0;

        return array(
            'score'           => max( 0, min( 100, $score ) ),
            'total'           => $total,
            'passed'          => $passed,
            'flagged'         => $flagged,
            'skipped'         => $skipped,
            'issue_count'     => $issue_count,
            'checks_passed'   => $checks_passed,
            'checks_possible' => $checks_possible,
        );
    }

    private function page_scores( $results ) {
        $page_scores = array();
        foreach ( $results as $row ) {
            $checks = $this->score_page_checks( $row );
            $score = $checks['possible'] > 0 ? (int) round( ( $checks['passed'] / $checks['possible'] ) * 100 ) : 0;
            $page_scores[] = array(
                'key'         => isset( $row['key'] ) ? (string) $row['key'] : '',
                'label'       => isset( $row['label'] ) ? (string) $row['label'] : '',
                'url'         => isset( $row['url'] ) ? (string) $row['url'] : '',
                'status'      => isset( $row['status'] ) ? (string) $row['status'] : 'FAIL',
                'score'       => max( 0, min( 100, $score ) ),
                'issue_count' => isset( $row['flags'] ) && is_array( $row['flags'] ) ? count( $row['flags'] ) : 0,
            );
        }

        return $page_scores;
    }

    private function score_page_checks( $row ) {
        if ( isset( $row['status'] ) && 'SKIP' === $row['status'] ) {
            return array( 'passed' => 0, 'possible' => 0 );
        }

        $checks = array(
            isset( $row['http_code'] ) && (int) $row['http_code'] >= 200 && (int) $row['http_code'] < 400,
            isset( $row['title_count'] ) && 1 === (int) $row['title_count'],
            isset( $row['description_count'] ) && 1 === (int) $row['description_count'],
            isset( $row['canonical_count'] ) && 1 === (int) $row['canonical_count'],
            isset( $row['robots_count'] ) && 1 === (int) $row['robots_count'],
            isset( $row['og_title_count'], $row['og_description_count'], $row['og_url_count'] )
                && 1 === (int) $row['og_title_count']
                && 1 === (int) $row['og_description_count']
                && 1 === (int) $row['og_url_count'],
            isset( $row['twitter_title_count'], $row['twitter_description_count'] )
                && 1 === (int) $row['twitter_title_count']
                && 1 === (int) $row['twitter_description_count'],
            isset( $row['schema_count'], $row['schema_invalid'] )
                && (int) $row['schema_count'] > 0
                && 0 === (int) $row['schema_invalid'],
            empty( $row['flags'] ),
        );

        return array(
            'passed'   => count( array_filter( $checks ) ),
            'possible' => count( $checks ),
        );
    }

    private function top_issues( $results ) {
        $issue_counts = array();
        foreach ( $results as $row ) {
            $flags = isset( $row['flags'] ) && is_array( $row['flags'] ) ? $row['flags'] : array();
            foreach ( $flags as $flag ) {
                $flag = (string) $flag;
                $issue_counts[ $flag ] = isset( $issue_counts[ $flag ] ) ? $issue_counts[ $flag ] + 1 : 1;
            }
        }
        arsort( $issue_counts );

        $issues = array();
        foreach ( array_slice( $issue_counts, 0, 5, true ) as $issue => $count ) {
            $issues[] = array(
                'issue' => $issue,
                'count' => (int) $count,
            );
        }

        return $issues;
    }

    private function history_points( $snapshots ) {
        $points = array();
        foreach ( $snapshots as $snapshot ) {
            $points[] = array(
                'captured_at' => isset( $snapshot['captured_at'] ) ? (string) $snapshot['captured_at'] : '',
                'score'       => isset( $snapshot['score'] ) ? (int) $snapshot['score'] : 0,
                'grade'       => isset( $snapshot['grade'] ) ? (string) $snapshot['grade'] : '',
            );
        }

        return $points;
    }

    private function score_delta( $baseline, $current ) {
        if ( ! is_array( $baseline ) || ! is_array( $current ) ) {
            return null;
        }

        return (int) $current['score'] - (int) $baseline['score'];
    }

    private function grade_for_score( $score ) {
        $score = (int) $score;
        if ( $score >= 90 ) {
            return 'Excellent';
        }
        if ( $score >= 75 ) {
            return 'Strong';
        }
        if ( $score >= 60 ) {
            return 'Needs work';
        }

        return 'At risk';
    }
}
