<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Context {
    private $registry;
    private $campaign_manager;

    public function __construct( Registry $registry, Campaign_Manager $campaign_manager ) {
        $this->registry = $registry;
        $this->campaign_manager = $campaign_manager;
    }

    public function current_path() {
        $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
        $path = wp_parse_url( $request_uri, PHP_URL_PATH );

        return $this->registry->normalize_path( $path ? $path : '/' );
    }

    public function current_managed_page() {
        // Never apply managed SEO output to an actual 404 response.
        // This prevents configured-but-missing pages, such as a future campaign
        // landing page, from receiving normal indexable SEO metadata on a 404 template.
        if ( is_404() ) {
            return null;
        }

        $page = $this->resolve_current_managed_page();

        if ( ! is_array( $page ) || empty( $page['key'] ) ) {
            return null;
        }

        $effective = $this->registry->get_effective( $page['key'] );

        if ( ! is_array( $effective ) ) {
            return null;
        }

        return $this->campaign_manager->apply( $effective );
    }

    /**
     * Resolve the current request to a managed SEO page.
     *
     * Order matters:
     * 1. Exact current request path, including configured aliases.
     * 2. Queried singular object's permalink path.
     * 3. Queried singular object's resolved post ID against registry paths.
     *
     * This makes the plugin resilient when dev/live slugs differ or when
     * WordPress normalizes a request before document-title generation.
     */
    private function resolve_current_managed_page() {
        $current_path = $this->current_path();
        $page = $this->registry->get_by_path( $current_path );

        if ( is_array( $page ) ) {
            return $page;
        }

        if ( is_singular() ) {
            $queried_id = (int) get_queried_object_id();

            if ( $queried_id > 0 ) {
                $permalink = get_permalink( $queried_id );

                if ( is_string( $permalink ) && '' !== $permalink ) {
                    $permalink_path = $this->registry->normalize_path( $permalink );
                    $page = $this->registry->get_by_path( $permalink_path );

                    if ( is_array( $page ) ) {
                        return $page;
                    }
                }

                foreach ( $this->registry->all() as $key => $candidate ) {
                    $candidate_id = $this->registry->resolve_post_id( $candidate );

                    if ( $candidate_id > 0 && $candidate_id === $queried_id ) {
                        $candidate['key'] = $key;
                        return $candidate;
                    }
                }
            }
        }

        return null;
    }

    public function is_managed() {
        return is_array( $this->current_managed_page() );
    }

    public function is_frontend_render_context() {
        if ( is_admin() || is_feed() || is_trackback() || is_robots() ) {
            return false;
        }

        return true;
    }

    public function fallback_canonical() {
        if ( is_singular() ) {
            $permalink = get_permalink();
            return $permalink ? $permalink : '';
        }

        return '';
    }

    public function fallback_title() {
        return wp_get_document_title();
    }

    public function fallback_description() {
        if ( ! is_singular() ) {
            return '';
        }

        global $post;

        if ( ! $post instanceof \WP_Post ) {
            return '';
        }

        if ( has_excerpt( $post ) ) {
            return $this->trim_plain_text( get_the_excerpt( $post ), 320 );
        }

        return '';
    }

    public function trim_plain_text( $text, $max_chars = 320 ) {
        $text = wp_strip_all_tags( strip_shortcodes( (string) $text ) );
        $text = preg_replace( '/\s+/', ' ', $text );
        $text = trim( $text );

        if ( function_exists( 'mb_strlen' ) && function_exists( 'mb_substr' ) ) {
            if ( mb_strlen( $text ) <= $max_chars ) {
                return $text;
            }

            return rtrim( mb_substr( $text, 0, $max_chars - 1 ) ) . '…';
        }

        if ( strlen( $text ) <= $max_chars ) {
            return $text;
        }

        return rtrim( substr( $text, 0, $max_chars - 1 ) ) . '…';
    }
}
