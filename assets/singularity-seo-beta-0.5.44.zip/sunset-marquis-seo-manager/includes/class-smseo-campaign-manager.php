<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Campaign_Manager {
    public function apply( $page ) {
        if ( ! is_array( $page ) || empty( $page['campaign'] ) || ! is_array( $page['campaign'] ) ) {
            return $page;
        }

        $campaign = $page['campaign'];
        $expired = $this->is_expired( isset( $campaign['expires_on'] ) ? $campaign['expires_on'] : '' );

        $description = $expired
            ? ( isset( $campaign['evergreen_description'] ) ? $campaign['evergreen_description'] : $page['description'] )
            : ( isset( $campaign['active_description'] ) ? $campaign['active_description'] : $page['description'] );

        $hotel_description = $expired
            ? ( isset( $campaign['evergreen_hotel_description'] ) ? $campaign['evergreen_hotel_description'] : '' )
            : ( isset( $campaign['active_hotel_description'] ) ? $campaign['active_hotel_description'] : '' );

        if ( '' !== $description ) {
            $page['description'] = $description;

            if ( isset( $page['og'] ) && is_array( $page['og'] ) ) {
                $page['og']['description'] = $description;
            }

            if ( isset( $page['twitter'] ) && is_array( $page['twitter'] ) ) {
                $page['twitter']['description'] = $description;
            }
        }

        if ( isset( $page['schema_json'] ) && is_string( $page['schema_json'] ) ) {
            $page['schema_json'] = $this->hydrate_schema_placeholders(
                $page['schema_json'],
                $description,
                $hotel_description
            );
        }

        $page['campaign_status'] = $expired ? 'expired' : 'active';

        return $page;
    }

    public function is_expired( $expires_on ) {
        if ( ! is_string( $expires_on ) || '' === trim( $expires_on ) ) {
            return false;
        }

        $expires_on = trim( $expires_on );
        if ( ! Validation::is_valid_iso_date( $expires_on ) ) {
            // A non-empty malformed expiry should not keep time-bound campaign copy active indefinitely.
            return true;
        }

        try {
            $timezone = wp_timezone();
            $expiry = new \DateTimeImmutable( $expires_on . ' 23:59:59', $timezone );
            $now = new \DateTimeImmutable( 'now', $timezone );

            return $now > $expiry;
        } catch ( \Exception $e ) {
            return false;
        }
    }

    private function hydrate_schema_placeholders( $schema_json, $description, $hotel_description ) {
        $decoded = json_decode( $schema_json, true );

        if ( ! is_array( $decoded ) ) {
            return $schema_json;
        }

        $replacements = array(
            '{{SMSEO_HOME_WEBPAGE_DESCRIPTION}}' => (string) $description,
            '{{SMSEO_HOME_HOTEL_DESCRIPTION}}' => (string) $hotel_description,
        );

        $decoded = $this->replace_placeholders_recursive( $decoded, $replacements );

        $encoded = wp_json_encode( $decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );

        return $encoded ? $encoded : $schema_json;
    }

    private function replace_placeholders_recursive( $value, $replacements ) {
        if ( is_array( $value ) ) {
            foreach ( $value as $key => $child ) {
                $value[ $key ] = $this->replace_placeholders_recursive( $child, $replacements );
            }

            return $value;
        }

        if ( is_string( $value ) && isset( $replacements[ $value ] ) ) {
            return $replacements[ $value ];
        }

        return $value;
    }
}
