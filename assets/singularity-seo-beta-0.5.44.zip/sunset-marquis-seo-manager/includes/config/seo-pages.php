<?php
defined( 'ABSPATH' ) || exit;

return array(
    'homepage' => array(
        'label' => 'Homepage',
        'path' => '/',
        'canonical' => 'https://sunsetmarquis.com/',
        'title' => 'Sunset Marquis | West Hollywood Hotel, Suites & Private Villas',
        'description' => 'Sunset Marquis is a West Hollywood hotel with spacious suites, private villas, lush gardens, Cavatina, BAR 1200 and Nightbird Studios, ideal for FIFA World Cup 2026 Los Angeles stays.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Organization + Hotel/LodgingBusiness + WebSite + WebPage + on-property entities',
        'og' => array(
            'title' => 'Sunset Marquis | West Hollywood Hotel, Suites & Private Villas',
            'description' => 'Sunset Marquis is a West Hollywood hotel with spacious suites, private villas, lush gardens, Cavatina, BAR 1200 and Nightbird Studios, ideal for FIFA World Cup 2026 Los Angeles stays.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Sunset Marquis | West Hollywood Hotel, Suites & Private Villas',
            'description' => 'Sunset Marquis is a West Hollywood hotel with spacious suites, private villas, lush gardens, Cavatina, BAR 1200 and Nightbird Studios, ideal for FIFA World Cup 2026 Los Angeles stays.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'campaign' => array(
            'expires_on' => '2026-07-20',
            'active_description' => 'Sunset Marquis is a West Hollywood hotel with spacious suites, private villas, lush gardens, Cavatina, BAR 1200 and Nightbird Studios, ideal for FIFA World Cup 2026 Los Angeles stays.',
            'evergreen_description' => 'Sunset Marquis is a West Hollywood hotel with spacious suites, private villas, lush gardens, Cavatina, BAR 1200 and Nightbird Studios near the Sunset Strip.',
            'active_hotel_description' => 'Sunset Marquis Hotel & Villas is a West Hollywood retreat steps from the Sunset Strip, with 152 spacious suites and private villas set within three and a half acres of lush gardens. The property is home to Cavatina restaurant, BAR 1200, Nightbird Recording Studios, the Morrison Hotel Gallery, two heated outdoor pools, spa services and in-room wellness experiences, a wellness studio, Les Clefs d\'Or concierge service, and electric vehicle charging. It is an ideal West Hollywood retreat for travelers attending Los Angeles\' 2026 SoFi Stadium soccer matches.',
            'evergreen_hotel_description' => 'Sunset Marquis Hotel & Villas is a West Hollywood retreat steps from the Sunset Strip, with 152 spacious suites and private villas set within three and a half acres of lush gardens. The property is home to Cavatina restaurant, BAR 1200, Nightbird Recording Studios, the Morrison Hotel Gallery, two heated outdoor pools, spa services and in-room wellness experiences, a wellness studio, Les Clefs d\'Or concierge service, and electric vehicle charging.',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Organization",
              "@id": "https://sunsetmarquis.com/#organization",
              "name": "Sunset Marquis",
              "url": "https://sunsetmarquis.com/",
              "email": "info@sunsetmarquis.com",
              "logo": {
                "@type": "ImageObject",
                "@id": "https://sunsetmarquis.com/#logo",
                "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/sm.png",
                "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/sm.png",
                "caption": "Sunset Marquis",
                "inLanguage": "en-US",
                "width": 112,
                "height": 112
              },
              "sameAs": [
                "https://www.instagram.com/sunsetmarquis/",
                "https://www.facebook.com/SunsetMarquisLA/"
              ],
              "contactPoint": [
                {
                  "@type": "ContactPoint",
                  "telephone": "+1-800-858-9758",
                  "contactType": "reservations",
                  "areaServed": "US",
                  "availableLanguage": [
                    "en"
                  ]
                },
                {
                  "@type": "ContactPoint",
                  "telephone": "+1-310-657-1333",
                  "contactType": "customer service",
                  "areaServed": "US",
                  "availableLanguage": [
                    "en"
                  ]
                }
              ]
            },
            {
              "@type": [
                "Hotel",
                "LodgingBusiness"
              ],
              "@id": "https://sunsetmarquis.com/#hotel",
              "name": "Sunset Marquis Hotel & Villas",
              "alternateName": "Sunset Marquis",
              "url": "https://sunsetmarquis.com/",
              "image": [
                {
                  "@type": "ImageObject",
                  "@id": "https://sunsetmarquis.com/#primaryimage",
                  "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
                  "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
                  "width": 1200,
                  "height": 630,
                  "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
                  "inLanguage": "en-US"
                }
              ],
              "logo": {
                "@id": "https://sunsetmarquis.com/#logo"
              },
              "telephone": "+1-310-657-1333",
              "email": "info@sunsetmarquis.com",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "1200 Alta Loma Road",
                "addressLocality": "West Hollywood",
                "addressRegion": "CA",
                "postalCode": "90069",
                "addressCountry": "US"
              },
              "geo": {
                "@type": "GeoCoordinates",
                "latitude": 34.0922307,
                "longitude": -118.377474
              },
              "hasMap": "https://www.google.com/maps/place/?q=place_id:ChIJR5onXby-woARNYxlILROsfk",
              "description": "{{SMSEO_HOME_HOTEL_DESCRIPTION}}",
              "priceRange": "$$$$",
              "currenciesAccepted": "USD",
              "checkinTime": "15:00:00",
              "checkoutTime": "12:00:00",
              "petsAllowed": "Small dogs 15 pounds or under are accepted, subject to hotel pet policy.",
              "numberOfRooms": {
                "@type": "QuantitativeValue",
                "value": 152,
                "unitText": "rooms"
              },
              "amenityFeature": [
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Private villas",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Spacious suites",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Lush garden setting",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Two heated outdoor pools",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Spa services and in-room wellness experiences",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Wellness Studio",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Les Clefs d'Or concierge service",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Electric vehicle charging",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "24-hour room service",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Pet friendly",
                  "value": true
                },
                {
                  "@type": "LocationFeatureSpecification",
                  "name": "Complimentary Wi-Fi",
                  "value": true
                }
              ],
              "containsPlace": [
                {
                  "@id": "https://sunsetmarquis.com/#cavatina"
                },
                {
                  "@id": "https://sunsetmarquis.com/#bar1200"
                },
                {
                  "@id": "https://sunsetmarquis.com/#nightbird"
                },
                {
                  "@id": "https://sunsetmarquis.com/#morrisongallery"
                }
              ],
              "potentialAction": {
                "@type": "ReserveAction",
                "target": {
                  "@type": "EntryPoint",
                  "urlTemplate": "https://be.synxis.com/?Hotel=1059&Chain=27506",
                  "actionPlatform": [
                    "http://schema.org/DesktopWebPlatform",
                    "http://schema.org/MobileWebPlatform"
                  ]
                },
                "result": {
                  "@type": "LodgingReservation",
                  "name": "Reserve a room at Sunset Marquis"
                }
              },
              "parentOrganization": {
                "@id": "https://sunsetmarquis.com/#organization"
              }
            },
            {
              "@type": "Restaurant",
              "@id": "https://sunsetmarquis.com/#cavatina",
              "name": "Cavatina",
              "url": "https://sunsetmarquis.com/cavatina-restaurant/",
              "description": "Cavatina is the indoor-outdoor restaurant at Sunset Marquis, helmed by Chef Luis Morales, serving breakfast, lunch, dinner and weekend brunch on a garden-surrounded patio in West Hollywood.",
              "servesCuisine": [
                "American",
                "California"
              ],
              "priceRange": "$$$",
              "acceptsReservations": true,
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "1200 Alta Loma Road",
                "addressLocality": "West Hollywood",
                "addressRegion": "CA",
                "postalCode": "90069",
                "addressCountry": "US"
              },
              "telephone": "+1-310-657-1333",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              }
            },
            {
              "@type": "BarOrPub",
              "@id": "https://sunsetmarquis.com/#bar1200",
              "name": "BAR 1200",
              "url": "https://sunsetmarquis.com/west-hollywood-bar-1200/",
              "description": "BAR 1200 is the legendary late-night bar at Sunset Marquis, serving premium spirits, cocktails and an intimate atmosphere steps from the Sunset Strip.",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "1200 Alta Loma Road",
                "addressLocality": "West Hollywood",
                "addressRegion": "CA",
                "postalCode": "90069",
                "addressCountry": "US"
              },
              "telephone": "+1-310-657-1333",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              }
            },
            {
              "@type": "Organization",
              "@id": "https://sunsetmarquis.com/#nightbird",
              "name": "Nightbird Recording Studios",
              "url": "https://sunsetmarquis.com/nightbird-studios/",
              "description": "Nightbird Recording Studios is the world-class recording facility located beneath Sunset Marquis in West Hollywood, hosting internationally acclaimed artists across multiple studios and production suites.",
              "parentOrganization": {
                "@id": "https://sunsetmarquis.com/#organization"
              },
              "location": {
                "@id": "https://sunsetmarquis.com/#hotel"
              }
            },
            {
              "@type": "ArtGallery",
              "@id": "https://sunsetmarquis.com/#morrisongallery",
              "name": "Morrison Hotel Gallery",
              "url": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/",
              "description": "The Morrison Hotel Gallery at Sunset Marquis showcases world-class collectible photography in an intimate gallery setting on property.",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "1200 Alta Loma Road",
                "addressLocality": "West Hollywood",
                "addressRegion": "CA",
                "postalCode": "90069",
                "addressCountry": "US"
              },
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              }
            },
            {
              "@type": "WebSite",
              "@id": "https://sunsetmarquis.com/#website",
              "url": "https://sunsetmarquis.com/",
              "name": "Sunset Marquis",
              "publisher": {
                "@id": "https://sunsetmarquis.com/#organization"
              },
              "inLanguage": "en-US",
              "potentialAction": {
                "@type": "SearchAction",
                "target": "https://sunsetmarquis.com/?s={search_term_string}",
                "query-input": "required name=search_term_string"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/#webpage",
              "url": "https://sunsetmarquis.com/",
              "name": "Sunset Marquis | West Hollywood Hotel, Suites & Private Villas",
              "description": "{{SMSEO_HOME_WEBPAGE_DESCRIPTION}}",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mentions": [
                {
                  "@id": "https://sunsetmarquis.com/#cavatina"
                },
                {
                  "@id": "https://sunsetmarquis.com/#bar1200"
                },
                {
                  "@id": "https://sunsetmarquis.com/#nightbird"
                },
                {
                  "@id": "https://sunsetmarquis.com/#morrisongallery"
                }
              ],
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/#primaryimage"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'villas_landing' => array(
        'label' => 'Villas Landing Page',
        'path' => '/villas-west-hollywood/',
        'path_aliases' => array( '/villas/' ),
        'canonical' => 'https://sunsetmarquis.com/villas-west-hollywood/',
        'title' => 'West Hollywood Villas | Private Villa Stays | Sunset Marquis',
        'description' => 'Explore private villas at Sunset Marquis in West Hollywood, from redesigned studio and one-bedroom villas to expansive two-bedroom, Retreat and Presidential stays.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'CollectionPage + ItemList + BreadcrumbList',
        'og' => array(
            'title' => 'West Hollywood Villas | Private Villa Stays | Sunset Marquis',
            'description' => 'Explore private villas at Sunset Marquis in West Hollywood, from redesigned studio and one-bedroom villas to expansive two-bedroom, Retreat and Presidential stays.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'West Hollywood Villas | Private Villa Stays | Sunset Marquis',
            'description' => 'Explore private villas at Sunset Marquis in West Hollywood, from redesigned studio and one-bedroom villas to expansive two-bedroom, Retreat and Presidential stays.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Villas",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/"
                }
              ]
            },
            {
              "@type": "ItemList",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/#villa-list",
              "name": "Sunset Marquis Villas",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Studio Villa",
                  "url": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "One-Bedroom Villa",
                  "url": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "Two-Bedroom Villa",
                  "url": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/"
                },
                {
                  "@type": "ListItem",
                  "position": 4,
                  "name": "Grand Deluxe Villa",
                  "url": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/"
                },
                {
                  "@type": "ListItem",
                  "position": 5,
                  "name": "The Retreat",
                  "url": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/"
                },
                {
                  "@type": "ListItem",
                  "position": 6,
                  "name": "Presidential Villa",
                  "url": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/"
                }
              ]
            },
            {
              "@type": "CollectionPage",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/#webpage",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/",
              "name": "West Hollywood Villas | Private Villa Stays | Sunset Marquis",
              "description": "Explore private villas at Sunset Marquis in West Hollywood, from redesigned studio and one-bedroom villas to expansive two-bedroom, Retreat and Presidential stays.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/#primaryimage"
              },
              "inLanguage": "en-US",
              "about": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/#villa-list"
              }
            }
          ]
        }
JSON
    ),
    'suites_landing' => array(
        'label' => 'Suites Landing Page',
        'path' => '/west-hollywood-hotel-suites/',
        'path_aliases' => array( '/suites/' ),
        'canonical' => 'https://sunsetmarquis.com/west-hollywood-hotel-suites/',
        'title' => 'West Hollywood Suites | Studio, One-Bedroom & King Rooms | Sunset Marquis',
        'description' => 'Discover spacious Sunset Marquis suites in West Hollywood, including Studio Suites, One-Bedroom Suites and King Guest Rooms near the Sunset Strip.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'CollectionPage + ItemList + BreadcrumbList',
        'og' => array(
            'title' => 'West Hollywood Suites | Studio, One-Bedroom & King Rooms | Sunset Marquis',
            'description' => 'Discover spacious Sunset Marquis suites in West Hollywood, including Studio Suites, One-Bedroom Suites and King Guest Rooms near the Sunset Strip.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'West Hollywood Suites | Studio, One-Bedroom & King Rooms | Sunset Marquis',
            'description' => 'Discover spacious Sunset Marquis suites in West Hollywood, including Studio Suites, One-Bedroom Suites and King Guest Rooms near the Sunset Strip.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Suites",
                  "item": "https://sunsetmarquis.com/west-hollywood-hotel-suites/"
                }
              ]
            },
            {
              "@type": "ItemList",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/#suite-list",
              "name": "Sunset Marquis Suites and Guest Rooms",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Studio Suite",
                  "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "One-Bedroom Suite",
                  "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "King Guest Room",
                  "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/"
                }
              ]
            },
            {
              "@type": "CollectionPage",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/#webpage",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/",
              "name": "West Hollywood Suites | Studio, One-Bedroom & King Rooms | Sunset Marquis",
              "description": "Discover spacious Sunset Marquis suites in West Hollywood, including Studio Suites, One-Bedroom Suites and King Guest Rooms near the Sunset Strip.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/#primaryimage"
              },
              "inLanguage": "en-US",
              "about": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/#suite-list"
              }
            }
          ]
        }
JSON
    ),
    'studio_villa' => array(
        'label' => 'Studio Villa',
        'path' => '/villas-west-hollywood/studio-villa/',
        'path_aliases' => array( '/studio-villas/' ),
        'canonical' => 'https://sunsetmarquis.com/villas-west-hollywood/studio-villa/',
        'title' => 'Studio Villa in West Hollywood | Sunset Marquis',
        'description' => 'The redesigned Studio Villa at Sunset Marquis pairs an open living and sleeping space with a garden arrival, villa amenities and West Hollywood ease.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Accommodation + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Studio Villa in West Hollywood | Sunset Marquis',
            'description' => 'The redesigned Studio Villa at Sunset Marquis pairs an open living and sleeping space with a garden arrival, villa amenities and West Hollywood ease.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Studio Villa in West Hollywood | Sunset Marquis',
            'description' => 'The redesigned Studio Villa at Sunset Marquis pairs an open living and sleeping space with a garden arrival, villa amenities and West Hollywood ease.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Villas",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "Studio Villa",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/"
                }
              ]
            },
            {
              "@type": "Accommodation",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/#accommodation",
              "name": "Studio Villa in West Hollywood",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/",
              "description": "The redesigned Studio Villa at Sunset Marquis pairs an open living and sleeping space with a garden arrival, villa amenities and West Hollywood ease.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/#webpage"
              },
              "accommodationCategory": "Villa"
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/#webpage",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/",
              "name": "Studio Villa in West Hollywood | Sunset Marquis",
              "description": "The redesigned Studio Villa at Sunset Marquis pairs an open living and sleeping space with a garden arrival, villa amenities and West Hollywood ease.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/#accommodation"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/studio-villa/#accommodation"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'one_bedroom_villa' => array(
        'label' => 'One-Bedroom Villa',
        'path' => '/villas-west-hollywood/one-bedroom-villa/',
        'path_aliases' => array( '/one-bedroom-villa/' ),
        'canonical' => 'https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/',
        'title' => 'One-Bedroom Villa in West Hollywood | Sunset Marquis',
        'description' => 'Stay in a Sunset Marquis One-Bedroom Villa with separate sleeping and living spaces, generous comfort and many villas featuring a balcony or patio.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Accommodation + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'One-Bedroom Villa in West Hollywood | Sunset Marquis',
            'description' => 'Stay in a Sunset Marquis One-Bedroom Villa with separate sleeping and living spaces, generous comfort and many villas featuring a balcony or patio.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'One-Bedroom Villa in West Hollywood | Sunset Marquis',
            'description' => 'Stay in a Sunset Marquis One-Bedroom Villa with separate sleeping and living spaces, generous comfort and many villas featuring a balcony or patio.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Villas",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "One-Bedroom Villa",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/"
                }
              ]
            },
            {
              "@type": "Accommodation",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/#accommodation",
              "name": "One-Bedroom Villa in West Hollywood",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/",
              "description": "Stay in a Sunset Marquis One-Bedroom Villa with separate sleeping and living spaces, generous comfort and many villas featuring a balcony or patio.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/#webpage"
              },
              "accommodationCategory": "Villa"
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/#webpage",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/",
              "name": "One-Bedroom Villa in West Hollywood | Sunset Marquis",
              "description": "Stay in a Sunset Marquis One-Bedroom Villa with separate sleeping and living spaces, generous comfort and many villas featuring a balcony or patio.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/#accommodation"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/one-bedroom-villa/#accommodation"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'two_bedroom_villa' => array(
        'label' => 'Two-Bedroom Villa',
        'path' => '/villas-west-hollywood/two-bedroom-villa/',
        'path_aliases' => array( '/two-bedroom-villa/' ),
        'canonical' => 'https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/',
        'title' => 'Two-Bedroom Villa in West Hollywood | Sunset Marquis',
        'description' => 'The Two-Bedroom Villa at Sunset Marquis offers 1,500 square feet, oversized living areas, patios, fireplaces and select full kitchens in West Hollywood.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Accommodation + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Two-Bedroom Villa in West Hollywood | Sunset Marquis',
            'description' => 'The Two-Bedroom Villa at Sunset Marquis offers 1,500 square feet, oversized living areas, patios, fireplaces and select full kitchens in West Hollywood.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Two-Bedroom Villa in West Hollywood | Sunset Marquis',
            'description' => 'The Two-Bedroom Villa at Sunset Marquis offers 1,500 square feet, oversized living areas, patios, fireplaces and select full kitchens in West Hollywood.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Villas",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "Two-Bedroom Villa",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/"
                }
              ]
            },
            {
              "@type": "Accommodation",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/#accommodation",
              "name": "Two-Bedroom Villa in West Hollywood",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/",
              "description": "The Two-Bedroom Villa at Sunset Marquis offers 1,500 square feet, oversized living areas, patios, fireplaces and select full kitchens in West Hollywood.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/#webpage"
              },
              "accommodationCategory": "Villa"
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/#webpage",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/",
              "name": "Two-Bedroom Villa in West Hollywood | Sunset Marquis",
              "description": "The Two-Bedroom Villa at Sunset Marquis offers 1,500 square feet, oversized living areas, patios, fireplaces and select full kitchens in West Hollywood.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/#accommodation"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/two-bedroom-villa/#accommodation"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'grand_deluxe_villa' => array(
        'label' => 'Grand Deluxe Villa',
        'path' => '/villas-west-hollywood/grand-deluxe-villa/',
        'path_aliases' => array( '/grand-deluxe-villa/' ),
        'canonical' => 'https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/',
        'title' => 'Grand Deluxe Villa in West Hollywood | Sunset Marquis',
        'description' => 'Sunset Marquis Grand Deluxe Villas feature private access parking, butler service, a full kitchen, outdoor living space and a baby grand piano.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Accommodation + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Grand Deluxe Villa in West Hollywood | Sunset Marquis',
            'description' => 'Sunset Marquis Grand Deluxe Villas feature private access parking, butler service, a full kitchen, outdoor living space and a baby grand piano.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Grand Deluxe Villa in West Hollywood | Sunset Marquis',
            'description' => 'Sunset Marquis Grand Deluxe Villas feature private access parking, butler service, a full kitchen, outdoor living space and a baby grand piano.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Villas",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "Grand Deluxe Villa",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/"
                }
              ]
            },
            {
              "@type": "Accommodation",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/#accommodation",
              "name": "Grand Deluxe Villa in West Hollywood",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/",
              "description": "Sunset Marquis Grand Deluxe Villas feature private access parking, butler service, a full kitchen, outdoor living space and a baby grand piano.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/#webpage"
              },
              "accommodationCategory": "Villa"
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/#webpage",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/",
              "name": "Grand Deluxe Villa in West Hollywood | Sunset Marquis",
              "description": "Sunset Marquis Grand Deluxe Villas feature private access parking, butler service, a full kitchen, outdoor living space and a baby grand piano.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/#accommodation"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/grand-deluxe-villa/#accommodation"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'the_retreat' => array(
        'label' => 'The Retreat',
        'path' => '/villas-west-hollywood/the-retreat/',
        'path_aliases' => array( '/the-retreat/' ),
        'canonical' => 'https://sunsetmarquis.com/villas-west-hollywood/the-retreat/',
        'title' => 'The Retreat Villa | Private Gathering Space | Sunset Marquis',
        'description' => 'The Retreat at Sunset Marquis is a villa-style West Hollywood space for work, play, creative gatherings and memorable private time with friends.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Accommodation + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'The Retreat Villa | Private Gathering Space | Sunset Marquis',
            'description' => 'The Retreat at Sunset Marquis is a villa-style West Hollywood space for work, play, creative gatherings and memorable private time with friends.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'The Retreat Villa | Private Gathering Space | Sunset Marquis',
            'description' => 'The Retreat at Sunset Marquis is a villa-style West Hollywood space for work, play, creative gatherings and memorable private time with friends.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Villas",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "The Retreat",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/"
                }
              ]
            },
            {
              "@type": "Accommodation",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/#accommodation",
              "name": "The Retreat Villa",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/",
              "description": "The Retreat at Sunset Marquis is a villa-style West Hollywood space for work, play, creative gatherings and memorable private time with friends.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/#webpage"
              },
              "accommodationCategory": "Villa retreat"
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/#webpage",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/",
              "name": "The Retreat Villa | Private Gathering Space | Sunset Marquis",
              "description": "The Retreat at Sunset Marquis is a villa-style West Hollywood space for work, play, creative gatherings and memorable private time with friends.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/#accommodation"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/the-retreat/#accommodation"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'presidential_villa' => array(
        'label' => 'Presidential Villa',
        'path' => '/villas-west-hollywood/presidential-villa/',
        'path_aliases' => array( '/presidential-villa/' ),
        'canonical' => 'https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/',
        'title' => 'Presidential Villa in West Hollywood | Sunset Marquis',
        'description' => 'The Presidential Villa at Sunset Marquis offers fireplaces, a chef\'s kitchen, screening room, private balcony and expansive space for entertaining.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Accommodation + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Presidential Villa in West Hollywood | Sunset Marquis',
            'description' => 'The Presidential Villa at Sunset Marquis offers fireplaces, a chef\'s kitchen, screening room, private balcony and expansive space for entertaining.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Presidential Villa in West Hollywood | Sunset Marquis',
            'description' => 'The Presidential Villa at Sunset Marquis offers fireplaces, a chef\'s kitchen, screening room, private balcony and expansive space for entertaining.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Villas",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "Presidential Villa",
                  "item": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/"
                }
              ]
            },
            {
              "@type": "Accommodation",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/#accommodation",
              "name": "Presidential Villa in West Hollywood",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/",
              "description": "The Presidential Villa at Sunset Marquis offers fireplaces, a chef's kitchen, screening room, private balcony and expansive space for entertaining.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/#webpage"
              },
              "accommodationCategory": "Villa"
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/#webpage",
              "url": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/",
              "name": "Presidential Villa in West Hollywood | Sunset Marquis",
              "description": "The Presidential Villa at Sunset Marquis offers fireplaces, a chef's kitchen, screening room, private balcony and expansive space for entertaining.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/#accommodation"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/villas-west-hollywood/presidential-villa/#accommodation"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'studio_suite' => array(
        'label' => 'Studio Suite',
        'path' => '/west-hollywood-hotel-suites/studio-suites/',
        'path_aliases' => array( '/studio-suites/' ),
        'canonical' => 'https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/',
        'title' => 'Studio Suite in West Hollywood | Sunset Marquis',
        'description' => 'Sunset Marquis Studio Suites feature generous living space, work and sleep areas, pool views, and a patio or balcony in West Hollywood.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Accommodation + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Studio Suite in West Hollywood | Sunset Marquis',
            'description' => 'Sunset Marquis Studio Suites feature generous living space, work and sleep areas, pool views, and a patio or balcony in West Hollywood.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Studio Suite in West Hollywood | Sunset Marquis',
            'description' => 'Sunset Marquis Studio Suites feature generous living space, work and sleep areas, pool views, and a patio or balcony in West Hollywood.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Suites",
                  "item": "https://sunsetmarquis.com/west-hollywood-hotel-suites/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "Studio Suite",
                  "item": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/"
                }
              ]
            },
            {
              "@type": "Accommodation",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/#accommodation",
              "name": "Studio Suite in West Hollywood",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/",
              "description": "Sunset Marquis Studio Suites feature generous living space, work and sleep areas, pool views, and a patio or balcony in West Hollywood.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/#webpage"
              },
              "accommodationCategory": "Studio Suite"
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/#webpage",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/",
              "name": "Studio Suite in West Hollywood | Sunset Marquis",
              "description": "Sunset Marquis Studio Suites feature generous living space, work and sleep areas, pool views, and a patio or balcony in West Hollywood.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/#accommodation"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/studio-suites/#accommodation"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'one_bedroom_suite' => array(
        'label' => 'One-Bedroom Suite',
        'path' => '/west-hollywood-hotel-suites/one-bedroom-suites/',
        'path_aliases' => array( '/one-bedroom-suite/' ),
        'canonical' => 'https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/',
        'title' => 'One-Bedroom Suite in West Hollywood | Sunset Marquis',
        'description' => 'Sunset Marquis One-Bedroom Suites offer separate sleeping and living spaces, California king bedding, well-appointed baths, and many patios or balconies.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Suite + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'One-Bedroom Suite in West Hollywood | Sunset Marquis',
            'description' => 'Sunset Marquis One-Bedroom Suites offer separate sleeping and living spaces, California king bedding, well-appointed baths, and many patios or balconies.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'One-Bedroom Suite in West Hollywood | Sunset Marquis',
            'description' => 'Sunset Marquis One-Bedroom Suites offer separate sleeping and living spaces, California king bedding, well-appointed baths, and many patios or balconies.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Suites",
                  "item": "https://sunsetmarquis.com/west-hollywood-hotel-suites/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "One-Bedroom Suite",
                  "item": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/"
                }
              ]
            },
            {
              "@type": "Suite",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/#accommodation",
              "name": "One-Bedroom Suite in West Hollywood",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/",
              "description": "Sunset Marquis One-Bedroom Suites offer separate sleeping and living spaces, California king bedding, well-appointed baths, and many patios or balconies.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/#webpage"
              },
              "accommodationCategory": "One-Bedroom Suite"
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/#webpage",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/",
              "name": "One-Bedroom Suite in West Hollywood | Sunset Marquis",
              "description": "Sunset Marquis One-Bedroom Suites offer separate sleeping and living spaces, California king bedding, well-appointed baths, and many patios or balconies.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/#accommodation"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/one-bedroom-suites/#accommodation"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'king_guest_room' => array(
        'label' => 'King Guest Room',
        'path' => '/west-hollywood-hotel-suites/king-guestrooms/',
        'path_aliases' => array( '/king-guestroom/' ),
        'canonical' => 'https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/',
        'title' => 'King Guest Room in West Hollywood | Sunset Marquis',
        'description' => 'The King Guest Room at Sunset Marquis features a California king bed, workspace and thoughtful in-room amenities for a polished West Hollywood stay.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'HotelRoom + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'King Guest Room in West Hollywood | Sunset Marquis',
            'description' => 'The King Guest Room at Sunset Marquis features a California king bed, workspace and thoughtful in-room amenities for a polished West Hollywood stay.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'King Guest Room in West Hollywood | Sunset Marquis',
            'description' => 'The King Guest Room at Sunset Marquis features a California king bed, workspace and thoughtful in-room amenities for a polished West Hollywood stay.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Suites",
                  "item": "https://sunsetmarquis.com/west-hollywood-hotel-suites/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "King Guest Room",
                  "item": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/"
                }
              ]
            },
            {
              "@type": "HotelRoom",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/#accommodation",
              "name": "King Guest Room in West Hollywood",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/",
              "description": "The King Guest Room at Sunset Marquis features a California king bed, workspace and thoughtful in-room amenities for a polished West Hollywood stay.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/#webpage",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/",
              "name": "King Guest Room in West Hollywood | Sunset Marquis",
              "description": "The King Guest Room at Sunset Marquis features a California king bed, workspace and thoughtful in-room amenities for a polished West Hollywood stay.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/#accommodation"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-suites/king-guestrooms/#accommodation"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'cavatina' => array(
        'label' => 'Cavatina',
        'path' => '/cavatina-restaurant/',
        'canonical' => 'https://sunsetmarquis.com/cavatina-restaurant/',
        'title' => 'Cavatina Restaurant | Garden Dining in West Hollywood | Sunset Marquis',
        'description' => 'Dine at Cavatina, the indoor-outdoor restaurant at Sunset Marquis, with garden surroundings, seasonal menus, private dining and West Hollywood atmosphere.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Restaurant + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Cavatina Restaurant | Garden Dining in West Hollywood | Sunset Marquis',
            'description' => 'Dine at Cavatina, the indoor-outdoor restaurant at Sunset Marquis, with garden surroundings, seasonal menus, private dining and West Hollywood atmosphere.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Cavatina Restaurant | Garden Dining in West Hollywood | Sunset Marquis',
            'description' => 'Dine at Cavatina, the indoor-outdoor restaurant at Sunset Marquis, with garden surroundings, seasonal menus, private dining and West Hollywood atmosphere.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/cavatina-restaurant/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/cavatina-restaurant/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Cavatina",
                  "item": "https://sunsetmarquis.com/cavatina-restaurant/"
                }
              ]
            },
            {
              "@type": "Restaurant",
              "@id": "https://sunsetmarquis.com/cavatina-restaurant/#restaurant",
              "name": "Cavatina",
              "description": "Dine at Cavatina, the indoor-outdoor restaurant at Sunset Marquis, with garden surroundings, seasonal menus, private dining and West Hollywood atmosphere.",
              "servesCuisine": [
                "American",
                "California"
              ],
              "priceRange": "$$$",
              "acceptsReservations": true,
              "telephone": "+1-310-657-1333",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "1200 Alta Loma Road",
                "addressLocality": "West Hollywood",
                "addressRegion": "CA",
                "postalCode": "90069",
                "addressCountry": "US"
              },
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "url": "https://sunsetmarquis.com/cavatina-restaurant/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/cavatina-restaurant/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/cavatina-restaurant/#webpage",
              "url": "https://sunsetmarquis.com/cavatina-restaurant/",
              "name": "Cavatina Restaurant | Garden Dining in West Hollywood | Sunset Marquis",
              "description": "Dine at Cavatina, the indoor-outdoor restaurant at Sunset Marquis, with garden surroundings, seasonal menus, private dining and West Hollywood atmosphere.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/cavatina-restaurant/#restaurant"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/cavatina-restaurant/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/cavatina-restaurant/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/cavatina-restaurant/#restaurant"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'bar_1200' => array(
        'label' => 'BAR 1200',
        'path' => '/west-hollywood-bar-1200/',
        'path_aliases' => array( '/bar-1200/' ),
        'canonical' => 'https://sunsetmarquis.com/west-hollywood-bar-1200/',
        'title' => 'BAR 1200 | West Hollywood Cocktails & Late Nights | Sunset Marquis',
        'description' => 'BAR 1200 at Sunset Marquis is a late-night West Hollywood bar with handcrafted cocktails, intimate atmosphere and occasional live music.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'BarOrPub + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'BAR 1200 | West Hollywood Cocktails & Late Nights | Sunset Marquis',
            'description' => 'BAR 1200 at Sunset Marquis is a late-night West Hollywood bar with handcrafted cocktails, intimate atmosphere and occasional live music.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'BAR 1200 | West Hollywood Cocktails & Late Nights | Sunset Marquis',
            'description' => 'BAR 1200 at Sunset Marquis is a late-night West Hollywood bar with handcrafted cocktails, intimate atmosphere and occasional live music.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/west-hollywood-bar-1200/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/west-hollywood-bar-1200/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "BAR 1200",
                  "item": "https://sunsetmarquis.com/west-hollywood-bar-1200/"
                }
              ]
            },
            {
              "@type": "BarOrPub",
              "@id": "https://sunsetmarquis.com/west-hollywood-bar-1200/#bar",
              "name": "BAR 1200",
              "description": "BAR 1200 at Sunset Marquis is a late-night West Hollywood bar with handcrafted cocktails, intimate atmosphere and occasional live music.",
              "priceRange": "$$$",
              "telephone": "+1-310-657-1333",
              "openingHours": "Mo-Su 20:00-02:00",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "1200 Alta Loma Road",
                "addressLocality": "West Hollywood",
                "addressRegion": "CA",
                "postalCode": "90069",
                "addressCountry": "US"
              },
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "url": "https://sunsetmarquis.com/west-hollywood-bar-1200/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-bar-1200/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/west-hollywood-bar-1200/#webpage",
              "url": "https://sunsetmarquis.com/west-hollywood-bar-1200/",
              "name": "BAR 1200 | West Hollywood Cocktails & Late Nights | Sunset Marquis",
              "description": "BAR 1200 at Sunset Marquis is a late-night West Hollywood bar with handcrafted cocktails, intimate atmosphere and occasional live music.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/west-hollywood-bar-1200/#bar"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/west-hollywood-bar-1200/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-bar-1200/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/west-hollywood-bar-1200/#bar"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'nightbird_studios' => array(
        'label' => 'Nightbird Studios',
        'path' => '/nightbird-studios/',
        'canonical' => 'https://sunsetmarquis.com/nightbird-studios/',
        'title' => 'Nightbird Recording Studios | Sunset Marquis West Hollywood',
        'description' => 'Nightbird Recording Studios lives beneath Sunset Marquis near the Sunset Strip, pairing a world-class recording environment with hotel hospitality.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Organization + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Nightbird Recording Studios | Sunset Marquis West Hollywood',
            'description' => 'Nightbird Recording Studios lives beneath Sunset Marquis near the Sunset Strip, pairing a world-class recording environment with hotel hospitality.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Nightbird Recording Studios | Sunset Marquis West Hollywood',
            'description' => 'Nightbird Recording Studios lives beneath Sunset Marquis near the Sunset Strip, pairing a world-class recording environment with hotel hospitality.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/nightbird-studios/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/nightbird-studios/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Nightbird Studios",
                  "item": "https://sunsetmarquis.com/nightbird-studios/"
                }
              ]
            },
            {
              "@type": "Organization",
              "@id": "https://sunsetmarquis.com/nightbird-studios/#nightbird",
              "name": "Nightbird Recording Studios",
              "description": "Nightbird Recording Studios lives beneath Sunset Marquis near the Sunset Strip, pairing a world-class recording environment with hotel hospitality.",
              "location": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "parentOrganization": {
                "@id": "https://sunsetmarquis.com/#organization"
              },
              "url": "https://sunsetmarquis.com/nightbird-studios/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/nightbird-studios/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/nightbird-studios/#webpage",
              "url": "https://sunsetmarquis.com/nightbird-studios/",
              "name": "Nightbird Recording Studios | Sunset Marquis West Hollywood",
              "description": "Nightbird Recording Studios lives beneath Sunset Marquis near the Sunset Strip, pairing a world-class recording environment with hotel hospitality.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/nightbird-studios/#nightbird"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/nightbird-studios/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/nightbird-studios/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/nightbird-studios/#nightbird"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'morrison_hotel_gallery' => array(
        'label' => 'Morrison Hotel Gallery',
        'path' => '/morrison-hotel-gallery-los-angeles/',
        'path_aliases' => array( '/morrison-hotel-gallery-2/' ),
        'canonical' => 'https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/',
        'title' => 'Morrison Hotel Gallery | Music Photography at Sunset Marquis',
        'description' => 'Explore Morrison Hotel Gallery at Sunset Marquis, a West Hollywood showcase of iconic music photography and collectible images.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'ArtGallery + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Morrison Hotel Gallery | Music Photography at Sunset Marquis',
            'description' => 'Explore Morrison Hotel Gallery at Sunset Marquis, a West Hollywood showcase of iconic music photography and collectible images.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Morrison Hotel Gallery | Music Photography at Sunset Marquis',
            'description' => 'Explore Morrison Hotel Gallery at Sunset Marquis, a West Hollywood showcase of iconic music photography and collectible images.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Morrison Hotel Gallery",
                  "item": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/"
                }
              ]
            },
            {
              "@type": "ArtGallery",
              "@id": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/#gallery",
              "name": "Morrison Hotel Gallery",
              "description": "Explore Morrison Hotel Gallery at Sunset Marquis, a West Hollywood showcase of iconic music photography and collectible images.",
              "telephone": "+1-310-881-6025",
              "openingHours": [
                "Mo-Th 11:00-19:00",
                "Fr-Sa 11:00-21:00",
                "Su 11:00-18:00"
              ],
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "1200 Alta Loma Road",
                "addressLocality": "West Hollywood",
                "addressRegion": "CA",
                "postalCode": "90069",
                "addressCountry": "US"
              },
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "url": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/#webpage",
              "url": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/",
              "name": "Morrison Hotel Gallery | Music Photography at Sunset Marquis",
              "description": "Explore Morrison Hotel Gallery at Sunset Marquis, a West Hollywood showcase of iconic music photography and collectible images.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/#gallery"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/morrison-hotel-gallery-los-angeles/#gallery"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'spa' => array(
        'label' => 'Spa',
        'path' => '/spa-west-hollywood/',
        'path_aliases' => array( '/spa/' ),
        'canonical' => 'https://sunsetmarquis.com/spa-west-hollywood/',
        'title' => 'Spa Services in West Hollywood | Sunset Marquis',
        'description' => 'The Spa at Sunset Marquis offers thoughtful restoration through in-room spa experiences designed for privacy, comfort and deep relaxation.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'DaySpa + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Spa Services in West Hollywood | Sunset Marquis',
            'description' => 'The Spa at Sunset Marquis offers thoughtful restoration through in-room spa experiences designed for privacy, comfort and deep relaxation.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Spa Services in West Hollywood | Sunset Marquis',
            'description' => 'The Spa at Sunset Marquis offers thoughtful restoration through in-room spa experiences designed for privacy, comfort and deep relaxation.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/spa-west-hollywood/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/spa-west-hollywood/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Spa",
                  "item": "https://sunsetmarquis.com/spa-west-hollywood/"
                }
              ]
            },
            {
              "@type": "DaySpa",
              "@id": "https://sunsetmarquis.com/spa-west-hollywood/#spa",
              "name": "The Spa at Sunset Marquis",
              "description": "The Spa at Sunset Marquis offers thoughtful restoration through in-room spa experiences designed for privacy, comfort and deep relaxation.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "url": "https://sunsetmarquis.com/spa-west-hollywood/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/spa-west-hollywood/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/spa-west-hollywood/#webpage",
              "url": "https://sunsetmarquis.com/spa-west-hollywood/",
              "name": "Spa Services in West Hollywood | Sunset Marquis",
              "description": "The Spa at Sunset Marquis offers thoughtful restoration through in-room spa experiences designed for privacy, comfort and deep relaxation.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/spa-west-hollywood/#spa"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/spa-west-hollywood/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/spa-west-hollywood/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/spa-west-hollywood/#spa"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'wellness_studio' => array(
        'label' => 'Wellness Studio',
        'path' => '/equinox-west-hollywood/',
        'path_aliases' => array( '/fitness/' ),
        'canonical' => 'https://sunsetmarquis.com/equinox-west-hollywood/',
        'title' => 'Wellness Studio | Fitness at Sunset Marquis West Hollywood',
        'description' => 'The Sunset Marquis Wellness Studio offers on-property fitness, thoughtful details and a rejuvenating setting for guests in West Hollywood.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'ExerciseGym + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Wellness Studio | Fitness at Sunset Marquis West Hollywood',
            'description' => 'The Sunset Marquis Wellness Studio offers on-property fitness, thoughtful details and a rejuvenating setting for guests in West Hollywood.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Wellness Studio | Fitness at Sunset Marquis West Hollywood',
            'description' => 'The Sunset Marquis Wellness Studio offers on-property fitness, thoughtful details and a rejuvenating setting for guests in West Hollywood.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/equinox-west-hollywood/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/equinox-west-hollywood/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Wellness Studio",
                  "item": "https://sunsetmarquis.com/equinox-west-hollywood/"
                }
              ]
            },
            {
              "@type": "ExerciseGym",
              "@id": "https://sunsetmarquis.com/equinox-west-hollywood/#wellness-studio",
              "name": "Sunset Marquis Wellness Studio",
              "description": "The Sunset Marquis Wellness Studio offers on-property fitness, thoughtful details and a rejuvenating setting for guests in West Hollywood.",
              "containedInPlace": {
                "@id": "https://sunsetmarquis.com/#hotel"
              },
              "url": "https://sunsetmarquis.com/equinox-west-hollywood/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/equinox-west-hollywood/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/equinox-west-hollywood/#webpage",
              "url": "https://sunsetmarquis.com/equinox-west-hollywood/",
              "name": "Wellness Studio | Fitness at Sunset Marquis West Hollywood",
              "description": "The Sunset Marquis Wellness Studio offers on-property fitness, thoughtful details and a rejuvenating setting for guests in West Hollywood.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/equinox-west-hollywood/#wellness-studio"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/equinox-west-hollywood/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/equinox-west-hollywood/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/equinox-west-hollywood/#wellness-studio"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'concierge' => array(
        'label' => 'Concierge',
        'path' => '/about-west-hollywood-hotel/concierge/',
        'canonical' => 'https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/',
        'title' => 'Concierge Services | Sunset Marquis West Hollywood',
        'description' => 'The Les Clefs d\'Or concierge team at Sunset Marquis helps plan transportation, reservations, tickets, tours, wellness services and unforgettable LA experiences.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Service + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Concierge Services | Sunset Marquis West Hollywood',
            'description' => 'The Les Clefs d\'Or concierge team at Sunset Marquis helps plan transportation, reservations, tickets, tours, wellness services and unforgettable LA experiences.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Concierge Services | Sunset Marquis West Hollywood',
            'description' => 'The Les Clefs d\'Or concierge team at Sunset Marquis helps plan transportation, reservations, tickets, tours, wellness services and unforgettable LA experiences.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Concierge",
                  "item": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/"
                }
              ]
            },
            {
              "@type": "Service",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/#service",
              "name": "Sunset Marquis Concierge Services",
              "serviceType": "Hotel concierge service",
              "provider": {
                "@id": "https://sunsetmarquis.com/#organization"
              },
              "areaServed": "Los Angeles, California",
              "description": "The Les Clefs d'Or concierge team at Sunset Marquis helps plan transportation, reservations, tickets, tours, wellness services and unforgettable LA experiences.",
              "url": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/#webpage",
              "url": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/",
              "name": "Concierge Services | Sunset Marquis West Hollywood",
              "description": "The Les Clefs d'Or concierge team at Sunset Marquis helps plan transportation, reservations, tickets, tours, wellness services and unforgettable LA experiences.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/#service"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/concierge/#service"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'ev_charging' => array(
        'label' => 'EV Charging',
        'path' => '/los-angeles-electric-vehicles/',
        'canonical' => 'https://sunsetmarquis.com/los-angeles-electric-vehicles/',
        'title' => 'EV Charging Hotel in West Hollywood | Sunset Marquis',
        'description' => 'Sunset Marquis offers on-property EV charging in West Hollywood, including six Tesla charging stations and two universal charging stations.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Service + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'EV Charging Hotel in West Hollywood | Sunset Marquis',
            'description' => 'Sunset Marquis offers on-property EV charging in West Hollywood, including six Tesla charging stations and two universal charging stations.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'EV Charging Hotel in West Hollywood | Sunset Marquis',
            'description' => 'Sunset Marquis offers on-property EV charging in West Hollywood, including six Tesla charging stations and two universal charging stations.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/los-angeles-electric-vehicles/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/los-angeles-electric-vehicles/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "EV Charging",
                  "item": "https://sunsetmarquis.com/los-angeles-electric-vehicles/"
                }
              ]
            },
            {
              "@type": "Service",
              "@id": "https://sunsetmarquis.com/los-angeles-electric-vehicles/#service",
              "name": "Electric Vehicle Charging at Sunset Marquis",
              "serviceType": "Electric vehicle charging",
              "provider": {
                "@id": "https://sunsetmarquis.com/#organization"
              },
              "areaServed": "Los Angeles, California",
              "description": "Sunset Marquis offers on-property EV charging in West Hollywood, including six Tesla charging stations and two universal charging stations.",
              "url": "https://sunsetmarquis.com/los-angeles-electric-vehicles/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/los-angeles-electric-vehicles/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/los-angeles-electric-vehicles/#webpage",
              "url": "https://sunsetmarquis.com/los-angeles-electric-vehicles/",
              "name": "EV Charging Hotel in West Hollywood | Sunset Marquis",
              "description": "Sunset Marquis offers on-property EV charging in West Hollywood, including six Tesla charging stations and two universal charging stations.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/los-angeles-electric-vehicles/#service"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/los-angeles-electric-vehicles/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/los-angeles-electric-vehicles/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/los-angeles-electric-vehicles/#service"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'weddings' => array(
        'label' => 'Weddings',
        'path' => '/hollywood-wedding-venue/',
        'path_aliases' => array( '/weddings/' ),
        'canonical' => 'https://sunsetmarquis.com/hollywood-wedding-venue/',
        'title' => 'West Hollywood Wedding Venue | Sunset Marquis',
        'description' => 'Plan a West Hollywood wedding at Sunset Marquis with garden spaces, suites and villas, intimate celebrations and a storied setting near the Sunset Strip.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Service + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'West Hollywood Wedding Venue | Sunset Marquis',
            'description' => 'Plan a West Hollywood wedding at Sunset Marquis with garden spaces, suites and villas, intimate celebrations and a storied setting near the Sunset Strip.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'West Hollywood Wedding Venue | Sunset Marquis',
            'description' => 'Plan a West Hollywood wedding at Sunset Marquis with garden spaces, suites and villas, intimate celebrations and a storied setting near the Sunset Strip.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/hollywood-wedding-venue/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/hollywood-wedding-venue/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Weddings",
                  "item": "https://sunsetmarquis.com/hollywood-wedding-venue/"
                }
              ]
            },
            {
              "@type": "Service",
              "@id": "https://sunsetmarquis.com/hollywood-wedding-venue/#service",
              "name": "Sunset Marquis Weddings",
              "serviceType": "Wedding venue and planning",
              "provider": {
                "@id": "https://sunsetmarquis.com/#organization"
              },
              "areaServed": "Los Angeles, California",
              "description": "Plan a West Hollywood wedding at Sunset Marquis with garden spaces, suites and villas, intimate celebrations and a storied setting near the Sunset Strip.",
              "url": "https://sunsetmarquis.com/hollywood-wedding-venue/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/hollywood-wedding-venue/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/hollywood-wedding-venue/#webpage",
              "url": "https://sunsetmarquis.com/hollywood-wedding-venue/",
              "name": "West Hollywood Wedding Venue | Sunset Marquis",
              "description": "Plan a West Hollywood wedding at Sunset Marquis with garden spaces, suites and villas, intimate celebrations and a storied setting near the Sunset Strip.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/hollywood-wedding-venue/#service"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/hollywood-wedding-venue/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/hollywood-wedding-venue/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/hollywood-wedding-venue/#service"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'private_events' => array(
        'label' => 'Private Events',
        'path' => '/west-hollywood-hotel-events/',
        'path_aliases' => array( '/event-venues/' ),
        'canonical' => 'https://sunsetmarquis.com/west-hollywood-hotel-events/',
        'title' => 'Private Event Venues in West Hollywood | Sunset Marquis',
        'description' => 'Host private events at Sunset Marquis with flexible West Hollywood venues, Cavatina catering, BAR 1200 gatherings, poolside spaces and experienced planning.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'Service + WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Private Event Venues in West Hollywood | Sunset Marquis',
            'description' => 'Host private events at Sunset Marquis with flexible West Hollywood venues, Cavatina catering, BAR 1200 gatherings, poolside spaces and experienced planning.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Private Event Venues in West Hollywood | Sunset Marquis',
            'description' => 'Host private events at Sunset Marquis with flexible West Hollywood venues, Cavatina catering, BAR 1200 gatherings, poolside spaces and experienced planning.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-events/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-events/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Private Events",
                  "item": "https://sunsetmarquis.com/west-hollywood-hotel-events/"
                }
              ]
            },
            {
              "@type": "Service",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-events/#service",
              "name": "Sunset Marquis Private Events",
              "serviceType": "Private event venues and planning",
              "provider": {
                "@id": "https://sunsetmarquis.com/#organization"
              },
              "areaServed": "Los Angeles, California",
              "description": "Host private events at Sunset Marquis with flexible West Hollywood venues, Cavatina catering, BAR 1200 gatherings, poolside spaces and experienced planning.",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-events/",
              "mainEntityOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-events/#webpage"
              }
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-events/#webpage",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-events/",
              "name": "Private Event Venues in West Hollywood | Sunset Marquis",
              "description": "Host private events at Sunset Marquis with flexible West Hollywood venues, Cavatina catering, BAR 1200 gatherings, poolside spaces and experienced planning.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "about": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-events/#service"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-events/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-events/#primaryimage"
              },
              "mainEntity": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-events/#service"
              },
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'local_attractions' => array(
        'label' => 'Local Attractions',
        'path' => '/things-to-do-in-hollywood/',
        'path_aliases' => array( '/local-attractions/' ),
        'canonical' => 'https://sunsetmarquis.com/things-to-do-in-hollywood/',
        'title' => 'Things to Do in West Hollywood | Sunset Marquis Local Guide',
        'description' => 'Explore Sunset Marquis\' West Hollywood guide to dining, nightlife, culture and nearby attractions, with concierge help for planning your stay.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'CollectionPage + BreadcrumbList',
        'og' => array(
            'title' => 'Things to Do in West Hollywood | Sunset Marquis Local Guide',
            'description' => 'Explore Sunset Marquis\' West Hollywood guide to dining, nightlife, culture and nearby attractions, with concierge help for planning your stay.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Things to Do in West Hollywood | Sunset Marquis Local Guide',
            'description' => 'Explore Sunset Marquis\' West Hollywood guide to dining, nightlife, culture and nearby attractions, with concierge help for planning your stay.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/things-to-do-in-hollywood/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/things-to-do-in-hollywood/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Local Attractions",
                  "item": "https://sunsetmarquis.com/things-to-do-in-hollywood/"
                }
              ]
            },
            {
              "@type": "CollectionPage",
              "@id": "https://sunsetmarquis.com/things-to-do-in-hollywood/#webpage",
              "url": "https://sunsetmarquis.com/things-to-do-in-hollywood/",
              "name": "Things to Do in West Hollywood | Sunset Marquis Local Guide",
              "description": "Explore Sunset Marquis' West Hollywood guide to dining, nightlife, culture and nearby attractions, with concierge help for planning your stay.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/things-to-do-in-hollywood/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/things-to-do-in-hollywood/#primaryimage"
              },
              "inLanguage": "en-US",
              "about": {
                "@id": "https://sunsetmarquis.com/#hotel"
              }
            }
          ]
        }
JSON
    ),
    'offers' => array(
        'label' => 'Offers',
        'path' => '/category/offers/',
        'canonical' => 'https://sunsetmarquis.com/category/offers/',
        'title' => 'Sunset Marquis Offers | West Hollywood Hotel Packages',
        'description' => 'Browse current Sunset Marquis hotel offers, packages and stay experiences for suites, villas, dining and longer West Hollywood getaways.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'CollectionPage + BreadcrumbList',
        'og' => array(
            'title' => 'Sunset Marquis Offers | West Hollywood Hotel Packages',
            'description' => 'Browse current Sunset Marquis hotel offers, packages and stay experiences for suites, villas, dining and longer West Hollywood getaways.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Sunset Marquis Offers | West Hollywood Hotel Packages',
            'description' => 'Browse current Sunset Marquis hotel offers, packages and stay experiences for suites, villas, dining and longer West Hollywood getaways.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/category/offers/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/category/offers/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Offers",
                  "item": "https://sunsetmarquis.com/category/offers/"
                }
              ]
            },
            {
              "@type": "CollectionPage",
              "@id": "https://sunsetmarquis.com/category/offers/#webpage",
              "url": "https://sunsetmarquis.com/category/offers/",
              "name": "Sunset Marquis Offers | West Hollywood Hotel Packages",
              "description": "Browse current Sunset Marquis hotel offers, packages and stay experiences for suites, villas, dining and longer West Hollywood getaways.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/category/offers/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/category/offers/#primaryimage"
              },
              "inLanguage": "en-US",
              "about": {
                "@id": "https://sunsetmarquis.com/#hotel"
              }
            }
          ]
        }
JSON
    ),
    'fifa_soccer_landing' => array(
        'label' => 'FIFA / 2026 Soccer Landing Page',
        'path' => '/los-angeles-soccer-2026-hotel/',
        'canonical' => 'https://sunsetmarquis.com/los-angeles-soccer-2026-hotel/',
        'title' => 'FIFA World Cup 2026 Los Angeles Hotel | Sunset Marquis',
        'description' => 'Stay at Sunset Marquis in West Hollywood for FIFA World Cup 2026 Los Angeles match days at SoFi Stadium, with villas, suites, dining and concierge support.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'WebPage + BreadcrumbList, with optional FAQPage only if the visible FAQ section is implemented',
        'og' => array(
            'title' => 'FIFA World Cup 2026 Los Angeles Hotel | Sunset Marquis',
            'description' => 'Stay at Sunset Marquis in West Hollywood for FIFA World Cup 2026 Los Angeles match days at SoFi Stadium, with villas, suites, dining and concierge support.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'FIFA World Cup 2026 Los Angeles Hotel | Sunset Marquis',
            'description' => 'Stay at Sunset Marquis in West Hollywood for FIFA World Cup 2026 Los Angeles match days at SoFi Stadium, with villas, suites, dining and concierge support.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/los-angeles-soccer-2026-hotel/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/los-angeles-soccer-2026-hotel/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "2026 Los Angeles Soccer Stays",
                  "item": "https://sunsetmarquis.com/los-angeles-soccer-2026-hotel/"
                }
              ]
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/los-angeles-soccer-2026-hotel/#webpage",
              "url": "https://sunsetmarquis.com/los-angeles-soccer-2026-hotel/",
              "name": "FIFA World Cup 2026 Los Angeles Hotel | Sunset Marquis",
              "description": "Stay at Sunset Marquis in West Hollywood for FIFA World Cup 2026 Los Angeles match days at SoFi Stadium, with villas, suites, dining and concierge support.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/los-angeles-soccer-2026-hotel/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/los-angeles-soccer-2026-hotel/#primaryimage"
              },
              "inLanguage": "en-US",
              "about": {
                "@id": "https://sunsetmarquis.com/#hotel"
              }
            }
          ]
        }
JSON
    ),
    'faq' => array(
        'label' => 'FAQ Page',
        'path' => '/west-hollywood-hotel-faqs/',
        'canonical' => 'https://sunsetmarquis.com/west-hollywood-hotel-faqs/',
        'title' => 'Sunset Marquis FAQs | West Hollywood Hotel Information',
        'description' => 'Find answers about Sunset Marquis reservations, dining, pools, pet policy, hotel facilities, room count, check-in and West Hollywood location.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'FAQPage + BreadcrumbList',
        'og' => array(
            'title' => 'Sunset Marquis FAQs | West Hollywood Hotel Information',
            'description' => 'Find answers about Sunset Marquis reservations, dining, pools, pet policy, hotel facilities, room count, check-in and West Hollywood location.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Sunset Marquis FAQs | West Hollywood Hotel Information',
            'description' => 'Find answers about Sunset Marquis reservations, dining, pools, pet policy, hotel facilities, room count, check-in and West Hollywood location.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-faqs/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-faqs/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "FAQs",
                  "item": "https://sunsetmarquis.com/west-hollywood-hotel-faqs/"
                }
              ]
            },
            {
              "@type": "FAQPage",
              "@id": "https://sunsetmarquis.com/west-hollywood-hotel-faqs/#webpage",
              "url": "https://sunsetmarquis.com/west-hollywood-hotel-faqs/",
              "name": "Sunset Marquis FAQs | West Hollywood Hotel Information",
              "description": "Find answers about Sunset Marquis reservations, dining, pools, pet policy, hotel facilities, room count, check-in and West Hollywood location.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-faqs/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/west-hollywood-hotel-faqs/#primaryimage"
              },
              "mainEntity": [
                {
                  "@type": "Question",
                  "name": "Where is the Sunset Marquis located?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Sunset Marquis is located at 1200 Alta Loma Road, West Hollywood, CA 90069, in the center of West Hollywood between Beverly Hills and Hollywood."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How do I make a reservation at the Sunset Marquis?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Guests can book through the Sunset Marquis website or call 800-858-9758."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Does the Sunset Marquis have a restaurant?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes. Cavatina is the restaurant at Sunset Marquis and serves breakfast, lunch and dinner in a garden-surrounded indoor-outdoor setting."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Does the Sunset Marquis have a pool?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Yes. Sunset Marquis has two full-sized outdoor heated pools, including the lobby pool and the villa pool."
                  }
                },
                {
                  "@type": "Question",
                  "name": "How many rooms are there at the Sunset Marquis?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Sunset Marquis has 152 total accommodations, divided between 100 suites and 52 villas."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What are check-in and check-out times at Sunset Marquis?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Check-in is at 3:00 PM and check-out is at 12:00 PM. Early check-in may be requested based on availability."
                  }
                },
                {
                  "@type": "Question",
                  "name": "Does Sunset Marquis allow pets?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Sunset Marquis accepts small dogs 15 pounds or under, subject to the hotel pet policy. The property allows a maximum of two dogs per room."
                  }
                },
                {
                  "@type": "Question",
                  "name": "What clubs are close to the Sunset Marquis?",
                  "acceptedAnswer": {
                    "@type": "Answer",
                    "text": "Sunset Marquis is steps from the Sunset Strip and near clubs and nightlife venues such as BAR 1200, Whisky a Go Go, The Roxy and The Abbey."
                  }
                }
              ],
              "inLanguage": "en-US"
            }
          ]
        }
JSON
    ),
    'history' => array(
        'label' => 'History',
        'path' => '/about-west-hollywood-hotel/history/',
        'path_aliases' => array( '/history/' ),
        'canonical' => 'https://sunsetmarquis.com/about-west-hollywood-hotel/history/',
        'title' => 'Sunset Marquis History | Rock & Roll Hotel in West Hollywood',
        'description' => 'Discover the history of Sunset Marquis, the West Hollywood hideaway connected to rock and roll, Hollywood culture and decades of legendary guests.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'Sunset Marquis History | Rock & Roll Hotel in West Hollywood',
            'description' => 'Discover the history of Sunset Marquis, the West Hollywood hideaway connected to rock and roll, Hollywood culture and decades of legendary guests.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'Sunset Marquis History | Rock & Roll Hotel in West Hollywood',
            'description' => 'Discover the history of Sunset Marquis, the West Hollywood hideaway connected to rock and roll, Hollywood culture and decades of legendary guests.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/history/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/history/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "About",
                  "item": "https://sunsetmarquis.com/about-west-hollywood-hotel/"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": "History",
                  "item": "https://sunsetmarquis.com/about-west-hollywood-hotel/history/"
                }
              ]
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/history/#webpage",
              "url": "https://sunsetmarquis.com/about-west-hollywood-hotel/history/",
              "name": "Sunset Marquis History | Rock & Roll Hotel in West Hollywood",
              "description": "Discover the history of Sunset Marquis, the West Hollywood hideaway connected to rock and roll, Hollywood culture and decades of legendary guests.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/history/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/history/#primaryimage"
              },
              "inLanguage": "en-US",
              "about": {
                "@id": "https://sunsetmarquis.com/#hotel"
              }
            }
          ]
        }
JSON
    ),
    'about' => array(
        'label' => 'About',
        'path' => '/about-west-hollywood-hotel/',
        'canonical' => 'https://sunsetmarquis.com/about-west-hollywood-hotel/',
        'title' => 'About Sunset Marquis | West Hollywood Hotel & Villas',
        'description' => 'Learn about Sunset Marquis Hotel & Villas, a West Hollywood retreat with suites, private villas, gardens, Cavatina, BAR 1200, spa experiences and music history.',
        'robots_preset' => 'index_follow',
        'schema_label' => 'WebPage + BreadcrumbList',
        'og' => array(
            'title' => 'About Sunset Marquis | West Hollywood Hotel & Villas',
            'description' => 'Learn about Sunset Marquis Hotel & Villas, a West Hollywood retreat with suites, private villas, gardens, Cavatina, BAR 1200, spa experiences and music history.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'twitter' => array(
            'card' => 'summary_large_image',
            'title' => 'About Sunset Marquis | West Hollywood Hotel & Villas',
            'description' => 'Learn about Sunset Marquis Hotel & Villas, a West Hollywood retreat with suites, private villas, gardens, Cavatina, BAR 1200, spa experiences and music history.',
            'image' => 'https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg',
            'image_alt' => 'Sunset Marquis Hotel & Villas in West Hollywood, California',
        ),
        'schema_json' => <<<'JSON'
        {
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "ImageObject",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/#primaryimage",
              "url": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "contentUrl": "https://sunsetmarquis.com/wp-content/uploads/2023/07/smimage.jpg",
              "width": 1200,
              "height": 630,
              "caption": "Sunset Marquis Hotel & Villas in West Hollywood, California",
              "inLanguage": "en-US"
            },
            {
              "@type": "BreadcrumbList",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/#breadcrumb",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://sunsetmarquis.com/"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "About",
                  "item": "https://sunsetmarquis.com/about-west-hollywood-hotel/"
                }
              ]
            },
            {
              "@type": "WebPage",
              "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/#webpage",
              "url": "https://sunsetmarquis.com/about-west-hollywood-hotel/",
              "name": "About Sunset Marquis | West Hollywood Hotel & Villas",
              "description": "Learn about Sunset Marquis Hotel & Villas, a West Hollywood retreat with suites, private villas, gardens, Cavatina, BAR 1200, spa experiences and music history.",
              "isPartOf": {
                "@id": "https://sunsetmarquis.com/#website"
              },
              "breadcrumb": {
                "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/#breadcrumb"
              },
              "primaryImageOfPage": {
                "@id": "https://sunsetmarquis.com/about-west-hollywood-hotel/#primaryimage"
              },
              "inLanguage": "en-US",
              "about": {
                "@id": "https://sunsetmarquis.com/#hotel"
              }
            }
          ]
        }
JSON
    ),
);
