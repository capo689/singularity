<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Sitemap_Manager {
    private $registry;
    private $robots_manager;

    public function __construct( Registry $registry, Robots_Manager $robots_manager ) {
        $this->registry = $registry;
        $this->robots_manager = $robots_manager;

        add_filter( 'wp_sitemaps_posts_query_args', array( $this, 'exclude_noindex_managed_pages' ), 20, 2 );
        add_filter( 'wp_sitemaps_taxonomies_query_args', array( $this, 'exclude_noindex_managed_terms' ), 20, 2 );
    }

    public function exclude_noindex_managed_pages( $args, $post_type ) {
        if ( ! in_array( $post_type, array( 'page', 'post' ), true ) ) {
            return $args;
        }

        $exclude_ids = $this->get_noindex_managed_post_ids();

        if ( empty( $exclude_ids ) ) {
            return $args;
        }

        $existing = isset( $args['post__not_in'] ) && is_array( $args['post__not_in'] )
            ? $args['post__not_in']
            : array();

        $args['post__not_in'] = array_values( array_unique( array_merge( $existing, $exclude_ids ) ) );

        return $args;
    }

    public function exclude_noindex_managed_terms( $args, $taxonomy ) {
        $exclude_ids = $this->get_noindex_managed_term_ids( $taxonomy );

        if ( empty( $exclude_ids ) ) {
            return $args;
        }

        $existing = isset( $args['exclude'] ) ? wp_parse_id_list( $args['exclude'] ) : array();
        $args['exclude'] = array_values( array_unique( array_merge( $existing, $exclude_ids ) ) );

        return $args;
    }

    public function get_noindex_managed_post_ids() {
        $ids = array();

        foreach ( $this->registry->keys() as $key ) {
            $page = $this->registry->get_effective( $key );

            if ( ! is_array( $page ) ) {
                continue;
            }

            $preset = isset( $page['robots_preset'] ) ? $page['robots_preset'] : 'index_follow';

            if ( ! $this->robots_manager->is_noindex_preset( $preset ) ) {
                continue;
            }

            $post_id = $this->registry->resolve_post_id( $page );

            if ( $post_id > 0 ) {
                $ids[] = $post_id;
            }
        }

        return array_values( array_unique( array_map( 'intval', $ids ) ) );
    }

    public function get_noindex_managed_term_ids( $taxonomy ) {
        $ids = array();

        if ( 'category' !== $taxonomy ) {
            return $ids;
        }

        foreach ( $this->registry->keys() as $key ) {
            $page = $this->registry->get_effective( $key );

            if ( ! is_array( $page ) ) {
                continue;
            }

            $preset = isset( $page['robots_preset'] ) ? $page['robots_preset'] : 'index_follow';

            if ( ! $this->robots_manager->is_noindex_preset( $preset ) ) {
                continue;
            }

            $path = isset( $page['path'] ) ? $this->registry->normalize_path( $page['path'] ) : '';

            if ( ! preg_match( '#^/category/([^/]+)/$#', $path, $matches ) ) {
                continue;
            }

            $term = get_term_by( 'slug', sanitize_title( $matches[1] ), 'category' );

            if ( $term instanceof \WP_Term ) {
                $ids[] = (int) $term->term_id;
            }
        }

        return array_values( array_unique( array_map( 'intval', $ids ) ) );
    }

    public function page_sitemap_status( $page ) {
        if ( ! is_array( $page ) ) {
            return 'Unknown';
        }

        $preset = isset( $page['robots_preset'] ) ? $page['robots_preset'] : 'index_follow';

        if ( $this->robots_manager->is_noindex_preset( $preset ) ) {
            return 'Excluded by noindex robots policy';
        }

        $post_id = $this->registry->resolve_post_id( $page );

        if ( $post_id > 0 ) {
            return 'Eligible for WordPress sitemap';
        }

        return 'Path/archive match; not resolved as singular sitemap entry';
    }
}
