<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Title_Manager {
    private $context;

    public function __construct( Context $context ) {
        $this->context = $context;
        add_filter( 'pre_get_document_title', array( $this, 'filter_title' ), PHP_INT_MAX );
    }

    public function filter_title( $title ) {
        if ( ! $this->context->is_frontend_render_context() ) {
            return $title;
        }

        $page = $this->context->current_managed_page();

        if ( is_array( $page ) && ! empty( $page['title'] ) ) {
            return $page['title'];
        }

        return $title;
    }
}
