<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Schema_Renderer {
    private $context;

    public function __construct( Context $context ) {
        $this->context = $context;
        add_action( 'wp_head', array( $this, 'render' ), 20 );
    }

    public function render() {
        if ( ! $this->context->is_frontend_render_context() ) {
            return;
        }

        $page = $this->context->current_managed_page();

        if ( is_array( $page ) && ! empty( $page['schema_json'] ) ) {
            $this->render_schema_json( $this->schema_json_for_managed_page( $page ), 'Managed' );
            return;
        }

        $fallback = $this->get_fallback_schema();

        if ( ! empty( $fallback ) ) {
            $this->render_schema_json( wp_json_encode( $fallback, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ), 'Fallback' );
        }
    }

    private function schema_json_for_managed_page( $page ) {
        $json = isset( $page['schema_json'] ) ? trim( (string) $page['schema_json'] ) : '';

        if ( '' === $json ) {
            return $json;
        }

        $decoded = json_decode( $json, true );

        if ( ! is_array( $decoded ) ) {
            return $json;
        }

        $replacements = array();
        $default_title = isset( $page['_default_title'] ) ? (string) $page['_default_title'] : '';
        $current_title = isset( $page['title'] ) ? (string) $page['title'] : '';
        $default_description = isset( $page['_default_description'] ) ? (string) $page['_default_description'] : '';
        $current_description = isset( $page['description'] ) ? (string) $page['description'] : '';

        if ( '' !== $default_title && '' !== $current_title && $default_title !== $current_title ) {
            $replacements[ $default_title ] = $current_title;
        }

        if ( '' !== $default_description && '' !== $current_description && $default_description !== $current_description ) {
            $replacements[ $default_description ] = $current_description;
        }

        if ( empty( $replacements ) ) {
            return $json;
        }

        $decoded = $this->replace_exact_string_values_recursive( $decoded, $replacements );
        $encoded = wp_json_encode( $decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );

        return $encoded ? $encoded : $json;
    }

    private function replace_exact_string_values_recursive( $value, $replacements ) {
        if ( is_array( $value ) ) {
            foreach ( $value as $key => $child ) {
                $value[ $key ] = $this->replace_exact_string_values_recursive( $child, $replacements );
            }

            return $value;
        }

        if ( is_string( $value ) && isset( $replacements[ $value ] ) ) {
            return $replacements[ $value ];
        }

        return $value;
    }

    private function render_schema_json( $json, $label ) {
        $json = trim( (string) $json );

        if ( '' === $json ) {
            return;
        }

        echo "\n<!-- Singularity SEO: " . esc_html( $label ) . " Schema -->\n";
        echo '<script type="application/ld+json">' . "\n";
        echo $json . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON is plugin-owned configuration.
        echo '</script>' . "\n";
        echo "<!-- /Singularity SEO: " . esc_html( $label ) . " Schema -->\n";
    }

    private function get_fallback_schema() {
        if ( ! is_singular() ) {
            return array();
        }

        global $post;

        if ( ! $post instanceof \WP_Post ) {
            return array();
        }

        $url = get_permalink( $post );
        $title = get_the_title( $post );

        if ( ! $url || '' === $title ) {
            return array();
        }

        if ( 'post' === get_post_type( $post ) ) {
            return array(
                '@context' => 'https://schema.org',
                '@type' => 'Article',
                'headline' => $title,
                'url' => $url,
                'datePublished' => get_the_date( DATE_W3C, $post ),
                'dateModified' => get_the_modified_date( DATE_W3C, $post ),
                'mainEntityOfPage' => array(
                    '@type' => 'WebPage',
                    '@id' => $url,
                ),
            );
        }

        return array(
            '@context' => 'https://schema.org',
            '@type' => 'WebPage',
            'name' => $title,
            'url' => $url,
            'mainEntityOfPage' => $url,
        );
    }
}
