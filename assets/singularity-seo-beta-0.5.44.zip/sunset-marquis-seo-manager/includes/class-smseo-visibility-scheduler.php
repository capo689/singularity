<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Visibility_Scheduler {
    const HOOK = 'smseo_daily_visibility_snapshot';
    const LAST_RUN_OPTION = 'smseo_daily_visibility_last_run';
    const LAST_ERROR_OPTION = 'smseo_daily_visibility_last_error';

    public function __construct() {
        add_action( self::HOOK, array( $this, 'run_scheduled_snapshot' ) );
        self::schedule();
    }

    public static function schedule() {
        if ( ! wp_next_scheduled( self::HOOK ) ) {
            wp_schedule_event( time() + ( 2 * HOUR_IN_SECONDS ), 'daily', self::HOOK );
        }
    }

    public static function unschedule() {
        $timestamp = wp_next_scheduled( self::HOOK );
        while ( $timestamp ) {
            wp_unschedule_event( $timestamp, self::HOOK );
            $timestamp = wp_next_scheduled( self::HOOK );
        }
    }

    public static function status() {
        $next_run = wp_next_scheduled( self::HOOK );

        return array(
            'enabled'      => (bool) $next_run,
            'schedule'     => 'daily',
            'next_run_gmt' => $next_run ? gmdate( 'Y-m-d H:i:s', $next_run ) : '',
            'last_run_gmt' => (string) get_option( self::LAST_RUN_OPTION, '' ),
            'last_error'   => (string) get_option( self::LAST_ERROR_OPTION, '' ),
        );
    }

    public function run_scheduled_snapshot() {
        try {
            $visibility_store = new Visibility_Store();
            $refreshed = $this->refresh_hosted_search_console();
            if ( ! $refreshed ) {
                $visibility_store->create_snapshot( 'daily_cron' );
            }
            update_option( self::LAST_RUN_OPTION, current_time( 'mysql', true ), false );
            delete_option( self::LAST_ERROR_OPTION );
        } catch ( \Throwable $throwable ) {
            update_option( self::LAST_ERROR_OPTION, $throwable->getMessage(), false );
        }
    }

    public function run_search_console_refresh_now() {
        try {
            $config = ( new Visibility_Store() )->get_config();
            if ( empty( $config['google_search_console_connected'] ) ) {
                throw new \RuntimeException( 'Search Console is not connected.' );
            }

            $refreshed = $this->refresh_hosted_search_console();
            if ( ! $refreshed ) {
                throw new \RuntimeException( 'Search Console refresh did not run. Confirm the hosted connection, customer ID and bridge token are configured.' );
            }

            update_option( self::LAST_RUN_OPTION, current_time( 'mysql', true ), false );
            delete_option( self::LAST_ERROR_OPTION );

            return array(
                'ok'      => true,
                'message' => 'Search Console refreshed successfully.',
                'status'  => self::status(),
            );
        } catch ( \Throwable $throwable ) {
            update_option( self::LAST_ERROR_OPTION, $throwable->getMessage(), false );

            return array(
                'ok'      => false,
                'message' => $throwable->getMessage(),
                'status'  => self::status(),
            );
        }
    }

    private function refresh_hosted_search_console() {
        $config = ( new Visibility_Store() )->get_config();
        if ( empty( $config['google_search_console_connected'] ) ) {
            return false;
        }

        $customer_id = sanitize_key( (string) get_option( Admin::CUSTOMER_ID_OPTION, '' ) );
        $controller_url = trim( (string) get_option( Admin::CONTROLLER_URL_OPTION, 'https://controller-nq6p.onrender.com/sse/' ) );
        $origin = $this->controller_origin( $controller_url );
        $token = trim( (string) get_option( API::BRIDGE_TOKEN_OPTION, '' ) );
        if ( '' === $customer_id || '' === $origin || strlen( $token ) < 24 ) {
            return false;
        }

        $site_url = home_url( '/' );
        $timestamp = (string) time();
        $message = $customer_id . '|' . $timestamp . '|' . $site_url;
        $response = wp_remote_post(
            $origin . '/integrations/google/search-console/refresh',
            array(
                'timeout' => 20,
                'headers' => array(
                    'Accept' => 'application/json',
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode(
                    array(
                        'customer_id' => $customer_id,
                        'site_url' => $site_url,
                        'ts' => $timestamp,
                        'signature' => hash_hmac( 'sha256', $message, $token ),
                    )
                ),
            )
        );

        if ( is_wp_error( $response ) ) {
            throw new \RuntimeException( 'Search Console refresh failed: ' . $response->get_error_message() );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        if ( $code >= 400 ) {
            $detail = $this->response_error_detail( $response );
            throw new \RuntimeException( 'Search Console refresh returned HTTP ' . $code . ( '' !== $detail ? ': ' . $detail : '.' ) );
        }

        $body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        return is_array( $body ) && ! empty( $body['ok'] );
    }

    private function response_error_detail( $response ) {
        $body = (string) wp_remote_retrieve_body( $response );
        if ( '' === trim( $body ) ) {
            return '';
        }

        $decoded = json_decode( $body, true );
        if ( is_array( $decoded ) ) {
            foreach ( array( 'message', 'error_description', 'error' ) as $key ) {
                if ( ! empty( $decoded[ $key ] ) && is_scalar( $decoded[ $key ] ) ) {
                    return $this->clean_error_detail( (string) $decoded[ $key ] );
                }
            }
        }

        return $this->clean_error_detail( $body );
    }

    private function clean_error_detail( $message ) {
        $message = wp_strip_all_tags( (string) $message );
        $message = preg_replace( '/\s+/', ' ', $message );
        $message = trim( $message );

        if ( strlen( $message ) > 500 ) {
            $message = substr( $message, 0, 497 ) . '...';
        }

        return $message;
    }

    private function controller_origin( $controller_url ) {
        $parts = wp_parse_url( (string) $controller_url );
        if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
            return '';
        }

        $port = isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '';
        return $parts['scheme'] . '://' . $parts['host'] . $port;
    }
}
