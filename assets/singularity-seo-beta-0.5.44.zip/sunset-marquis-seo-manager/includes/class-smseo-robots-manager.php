<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Robots_Manager {
    private $context;
    private $registry;

    public function __construct( Context $context, Registry $registry ) {
        $this->context = $context;
        $this->registry = $registry;
        add_filter( 'wp_robots', array( $this, 'filter_robots' ), 999 );
    }

    public function filter_robots( $robots ) {
        if ( ! $this->context->is_frontend_render_context() ) {
            return $robots;
        }

        // Respect WordPress' global "Discourage search engines" setting.
        if ( '0' === (string) get_option( 'blog_public' ) ) {
            return $robots;
        }

        $page = $this->context->current_managed_page();

        if ( ! is_array( $page ) ) {
            return $robots;
        }

        $preset = isset( $page['robots_preset'] ) ? $page['robots_preset'] : 'index_follow';

        return $this->directives_for_preset( $preset );
    }

    public function directives_for_preset( $preset ) {
        switch ( $preset ) {
            case 'noindex_nofollow':
                return array(
                    'noindex' => true,
                    'nofollow' => true,
                    'max-snippet' => -1,
                    'max-video-preview' => -1,
                    'max-image-preview' => 'large',
                );

            case 'noindex_follow':
                return array(
                    'noindex' => true,
                    'follow' => true,
                    'max-snippet' => -1,
                    'max-video-preview' => -1,
                    'max-image-preview' => 'large',
                );

            case 'index_follow':
            default:
                return array(
                    'index' => true,
                    'follow' => true,
                    'max-snippet' => -1,
                    'max-video-preview' => -1,
                    'max-image-preview' => 'large',
                );
        }
    }

    public function is_noindex_preset( $preset ) {
        return in_array( $preset, array( 'noindex_follow', 'noindex_nofollow' ), true );
    }
}
