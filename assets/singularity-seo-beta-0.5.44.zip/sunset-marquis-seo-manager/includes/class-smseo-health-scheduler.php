<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Health_Scheduler {
    const HOOK = 'smseo_daily_health_snapshot';
    const LAST_RUN_OPTION = 'smseo_daily_health_last_run';
    const LAST_ERROR_OPTION = 'smseo_daily_health_last_error';

    private $registry;
    private $campaign_manager;

    public function __construct( Registry $registry, Campaign_Manager $campaign_manager ) {
        $this->registry = $registry;
        $this->campaign_manager = $campaign_manager;

        add_action( self::HOOK, array( $this, 'run_scheduled_snapshot' ) );
        self::schedule();
    }

    public static function schedule() {
        if ( ! wp_next_scheduled( self::HOOK ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::HOOK );
        }
    }

    public static function unschedule() {
        $timestamp = wp_next_scheduled( self::HOOK );
        while ( $timestamp ) {
            wp_unschedule_event( $timestamp, self::HOOK );
            $timestamp = wp_next_scheduled( self::HOOK );
        }
    }

    public static function status() {
        $next_run = wp_next_scheduled( self::HOOK );

        return array(
            'enabled'      => (bool) $next_run,
            'schedule'     => 'daily',
            'next_run_gmt' => $next_run ? gmdate( 'Y-m-d H:i:s', $next_run ) : '',
            'last_run_gmt' => (string) get_option( self::LAST_RUN_OPTION, '' ),
            'last_error'   => (string) get_option( self::LAST_ERROR_OPTION, '' ),
        );
    }

    public function run_scheduled_snapshot() {
        try {
            $auditor = new Audit_Service( $this->registry, $this->campaign_manager );
            $results = $auditor->run_live_head_audit();
            $metrics_store = new Metrics_Store();
            $metrics_store->create_snapshot( $results, 'daily_cron' );
            update_option( self::LAST_RUN_OPTION, current_time( 'mysql', true ), false );
            delete_option( self::LAST_ERROR_OPTION );
        } catch ( \Throwable $throwable ) {
            update_option( self::LAST_ERROR_OPTION, $throwable->getMessage(), false );
        }
    }
}
