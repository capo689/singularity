<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Admin {
    const MENU_SLUG = 'sunset-marquis-seo-manager';
    const CONTROLLER_URL_OPTION = 'smseo_controller_url';
    const CUSTOMER_ID_OPTION = 'smseo_customer_id';
    const HOSTED_CONNECTION_STATUS_OPTION = 'smseo_hosted_connection_status';
    const HOSTED_CONNECTION_MESSAGE_OPTION = 'smseo_hosted_connection_message';
    const AUTO_CONNECT_COOLDOWN_TRANSIENT = 'smseo_auto_connect_cooldown';
    const CUSTOMER_ID_PREFIX = 'ss-';
    const DASHBOARD_NAMESPACE = 'singularity/v1';
    const UI_SETUP_COLLAPSED_META = 'singularity_ui_setup_collapsed';
    const UI_MODE_COLLAPSED_META = 'singularity_ui_mode_collapsed';
    const MODE_OPTION = 'singularity_mode';
    const CAPTURE_PAGE_IDS_OPTION = 'singularity_capture_page_ids';
    const MODE_APPLIED_AT_OPTION = 'singularity_mode_applied_at';
    const MODE_LOG_OPTION = 'singularity_mode_log';

    private $registry;
    private $campaign_manager;
    private $sitemap_manager;
    private $robots_manager;
    private $product_store;

    public function __construct(
        Registry $registry,
        Campaign_Manager $campaign_manager,
        Sitemap_Manager $sitemap_manager,
        Robots_Manager $robots_manager,
        Product_Store $product_store
    ) {
        $this->registry = $registry;
        $this->campaign_manager = $campaign_manager;
        $this->sitemap_manager = $sitemap_manager;
        $this->robots_manager = $robots_manager;
        $this->product_store = $product_store;

        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_post_smseo_save_overrides', array( $this, 'handle_save_overrides' ) );
        add_action( 'admin_post_smseo_reset_overrides', array( $this, 'handle_reset_overrides' ) );
        add_action( 'admin_post_smseo_run_live_audit', array( $this, 'handle_run_live_audit' ) );
        add_action( 'admin_post_smseo_save_bridge_token', array( $this, 'handle_save_bridge_token' ) );
        add_action( 'admin_post_smseo_save_connection', array( $this, 'handle_save_connection' ) );
        add_action( 'admin_post_smseo_save_visibility_setup', array( $this, 'handle_save_visibility_setup' ) );
        add_action( 'admin_post_smseo_refresh_search_console', array( $this, 'handle_refresh_search_console' ) );
        add_action( 'admin_post_smseo_run_takeover_scan', array( $this, 'handle_run_takeover_scan' ) );
        add_action( 'admin_post_smseo_create_report', array( $this, 'handle_create_report' ) );
        add_action( 'admin_post_smseo_save_competitors', array( $this, 'handle_save_competitors' ) );
        add_action( 'admin_post_smseo_download_report', array( $this, 'handle_download_report' ) );
        add_action( 'rest_api_init', array( $this, 'register_dashboard_routes' ) );
    }

    public function register_menu() {
        add_menu_page(
            'Singularity SEO',
            'Singularity SEO',
            'manage_options',
            self::MENU_SLUG,
            array( $this, 'render_page' ),
            'dashicons-chart-line',
            58
        );

        add_options_page(
            'Singularity SEO',
            'Singularity SEO',
            'manage_options',
            self::MENU_SLUG,
            array( $this, 'render_page' )
        );
    }

    public function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'sunset-marquis-seo-manager' ) );
        }

        $updated = isset( $_GET['smseo_updated'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_updated'] ) ) : '';
        $reset = isset( $_GET['smseo_reset'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_reset'] ) ) : '';
        $audit = isset( $_GET['smseo_audit'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_audit'] ) ) : '';
        $bridge_token_updated = isset( $_GET['smseo_bridge_token_updated'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_bridge_token_updated'] ) ) : '';
        $connection_updated = isset( $_GET['smseo_connection_updated'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_connection_updated'] ) ) : '';
        $visibility_updated = isset( $_GET['smseo_visibility_updated'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_visibility_updated'] ) ) : '';
        $gsc_refresh = isset( $_GET['smseo_gsc_refresh'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_gsc_refresh'] ) ) : '';
        $takeover_updated = isset( $_GET['smseo_takeover'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_takeover'] ) ) : '';
        $report_updated = isset( $_GET['smseo_report'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_report'] ) ) : '';
        $competitors_updated = isset( $_GET['smseo_competitors'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_competitors'] ) ) : '';
        $save_error = isset( $_GET['smseo_error'] ) ? sanitize_text_field( wp_unslash( $_GET['smseo_error'] ) ) : '';

        $this->maybe_auto_connect();

        echo '<div class="wrap smseo-admin">';

        if ( '1' === $updated ) {
            echo '<div class="notice notice-success is-dismissible"><p>SEO overrides saved.</p></div>';
        }

        if ( '1' === $save_error ) {
            $save_errors = get_transient( 'smseo_save_errors_' . get_current_user_id() );
            delete_transient( 'smseo_save_errors_' . get_current_user_id() );
            echo '<div class="notice notice-error"><p><strong>SEO overrides were not saved.</strong></p>';
            if ( is_array( $save_errors ) && ! empty( $save_errors ) ) {
                echo '<ul>';
                foreach ( $save_errors as $save_error_message ) {
                    printf( '<li>%s</li>', esc_html( (string) $save_error_message ) );
                }
                echo '</ul>';
            }
            echo '</div>';
        }

        if ( '1' === $reset ) {
            echo '<div class="notice notice-success is-dismissible"><p>All SEO overrides reset to plugin defaults.</p></div>';
        }

        if ( '1' === $bridge_token_updated ) {
            echo '<div class="notice notice-success is-dismissible"><p>Bridge API token saved.</p></div>';
        }

        if ( '1' === $connection_updated ) {
            echo '<div class="notice notice-success is-dismissible"><p>Connection checked.</p></div>';
        }

        if ( '1' === $visibility_updated ) {
            echo '<div class="notice notice-success is-dismissible"><p>Search data setup saved.</p></div>';
        }

        if ( '' !== $gsc_refresh ) {
            $gsc_message = get_transient( 'smseo_gsc_refresh_' . get_current_user_id() );
            delete_transient( 'smseo_gsc_refresh_' . get_current_user_id() );
            $notice_class = 'ok' === $gsc_refresh ? 'notice-success' : 'notice-error';
            printf(
                '<div class="notice %s is-dismissible"><p>%s</p></div>',
                esc_attr( $notice_class ),
                esc_html( is_string( $gsc_message ) && '' !== $gsc_message ? $gsc_message : 'Search Console refresh finished.' )
            );
        }

        if ( '1' === $report_updated ) {
            echo '<div class="notice notice-success is-dismissible"><p>Singularity report generated.</p></div>';
        }

        if ( '1' === $competitors_updated ) {
            echo '<div class="notice notice-success is-dismissible"><p>Competitors saved.</p></div>';
        }

        $this->render_admin_styles();
        $this->render_control_plane_dashboard();
        $this->render_edit_form();
        $this->render_reset_form();
        $this->render_agency_footer();
        $this->render_control_plane_assets();

        echo '</div>';
    }

    public function register_dashboard_routes() {
        register_rest_route(
            self::DASHBOARD_NAMESPACE,
            '/dashboard',
            array(
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_dashboard' ),
                'permission_callback' => array( $this, 'rest_manage_permission' ),
            )
        );

        register_rest_route(
            self::DASHBOARD_NAMESPACE,
            '/setup-status',
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'rest_setup_status' ),
                    'permission_callback' => array( $this, 'rest_manage_permission' ),
                ),
                array(
                    'methods'             => \WP_REST_Server::CREATABLE,
                    'callback'            => array( $this, 'rest_update_setup_status' ),
                    'permission_callback' => array( $this, 'rest_manage_permission' ),
                ),
            )
        );

        register_rest_route(
            self::DASHBOARD_NAMESPACE,
            '/health',
            array(
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_health' ),
                'permission_callback' => array( $this, 'rest_manage_permission' ),
            )
        );

        register_rest_route(
            self::DASHBOARD_NAMESPACE,
            '/coverage',
            array(
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_coverage' ),
                'permission_callback' => array( $this, 'rest_manage_permission' ),
            )
        );

        register_rest_route(
            self::DASHBOARD_NAMESPACE,
            '/visibility',
            array(
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_visibility' ),
                'permission_callback' => array( $this, 'rest_manage_permission' ),
            )
        );

        register_rest_route(
            self::DASHBOARD_NAMESPACE,
            '/ui',
            array(
                'methods'             => \WP_REST_Server::EDITABLE,
                'callback'            => array( $this, 'rest_update_ui' ),
                'permission_callback' => array( $this, 'rest_manage_permission' ),
            )
        );

        register_rest_route(
            self::DASHBOARD_NAMESPACE,
            '/mode',
            array(
                array(
                    'methods'             => \WP_REST_Server::READABLE,
                    'callback'            => array( $this, 'rest_mode' ),
                    'permission_callback' => array( $this, 'rest_manage_permission' ),
                ),
                array(
                    'methods'             => \WP_REST_Server::EDITABLE,
                    'callback'            => array( $this, 'rest_update_mode' ),
                    'permission_callback' => array( $this, 'rest_manage_permission' ),
                ),
            )
        );

        register_rest_route(
            self::DASHBOARD_NAMESPACE,
            '/capture-pages',
            array(
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => array( $this, 'rest_capture_pages' ),
                'permission_callback' => array( $this, 'rest_manage_permission' ),
            )
        );
    }

    public function rest_manage_permission( $request ) {
        return current_user_can( 'manage_options' );
    }

    public function rest_dashboard( \WP_REST_Request $request ) {
        return rest_ensure_response( $this->dashboard_payload() );
    }

    public function rest_setup_status( \WP_REST_Request $request ) {
        return rest_ensure_response( $this->setup_status_contract() );
    }

    public function rest_update_setup_status( \WP_REST_Request $request ) {
        $property_url = isset( $request['google_search_console_property_url'] ) ? trim( (string) $request['google_search_console_property_url'] ) : '';
        if ( '' !== $property_url ) {
            $visibility_store = new Visibility_Store();
            $visibility_store->update_config(
                array(
                    'google_search_console_property_url' => $property_url,
                    'google_search_console_connected'    => false,
                )
            );
            $visibility_store->create_snapshot( 'admin_setup' );
        }

        return rest_ensure_response( $this->setup_status_contract() );
    }

    public function rest_health( \WP_REST_Request $request ) {
        return rest_ensure_response( $this->health_contract() );
    }

    public function rest_coverage( \WP_REST_Request $request ) {
        return rest_ensure_response( $this->coverage_contract() );
    }

    public function rest_visibility( \WP_REST_Request $request ) {
        return rest_ensure_response( $this->visibility_contract() );
    }

    public function rest_update_ui( \WP_REST_Request $request ) {
        $user_id = get_current_user_id();
        if ( isset( $request['setup_collapsed'] ) ) {
            update_user_meta( $user_id, self::UI_SETUP_COLLAPSED_META, ! empty( $request['setup_collapsed'] ) ? '1' : '0' );
        }
        if ( isset( $request['mode_collapsed'] ) ) {
            update_user_meta( $user_id, self::UI_MODE_COLLAPSED_META, ! empty( $request['mode_collapsed'] ) ? '1' : '0' );
        }

        return rest_ensure_response( $this->ui_state() );
    }

    public function rest_mode( \WP_REST_Request $request ) {
        return rest_ensure_response( $this->mode_contract() );
    }

    public function rest_update_mode( \WP_REST_Request $request ) {
        $mode = sanitize_key( (string) $request['mode'] );
        if ( ! in_array( $mode, array( 'orbit', 'capture', 'singularity' ), true ) ) {
            return new \WP_Error( 'singularity_invalid_mode', 'Mode must be orbit, capture, or singularity.', array( 'status' => 400 ) );
        }

        $old_mode = $this->active_mode();
        $capture_ids = get_option( self::CAPTURE_PAGE_IDS_OPTION, array() );
        if ( 'capture' === $mode && isset( $request['capture_page_ids'] ) ) {
            $capture_ids = $this->clean_post_ids( $request['capture_page_ids'] );
            update_option( self::CAPTURE_PAGE_IDS_OPTION, $capture_ids, false );
        }

        if ( in_array( $mode, array( 'capture', 'singularity' ), true ) ) {
            $materialized = $this->materialize_managed_registry_for_mode( $mode, $capture_ids );
            if ( is_wp_error( $materialized ) ) {
                return $materialized;
            }
        }

        update_option( self::MODE_OPTION, $mode, false );
        update_option( self::MODE_APPLIED_AT_OPTION, current_time( 'mysql', true ), false );
        update_user_meta( get_current_user_id(), self::UI_MODE_COLLAPSED_META, '1' );
        $this->log_mode_transition( $old_mode, $mode, $capture_ids );

        return rest_ensure_response( $this->mode_contract() );
    }

    public function rest_capture_pages( \WP_REST_Request $request ) {
        return rest_ensure_response( $this->capture_pages_contract() );
    }

    private function dashboard_payload() {
        return array(
            'setup'       => $this->setup_status_contract(),
            'mode'        => $this->mode_contract(),
            'health'      => $this->health_contract(),
            'coverage'    => $this->coverage_contract(),
            'visibility'  => $this->visibility_contract(),
            'reports'     => $this->reports_contract(),
            'pages'       => $this->capture_pages_contract(),
            'advanced'    => $this->advanced_contract(),
            'ui'          => $this->ui_state(),
            'version'     => defined( 'SMSEO_VERSION' ) ? SMSEO_VERSION : '',
            'site_id'     => $this->default_customer_id(),
            'site_url'    => home_url( '/' ),
            'controller'  => trim( (string) get_option( self::CONTROLLER_URL_OPTION, $this->default_controller_url() ) ),
        );
    }

    private function setup_status_contract() {
        $visibility_store = new Visibility_Store();
        $visibility = $visibility_store->get_metrics();
        $providers = isset( $visibility['providers'] ) && is_array( $visibility['providers'] ) ? $visibility['providers'] : array();
        $config = isset( $visibility['config'] ) && is_array( $visibility['config'] ) ? $visibility['config'] : array();
        $gsc = isset( $providers['google_search_console'] ) && is_array( $providers['google_search_console'] ) ? $providers['google_search_console'] : array();
        $rank = isset( $providers['rank_provider'] ) && is_array( $providers['rank_provider'] ) ? $providers['rank_provider'] : array();
        $customer_id = $this->default_customer_id();
        $wordpress_ok = $this->is_connected();
        $chatgpt_ok = $wordpress_ok && '' !== $customer_id;
        $rank_ok = ! empty( $rank['connected'] ) || '' !== ( isset( $rank['provider'] ) ? (string) $rank['provider'] : '' );
        $gsc_ok = ! empty( $gsc['connected'] );

        return array(
            'wordpress'      => array(
                'ok'     => $wordpress_ok,
                'detail' => $wordpress_ok ? 'Hosted record verified' : $this->connection_status_label( (string) get_option( self::HOSTED_CONNECTION_STATUS_OPTION, '' ), '' !== trim( (string) get_option( API::BRIDGE_TOKEN_OPTION, '' ) ) ),
            ),
            'chatgpt_app'    => array(
                'ok'     => $chatgpt_ok,
                'detail' => '' !== $customer_id ? 'Secure connection code ready' : 'Secure connection code not set',
            ),
            'rank'           => array(
                'ok'     => $rank_ok,
                'detail' => $rank_ok ? trim( (string) ( isset( $rank['provider'] ) ? $rank['provider'] : 'Rank provider' ) . ', daily' ) : 'Rank provider not connected',
            ),
            'search_console' => array(
                'ok'     => $gsc_ok,
                'detail' => ! empty( $gsc['property_url'] )
                    ? (string) $gsc['property_url']
                    : ( ! empty( $config['google_search_console_property_url'] ) ? (string) $config['google_search_console_property_url'] : 'Property not connected' ),
            ),
            'core_ok'        => $wordpress_ok && $chatgpt_ok,
            'all_ok'         => $wordpress_ok && $chatgpt_ok && $rank_ok && $gsc_ok,
            'checked_at'     => gmdate( 'c' ),
        );
    }

    private function health_contract() {
        $metrics_store = new Metrics_Store();
        $metrics = $metrics_store->get_metrics();
        $current = isset( $metrics['current'] ) && is_array( $metrics['current'] ) ? $metrics['current'] : array();
        $summary = isset( $current['summary'] ) && is_array( $current['summary'] ) ? $current['summary'] : array();
        $history = isset( $metrics['history'] ) && is_array( $metrics['history'] ) ? $metrics['history'] : array();
        $trend = array();
        foreach ( array_slice( $history, -14 ) as $point ) {
            $captured_at = isset( $point['captured_at'] ) ? (string) $point['captured_at'] : '';
            $trend[] = array(
                'date'  => $captured_at ? gmdate( 'Y-m-d', strtotime( $captured_at . ' UTC' ) ) : '',
                'score' => isset( $point['score'] ) ? (int) $point['score'] : 0,
            );
        }

        $top_issue = array( 'label' => 'No open issues', 'pages' => 0 );
        if ( ! empty( $current['top_issues'] ) && is_array( $current['top_issues'] ) ) {
            $first = reset( $current['top_issues'] );
            if ( is_array( $first ) ) {
                $top_issue = array(
                    'label' => isset( $first['issue'] ) ? (string) $first['issue'] : '',
                    'pages' => isset( $first['count'] ) ? (int) $first['count'] : 0,
                );
            }
        }

        return array(
            'score'       => isset( $current['score'] ) ? (int) $current['score'] : 0,
            'grade'       => isset( $current['grade'] ) ? (string) $current['grade'] : 'Not scanned',
            'open_issues' => isset( $summary['issue_count'] ) ? (int) $summary['issue_count'] : 0,
            'trend'       => $trend,
            'top_issue'   => $top_issue,
            'captured_at' => isset( $current['captured_at'] ) ? (string) $current['captured_at'] : '',
        );
    }

    private function coverage_contract() {
        $mode = $this->active_mode();
        $pages = $this->capture_pages_contract();
        $total = isset( $pages['total'] ) ? (int) $pages['total'] : 0;
        $capture_ids = $this->clean_post_ids( get_option( self::CAPTURE_PAGE_IDS_OPTION, array() ) );
        if ( 'singularity' === $mode ) {
            $managed = $total;
            $unmanaged_ids = array();
        } elseif ( 'capture' === $mode ) {
            $managed = count( $capture_ids );
            $unmanaged_ids = array_values( array_diff( $this->eligible_post_ids(), $capture_ids ) );
        } else {
            $managed = count( $capture_ids );
            $unmanaged_ids = array_values( array_diff( $this->eligible_post_ids(), $capture_ids ) );
        }

        return array(
            'managed'            => max( 0, min( $total, $managed ) ),
            'total'              => $total,
            'unmanaged_page_ids' => $unmanaged_ids,
            'mode'               => $mode,
        );
    }

    private function visibility_contract() {
        $visibility_store = new Visibility_Store();
        $visibility = $visibility_store->get_metrics();
        $providers = isset( $visibility['providers'] ) && is_array( $visibility['providers'] ) ? $visibility['providers'] : array();
        $gsc = isset( $providers['google_search_console'] ) && is_array( $providers['google_search_console'] ) ? $providers['google_search_console'] : array();
        $config = isset( $visibility['config'] ) && is_array( $visibility['config'] ) ? $visibility['config'] : array();
        $automation = isset( $visibility['automation'] ) && is_array( $visibility['automation'] ) ? $visibility['automation'] : array();
        $current = isset( $visibility['current'] ) && is_array( $visibility['current'] ) ? $visibility['current'] : array();
        $search_console = isset( $current['search_console'] ) && is_array( $current['search_console'] ) ? $current['search_console'] : array();
        $rankings = isset( $current['rankings'] ) && is_array( $current['rankings'] ) ? $current['rankings'] : array();
        $latest_rankings = $this->latest_visibility_rankings( $visibility_store->get_snapshots() );
        if ( ! empty( $latest_rankings ) ) {
            $rankings = $latest_rankings;
        }

        return array(
            'connected'        => ! empty( $gsc['connected'] ),
            'next_snapshot_at' => isset( $automation['next_run_gmt'] ) && '' !== (string) $automation['next_run_gmt'] ? gmdate( 'c', strtotime( (string) $automation['next_run_gmt'] . ' UTC' ) ) : '',
            'clicks_28d'       => isset( $search_console['clicks'] ) ? $search_console['clicks'] : null,
            'impressions_28d'  => isset( $search_console['impressions'] ) ? $search_console['impressions'] : null,
            'avg_position'     => isset( $search_console['average_position'] ) ? $search_console['average_position'] : null,
            'target_keywords'  => isset( $config['target_keywords'] ) && is_array( $config['target_keywords'] ) ? array_values( $config['target_keywords'] ) : array(),
            'rankings'         => $rankings,
            'automation'       => $automation,
        );
    }

    private function reports_contract() {
        $report_store = new Report_Store( $this->registry, $this->product_store );
        return $report_store->dashboard_payload();
    }

    private function mode_contract() {
        $mode = $this->active_mode();
        $capture_ids = $this->clean_post_ids( get_option( self::CAPTURE_PAGE_IDS_OPTION, array() ) );
        return array(
            'mode'             => $mode,
            'capture_page_ids' => $capture_ids,
            'applied_at'       => (string) get_option( self::MODE_APPLIED_AT_OPTION, '' ),
            'scope'            => $this->mode_scope_summary( $mode, $capture_ids ),
        );
    }

    private function capture_pages_contract() {
        $report = ( new Takeover_Store( $this->registry ) )->get_report();
        $current = isset( $report['current'] ) && is_array( $report['current'] ) ? $report['current'] : array();
        $scan_pages = isset( $current['pages'] ) && is_array( $current['pages'] ) ? $current['pages'] : array();
        $selected = $this->clean_post_ids( get_option( self::CAPTURE_PAGE_IDS_OPTION, array() ) );
        $pages = array();

        if ( ! empty( $scan_pages ) ) {
            foreach ( $scan_pages as $page ) {
                if ( ! is_array( $page ) ) {
                    continue;
                }
                $post_id = isset( $page['post_id'] ) ? (int) $page['post_id'] : 0;
                if ( $post_id <= 0 ) {
                    continue;
                }
                $issues = isset( $page['issues'] ) && is_array( $page['issues'] ) ? array_values( array_map( 'strval', $page['issues'] ) ) : array();
                $pages[] = array(
                    'id'       => $post_id,
                    'title'    => isset( $page['label'] ) ? (string) $page['label'] : get_the_title( $post_id ),
                    'path'     => isset( $page['path'] ) ? (string) $page['path'] : wp_parse_url( get_permalink( $post_id ), PHP_URL_PATH ),
                    'managed'  => ! empty( $page['managed'] ),
                    'issues'   => $issues,
                    'selected' => in_array( $post_id, $selected, true ),
                );
            }
        } else {
            foreach ( $this->registry->all() as $key => $page ) {
                $post_id = $this->registry->resolve_post_id( $page );
                if ( $post_id <= 0 ) {
                    continue;
                }
                $path = isset( $page['path'] ) ? (string) $page['path'] : wp_parse_url( get_permalink( $post_id ), PHP_URL_PATH );
                $pages[] = array(
                    'id'       => $post_id,
                    'title'    => isset( $page['label'] ) ? (string) $page['label'] : get_the_title( $post_id ),
                    'path'     => $path,
                    'managed'  => true,
                    'issues'   => array(),
                    'selected' => in_array( $post_id, $selected, true ),
                );
            }
        }

        return array(
            'pages'    => array_values( $pages ),
            'total'    => count( $pages ),
            'selected' => $selected,
        );
    }

    private function advanced_contract() {
        $metrics = $this->health_contract();
        $overrides = get_option( Registry::OVERRIDES_OPTION, array() );
        $overrides = is_array( $overrides ) ? $overrides : array();
        return array(
            'diagnostics' => array(
                'badge' => $metrics['open_issues'] > 0 ? 'Review' : 'All resolved',
                'count' => count( $this->registry->all() ),
            ),
            'audit'       => array(
                'badge' => $metrics['open_issues'] > 0 ? 'Review' : 'Clean',
                'time'  => $metrics['captured_at'],
            ),
            'overrides'   => array(
                'count' => count( $overrides ),
            ),
            'system'      => array(
                'status'       => $this->is_connected() ? 'Operational' : 'Degraded',
                'blog_public'  => '0' !== (string) get_option( 'blog_public' ),
                'version'      => defined( 'SMSEO_VERSION' ) ? SMSEO_VERSION : '',
                'sitemap_url'  => home_url( '/wp-sitemap.xml' ),
            ),
        );
    }

    private function ui_state() {
        $user_id = get_current_user_id();
        return array(
            'setup_collapsed' => '1' === (string) get_user_meta( $user_id, self::UI_SETUP_COLLAPSED_META, true ),
            'mode_collapsed'  => '1' === (string) get_user_meta( $user_id, self::UI_MODE_COLLAPSED_META, true ),
        );
    }

    private function active_mode() {
        $mode = sanitize_key( (string) get_option( self::MODE_OPTION, '' ) );
        return in_array( $mode, array( 'orbit', 'capture', 'singularity' ), true ) ? $mode : '';
    }

    private function mode_scope_summary( $mode, $capture_ids ) {
        if ( 'singularity' === $mode ) {
            return 'Every eligible page is in autonomous management scope.';
        }
        if ( 'capture' === $mode ) {
            return count( $capture_ids ) . ' page(s) are in management scope. Everything else is untouched.';
        }
        if ( 'orbit' === $mode ) {
            return 'Scan and flag only. User edits remain authoritative.';
        }
        return 'No mode has been applied yet.';
    }

    private function materialize_managed_registry_for_mode( $mode, $capture_ids ) {
        $takeover_store = new Takeover_Store( $this->registry );
        $report = $takeover_store->get_report();
        $scan = isset( $report['current'] ) && is_array( $report['current'] ) ? $report['current'] : array();

        if ( empty( $scan ) ) {
            $scan = $takeover_store->create_scan( 'mode_auto_scan' );
        }

        $ids = 'singularity' === $mode ? $this->post_ids_from_takeover_scan( $scan ) : $capture_ids;
        if ( 'singularity' === $mode && empty( $ids ) ) {
            $ids = $this->eligible_post_ids();
        }

        $count = $this->registry->replace_customer_pages_from_takeover_scan( $scan, $ids );
        if ( $count <= 0 && 'orbit' !== $mode ) {
            return new \WP_Error(
                'singularity_no_pages_selected',
                'No eligible published pages were available for Singularity SEO management.',
                array( 'status' => 400 )
            );
        }

        return $count;
    }

    private function eligible_post_ids() {
        $ids = array();
        foreach ( $this->capture_pages_contract()['pages'] as $page ) {
            if ( isset( $page['id'] ) && (int) $page['id'] > 0 ) {
                $ids[] = (int) $page['id'];
            }
        }
        return array_values( array_unique( $ids ) );
    }

    private function post_ids_from_takeover_scan( $scan ) {
        $ids = array();
        $pages = isset( $scan['pages'] ) && is_array( $scan['pages'] ) ? $scan['pages'] : array();
        foreach ( $pages as $page ) {
            if ( ! is_array( $page ) ) {
                continue;
            }
            $post_id = isset( $page['post_id'] ) ? (int) $page['post_id'] : 0;
            if ( $post_id > 0 ) {
                $ids[] = $post_id;
            }
        }

        return array_values( array_unique( $ids ) );
    }

    private function clean_post_ids( $ids ) {
        $clean = array();
        foreach ( (array) $ids as $id ) {
            $id = absint( $id );
            if ( $id > 0 ) {
                $clean[] = $id;
            }
        }
        return array_values( array_unique( $clean ) );
    }

    private function log_mode_transition( $old_mode, $new_mode, $capture_ids ) {
        $log = get_option( self::MODE_LOG_OPTION, array() );
        $log = is_array( $log ) ? $log : array();
        $log[] = array(
            'old_mode'         => (string) $old_mode,
            'new_mode'         => (string) $new_mode,
            'capture_page_ids' => $this->clean_post_ids( $capture_ids ),
            'user_id'          => get_current_user_id(),
            'timestamp'        => current_time( 'mysql', true ),
        );
        update_option( self::MODE_LOG_OPTION, array_slice( $log, -100 ), false );
    }

    private function render_control_plane_dashboard() {
        $payload = $this->dashboard_payload();
        $logo_url = SMSEO_PLUGIN_URL . 'assets/singularity-seo-logo.png';
        $bug_url = SMSEO_PLUGIN_URL . 'assets/singularity-seo-logo-bug.png';
        $setup_collapsed = ! empty( $payload['ui']['setup_collapsed'] ) && ! empty( $payload['setup']['core_ok'] );
        $mode_collapsed = ! empty( $payload['ui']['mode_collapsed'] ) && '' !== $payload['mode']['mode'];

        echo '<div class="singularity-app" id="singularityApp">';
        echo '<section class="singularity-masthead">';
        echo '<div class="singularity-brand">';
        printf( '<img class="singularity-mark" src="%s" alt="Singularity SEO" />', esc_url( $bug_url ) );
        echo '<div><h1>Singularity SEO</h1><p>Artificial Intelligence. Real Results.</p></div>';
        echo '</div>';
        printf(
            '<div class="singularity-live %s"><span></span>%s</div>',
            ! empty( $payload['setup']['wordpress']['ok'] ) ? 'is-live' : 'needs-work',
            esc_html( ! empty( $payload['setup']['wordpress']['ok'] ) ? 'CONTROL PLANE · ACTIVE' : 'CONTROL PLANE · ATTENTION' )
        );
        echo '</section>';

        $this->render_setup_control_panel( $payload, $setup_collapsed );
        $this->render_mode_control_panel( $payload, $mode_collapsed );
        $this->render_metrics_control_panel( $payload );
        $this->render_reports_control_panel( $payload );
        $this->render_advanced_control_panels( $payload );
        echo '</div>';
    }

    private function render_setup_control_panel( $payload, $collapsed ) {
        $setup = $payload['setup'];
        $failing = $this->first_failing_setup_label( $setup );
        $site_id = $payload['site_id'];
        $controller_url = isset( $payload['controller'] ) ? (string) $payload['controller'] : $this->default_controller_url();
        $gsc_oauth_url = $this->google_search_console_oauth_url( $site_id, $controller_url );

        printf(
            '<section class="singularity-section singularity-setup %s" data-panel="setup">',
            $collapsed ? 'is-collapsed' : ''
        );
        printf(
            '<button type="button" class="singularity-statusbar" data-open-panel="setup"><span class="dot %s"></span><span><strong>%s</strong><small>%s</small></span><em>%s</em><b>open</b></button>',
            ! empty( $setup['core_ok'] ) ? '' : 'warn',
            ! empty( $setup['core_ok'] ) ? 'Ready for ChatGPT' : 'Connection needs attention',
            esc_html( ! empty( $setup['core_ok'] ) ? 'WordPress is verified and the ChatGPT link is ready' : $failing . ' needs attention' ),
            esc_html( '' !== $site_id ? 'secure link' : 'not linked' )
        );
        echo '<div class="singularity-panel">';
        echo '<header><div><h2>Launch setup</h2><p>Connect WordPress to ChatGPT first. Search data can be added next for reporting and rankings.</p></div><button type="button" class="ghost" data-collapse-panel="setup">Minimize</button></header>';
        echo '<div class="singularity-chatgpt singularity-chatgpt-link">';
        echo '<i class="chatgpt-bug" aria-hidden="true">S</i>';
        echo '<div class="singularity-chatgpt-copy"><strong>Connect this site to ChatGPT</strong>';
        echo '<span>Copy the secure ChatGPT command, then paste it into the Singularity SEO ChatGPT app.</span></div>';
        echo '<form class="singularity-chatgpt-link-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_save_connection" />';
        wp_nonce_field( 'smseo_save_connection', 'smseo_connection_nonce' );
        printf( '<input type="hidden" name="smseo_customer_id" value="%s" />', esc_attr( $site_id ) );
        printf( '<input type="hidden" name="smseo_controller_url" value="%s" />', esc_attr( $controller_url ) );
        printf( '<button type="submit" class="primary singularity-refresh-chatgpt">%s</button>', esc_html( ! empty( $setup['wordpress']['ok'] ) ? 'Refresh ChatGPT connection' : 'Connect WordPress' ) );
        echo '</form>';
        if ( ! empty( $setup['wordpress']['ok'] ) ) {
            printf( '<button type="button" class="copy" data-copy="Connect customer/site ID %s">Copy ChatGPT command</button>', esc_attr( $site_id ) );
        } else {
            echo '<button type="button" class="copy" disabled>Verifying secure link</button>';
        }
        echo '</div>';
        echo '<div class="singularity-launch-path">';
        $this->render_launch_step( '1', 'WordPress verified', $setup['wordpress'], 'The hosted Controller can read this WordPress site through the secure bridge.' );
        $this->render_launch_step( '2', 'ChatGPT ready', $setup['chatgpt_app'], 'A secure connection code is prepared for the Singularity SEO ChatGPT app.' );
        $this->render_launch_step( '3', 'Search data', $setup['search_console'], 'Optional reporting layer for clicks, impressions and Google position trends.' );
        echo '</div>';
        echo '<div class="singularity-checks">';
        $this->render_setup_check( 'WordPress', $setup['wordpress'] );
        $this->render_setup_check( 'ChatGPT Ready', $setup['chatgpt_app'] );
        $this->render_setup_check( 'Rank Tracking', $setup['rank'] );
        $this->render_setup_check( 'Search Console', $setup['search_console'] );
        echo '</div>';
        echo '<div class="singularity-gsc">';
        echo '<div><strong>Add Google Search Console</strong><span>Enter the website URL. Singularity will match the correct Search Console property after Google sign-in.</span></div>';
        printf( '<input type="text" id="singularityGscInput" placeholder="%s" value="%s" />', esc_attr( home_url( '/' ) ), ! empty( $setup['search_console']['detail'] ) && 'Property not connected' !== $setup['search_console']['detail'] ? esc_attr( $setup['search_console']['detail'] ) : '' );
        if ( '' !== $gsc_oauth_url ) {
            printf( '<a class="primary singularity-gsc-oauth" href="%s">Connect with Google</a>', esc_url( $gsc_oauth_url ) );
        } else {
            echo '<button type="button" class="primary" id="singularityGscButton">Save</button>';
        }
        echo '</div>';
        echo '</div></section>';
    }

    private function render_launch_step( $number, $label, $check, $copy ) {
        $ok = ! empty( $check['ok'] );
        printf(
            '<article class="launch-step %s"><b>%s</b><div><strong>%s</strong><span>%s</span><small>%s</small></div></article>',
            $ok ? 'ok' : 'todo',
            esc_html( $ok ? '✓' : (string) $number ),
            esc_html( $label ),
            esc_html( $copy ),
            esc_html( isset( $check['detail'] ) ? (string) $check['detail'] : '' )
        );
    }

    private function render_mode_control_panel( $payload, $collapsed ) {
        $mode = $payload['mode']['mode'];
        $coverage = $payload['coverage'];
        $mode_label = '' !== $mode ? ucfirst( $mode ) : 'Not selected';
        $dot_warn = 'singularity' === $mode && 0 === (int) $payload['health']['open_issues'] ? '' : 'warn';
        $subtitle = $this->mode_bar_subtitle( $payload );

        printf( '<section class="singularity-section singularity-mode %s" data-panel="mode">', $collapsed ? 'is-collapsed' : '' );
        printf(
            '<button type="button" class="singularity-statusbar" data-open-panel="mode"><span class="dot %s"></span><span><strong>SEO mode: %s</strong><small>%s</small></span><em>%s</em><b>change</b></button>',
            esc_attr( $dot_warn ),
            esc_html( $mode_label ),
            esc_html( $subtitle ),
            esc_html( '' !== $payload['mode']['applied_at'] ? $this->relative_metric_time( $payload['mode']['applied_at'] ) : 'not applied' )
        );
        echo '<div class="singularity-panel">';
        echo '<header><div><h2>Existing SEO scanned</h2><p>Singularity captured the current public output as a safe baseline. Choose how much control to hand over.</p></div></header>';
        echo '<div class="scan-pills">';
        printf( '<span>%d pages visible</span><span>%d managed now</span><span>%d untouched</span><span>%s</span>', (int) $coverage['total'], (int) $coverage['managed'], max( 0, (int) $coverage['total'] - (int) $coverage['managed'] ), esc_html( $payload['advanced']['system']['status'] ) );
        echo '</div>';
        echo '<div class="mode-cards" id="singularityModeCards">';
        $this->render_mode_card( 'orbit', 'Orbit', 'Low gravity · you steer', 'Singularity scans and flags. You fix pages by hand. Overrides are authoritative.', $mode );
        $this->render_mode_card( 'capture', 'Capture', 'Medium gravity · you choose', 'Pick which pages cross the horizon. Unselected pages keep their current SEO untouched.', $mode );
        $this->render_mode_card( 'singularity', 'Singularity', 'Total gravity · it runs itself', 'Every eligible page enters autonomous management scope and self-correction.', $mode );
        echo '</div>';
        echo '<div class="mode-footer"><span id="singularityModeHint">Choose a mode. You can change this anytime.</span><button type="button" class="primary" id="singularityApplyMode">Apply mode</button></div>';
        $this->render_capture_picker( $payload );
        echo '</div></section>';
    }

    private function render_metrics_control_panel( $payload ) {
        $health = $payload['health'];
        $coverage = $payload['coverage'];
        $visibility = $payload['visibility'];
        $managed = (int) $coverage['managed'];
        $total = max( 1, (int) $coverage['total'] );
        $pct = (int) round( ( $managed / $total ) * 100 );

        echo '<section class="singularity-metrics">';
        echo '<article class="metric-card health-card"><h3>SEO Health</h3><p>Composite score across managed pages · last 14 snapshots</p>';
        printf( '<div class="score">%d<small>/100</small></div><div class="delta">%s · %d open issues</div>', (int) $health['score'], esc_html( $health['grade'] ), (int) $health['open_issues'] );
        echo $this->sparkline_svg( $health['trend'] );
        echo '</article>';
        echo '<article class="metric-card coverage-card"><h3>Coverage</h3><p>Pages under Singularity control</p>';
        printf(
            '<div class="coverage-readout"><strong>%d</strong><span>of %d pages managed</span></div><div class="coverage-facts"><span>%d%% coverage</span><span>%d remaining</span></div>',
            $managed,
            (int) $coverage['total'],
            $pct,
            max( 0, (int) $coverage['total'] - $managed )
        );
        printf( '<button type="button" class="line" id="singularityManageRest">Manage the rest</button>' );
        echo '</article>';
        echo '</section>';

        echo '<section class="metric-card visibility-card"><h3>Visibility</h3><p>Google Search Console and tracked keyword movement · refreshes daily</p><div class="kpis">';
        $pending = empty( $visibility['connected'] );
        $next = ! empty( $visibility['next_snapshot_at'] ) ? $this->relative_metric_time( gmdate( 'Y-m-d H:i:s', strtotime( $visibility['next_snapshot_at'] ) ) ) : 'after connection';
        $this->render_visibility_kpi( 'Clicks (28d)', $visibility['clicks_28d'], $pending, $next );
        $this->render_visibility_kpi( 'Impressions', $visibility['impressions_28d'], $pending, $next );
        $this->render_visibility_kpi( 'Avg. Position', $visibility['avg_position'], $pending, $next );
        echo '</div>';
        $this->render_control_keyword_rankings( $visibility );
        $this->render_control_gsc_refresh( $visibility );
        echo '</section>';
    }

    private function render_control_gsc_refresh( $visibility ) {
        $automation = isset( $visibility['automation'] ) && is_array( $visibility['automation'] ) ? $visibility['automation'] : array();
        $last_error = isset( $automation['last_error'] ) ? trim( (string) $automation['last_error'] ) : '';
        $last_run = isset( $automation['last_run_gmt'] ) ? trim( (string) $automation['last_run_gmt'] ) : '';
        $next_run = isset( $automation['next_run_gmt'] ) ? trim( (string) $automation['next_run_gmt'] ) : '';
        $connected = ! empty( $visibility['connected'] );

        echo '<div class="smseo-gsc-refresh">';
        echo '<div>';
        echo '<strong>Search Console refresh</strong>';
        if ( '' !== $last_error ) {
            printf( '<span>Last error: %s</span>', esc_html( $last_error ) );
        } elseif ( '' !== $last_run ) {
            printf(
                '<span>Last checked %s. Next automatic run %s.</span>',
                esc_html( $this->relative_metric_time( $last_run ) ),
                esc_html( '' !== $next_run ? $this->relative_metric_time( $next_run ) : 'not scheduled' )
            );
        } else {
            echo '<span>Connected, waiting for the first automatic refresh.</span>';
        }
        echo '</div>';

        if ( $connected ) {
            echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
            echo '<input type="hidden" name="action" value="smseo_refresh_search_console" />';
            wp_nonce_field( 'smseo_refresh_search_console', 'smseo_gsc_refresh_nonce' );
            echo '<button type="submit" class="line">Test Search Console</button>';
            echo '</form>';
        }

        echo '</div>';
    }

    private function render_reports_control_panel( $payload ) {
        $reports = isset( $payload['reports'] ) && is_array( $payload['reports'] ) ? $payload['reports'] : array();
        $competitors = isset( $reports['competitors'] ) && is_array( $reports['competitors'] ) ? $reports['competitors'] : array();
        $latest = isset( $reports['latest'] ) && is_array( $reports['latest'] ) ? $reports['latest'] : array();
        $limit = isset( $reports['competitor_limit'] ) ? (int) $reports['competitor_limit'] : 5;

        echo '<section class="singularity-section singularity-reports">';
        echo '<div class="singularity-panel">';
        echo '<header><div><h2>Singularity Reports</h2><p>Generate branded strategy and progress reports from verified site data. Competitive reviews are prepared for ChatGPT strategy work.</p></div></header>';
        echo '<div class="report-actions">';
        $this->render_report_action( 'baseline', 'Create Baseline Report', 'Install-day health, takeover readiness and next actions.' );
        $this->render_report_action( 'competitive', 'Prepare Competitive Review', 'Save competitors or let ChatGPT identify up to five from the site context.' );
        $this->render_report_action( 'monthly', 'Create Monthly Report', 'Progress, changes, visibility movement and next priorities.' );
        $this->render_report_action( 'campaign', 'Create Campaign Status Report', 'Campaign state, expiration posture and reporting guidance.' );
        echo '</div>';

        echo '<div class="competitor-panel">';
        echo '<div><h3>Competitive Review Inputs</h3><p>Add up to five known competitors, or leave spaces open and ask ChatGPT to identify the most relevant competitors from the site, search data and managed page intent.</p></div>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_save_competitors" />';
        wp_nonce_field( 'smseo_save_competitors', 'smseo_competitors_nonce' );
        for ( $i = 0; $i < $limit; $i++ ) {
            $competitor = isset( $competitors[ $i ] ) && is_array( $competitors[ $i ] ) ? $competitors[ $i ] : array();
            printf(
                '<label><span>Competitor %d</span><input type="text" name="smseo_competitor_name[]" placeholder="Business name" value="%s" /><input type="text" name="smseo_competitor_domain[]" placeholder="competitor.com" value="%s" /></label>',
                $i + 1,
                esc_attr( isset( $competitor['name'] ) ? (string) $competitor['name'] : '' ),
                esc_attr( isset( $competitor['domain'] ) ? (string) $competitor['domain'] : '' )
            );
        }
        echo '<button type="submit" class="line">Save competitors</button>';
        echo '</form>';
        echo '</div>';

        echo '<div class="latest-reports">';
        echo '<h3>Latest Reports</h3>';
        if ( empty( $latest ) ) {
            echo '<p class="fold-note">No reports generated yet. Create a baseline report before the live test so the first client has a clean starting artifact.</p>';
        } else {
            echo '<div class="report-list">';
            foreach ( $latest as $report ) {
                $this->render_report_row( $report );
            }
            echo '</div>';
        }
        echo '</div>';
        echo '</div></section>';
    }

    private function render_report_action( $type, $label, $copy ) {
        echo '<form class="report-action-card" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_create_report" />';
        printf( '<input type="hidden" name="smseo_report_type" value="%s" />', esc_attr( $type ) );
        wp_nonce_field( 'smseo_create_report', 'smseo_report_nonce' );
        printf( '<strong>%s</strong><span>%s</span><button type="submit" class="primary">%s</button>', esc_html( $label ), esc_html( $copy ), esc_html( $label ) );
        echo '</form>';
    }

    private function render_report_row( $report ) {
        $id = isset( $report['id'] ) ? sanitize_key( (string) $report['id'] ) : '';
        $html_url = wp_nonce_url(
            add_query_arg(
                array(
                    'action'          => 'smseo_download_report',
                    'smseo_report_id' => $id,
                    'smseo_format'    => 'html',
                ),
                admin_url( 'admin-post.php' )
            ),
            'smseo_download_report_' . $id
        );
        $pdf_url = wp_nonce_url(
            add_query_arg(
                array(
                    'action'          => 'smseo_download_report',
                    'smseo_report_id' => $id,
                    'smseo_format'    => 'pdf',
                ),
                admin_url( 'admin-post.php' )
            ),
            'smseo_download_report_' . $id
        );
        printf(
            '<article class="report-row"><div><strong>%s</strong><span>%s</span></div><a class="line" href="%s" target="_blank" rel="noopener noreferrer">View HTML</a><a class="primary" href="%s">Download PDF</a></article>',
            esc_html( isset( $report['label'] ) ? (string) $report['label'] : 'Singularity Report' ),
            esc_html( isset( $report['created_at'] ) ? $this->format_metric_date( (string) $report['created_at'] ) : '' ),
            esc_url( $html_url ),
            esc_url( $pdf_url )
        );
    }

    private function render_advanced_control_panels( $payload ) {
        echo '<div class="advanced-title">Advanced</div><section class="advanced-folds">';
        $advanced = $payload['advanced'];
        $this->render_fold( 'Diagnostics', 'Managed SEO Diagnostics', 'Registry matching, sitemap posture, schema and override state', $advanced['diagnostics']['badge'], $advanced['diagnostics']['count'] . ' rows', $this->diagnostics_fold_content() );
        $this->render_fold( 'Audit', 'Live Front-End Head Audit', 'Real HTML returned by the site', $advanced['audit']['badge'], '' !== $advanced['audit']['time'] ? $this->relative_metric_time( $advanced['audit']['time'] ) : 'not run', $this->audit_fold_content() );
        $this->render_fold( 'Overrides', 'Managed SEO Overrides', 'Hand-tune controlled fields per page', (int) $advanced['overrides']['count'] . ' active', 'mode aware', $this->overrides_fold_content() );
        $this->render_fold( 'System', 'System Status', 'Connection health, sitemap and crawler signaling', $advanced['system']['status'], 'v' . $advanced['system']['version'], $this->system_fold_content( $advanced['system'] ) );
        echo '</section>';
    }

    private function render_capture_picker( $payload ) {
        echo '<div class="capture-picker" id="singularityCapturePicker" hidden>';
        echo '<div class="picker-tools"><input type="search" id="captureSearch" placeholder="Search pages by title or path..." /><button type="button" class="chip is-on" data-filter="all">All</button><button type="button" class="chip" data-filter="unmanaged">Unmanaged</button><button type="button" class="chip" data-filter="issues">Has issues</button></div>';
        echo '<label class="select-visible"><input type="checkbox" id="captureSelectVisible" /> Select all visible pages <span>Selected pages are managed. The remaining pages keep their current SEO untouched.</span></label>';
        echo '<div class="capture-list" id="captureList"></div>';
        echo '<div class="capture-footer"><strong><span id="captureCount">0</span> pages selected</strong><small id="captureConsequence">Choose which pages Singularity should manage.</small><button type="button" class="line" id="captureBack">Back to modes</button><button type="button" class="primary" id="captureApply" disabled>Bring 0 pages under control</button></div>';
        echo '</div>';
    }

    private function render_setup_check( $label, $check ) {
        $ok = ! empty( $check['ok'] );
        printf( '<article class="setup-check %s"><b>%s</b><strong>%s</strong><span>%s</span></article>', $ok ? 'ok' : 'todo', $ok ? '✓' : '!', esc_html( $label ), esc_html( isset( $check['detail'] ) ? (string) $check['detail'] : '' ) );
    }

    private function first_failing_setup_label( $setup ) {
        foreach ( array( 'wordpress' => 'WordPress', 'chatgpt_app' => 'ChatGPT app', 'rank' => 'Rank tracking', 'search_console' => 'Search Console' ) as $key => $label ) {
            if ( empty( $setup[ $key ]['ok'] ) ) {
                return $label;
            }
        }
        return 'Setup';
    }

    private function render_mode_card( $key, $label, $gravity, $copy, $active_mode ) {
        printf(
            '<button type="button" class="mode-card %s" data-mode="%s"><span class="mode-orbit"></span><strong>%s</strong><em>%s</em><small>%s</small><b>%s</b></button>',
            $key === $active_mode ? 'is-selected' : '',
            esc_attr( $key ),
            esc_html( $label ),
            esc_html( $gravity ),
            esc_html( $copy ),
            'capture' === $key ? 'Choose pages' : ( 'singularity' === $key ? 'Enter the Singularity' : 'Stay in Orbit' )
        );
    }

    private function mode_bar_subtitle( $payload ) {
        $mode = $payload['mode']['mode'];
        if ( 'singularity' === $mode ) {
            return (int) $payload['coverage']['managed'] . ' pages under autonomous scope · ' . (int) $payload['health']['open_issues'] . ' open issues';
        }
        if ( 'capture' === $mode ) {
            return (int) $payload['coverage']['managed'] . ' pages managed · ' . max( 0, (int) $payload['coverage']['total'] - (int) $payload['coverage']['managed'] ) . ' untouched';
        }
        if ( 'orbit' === $mode ) {
            return 'Watch only · you are fixing pages by hand';
        }
        return 'Choose Orbit, Capture, or Singularity';
    }

    private function sparkline_svg( $trend ) {
        $trend = is_array( $trend ) ? array_values( $trend ) : array();
        if ( empty( $trend ) ) {
            $trend = array( array( 'score' => 0 ), array( 'score' => 0 ) );
        }
        $count = max( 1, count( $trend ) - 1 );
        $points = array();
        foreach ( $trend as $index => $point ) {
            $score = isset( $point['score'] ) ? max( 0, min( 100, (int) $point['score'] ) ) : 0;
            $x = 620 * ( $index / $count );
            $y = 112 - ( $score * 0.9 );
            $points[] = round( $x, 2 ) . ',' . round( $y, 2 );
        }
        $polyline = implode( ' ', $points );
        return '<svg class="sparkline" viewBox="0 0 620 130" preserveAspectRatio="none" aria-hidden="true"><path d="M0 112 H620" /><path d="M0 68 H620" /><polyline points="' . esc_attr( $polyline ) . '" /></svg>';
    }

    private function render_visibility_kpi( $label, $value, $pending, $next ) {
        echo '<article class="visibility-kpi">';
        printf( '<span>%s</span>', esc_html( $label ) );
        if ( $pending || null === $value || '' === $value ) {
            printf( '<strong class="pending">Pending</strong><small>first snapshot %s</small>', esc_html( $next ) );
        } else {
            printf( '<strong>%s</strong><small>latest 28 days</small>', esc_html( is_numeric( $value ) ? number_format_i18n( (float) $value, is_float( $value ) ? 2 : 0 ) : (string) $value ) );
        }
        echo '</article>';
    }

    private function render_control_keyword_rankings( $visibility ) {
        $keywords = isset( $visibility['target_keywords'] ) && is_array( $visibility['target_keywords'] )
            ? array_values( array_filter( $visibility['target_keywords'] ) )
            : array();
        if ( empty( $keywords ) ) {
            return;
        }

        $rankings = isset( $visibility['rankings'] ) && is_array( $visibility['rankings'] ) ? $visibility['rankings'] : array();
        $ranking_rows = array();
        if ( isset( $rankings['keywords'] ) && is_array( $rankings['keywords'] ) ) {
            foreach ( $rankings['keywords'] as $row ) {
                if ( ! is_array( $row ) || empty( $row['keyword'] ) ) {
                    continue;
                }
                $ranking_rows[ strtolower( trim( (string) $row['keyword'] ) ) ] = $row;
            }
        }

        echo '<div class="keyword-rank-list">';
        echo '<div class="keyword-rank-head"><strong>Tracked Keyword Rankings</strong><span>Stored results only. No search runs here.</span></div>';
        foreach ( $keywords as $keyword ) {
            $keyword = trim( (string) $keyword );
            if ( '' === $keyword ) {
                continue;
            }
            $row = isset( $ranking_rows[ strtolower( $keyword ) ] ) ? $ranking_rows[ strtolower( $keyword ) ] : array();
            $rank = isset( $row['rank'] ) ? $row['rank'] : null;
            $status = isset( $row['status'] ) && '' !== (string) $row['status'] ? (string) $row['status'] : '';
            $message = isset( $row['message'] ) && '' !== (string) $row['message'] ? (string) $row['message'] : '';
            $url = isset( $row['url'] ) ? (string) $row['url'] : '';
            if ( null !== $rank && '' !== (string) $rank ) {
                $value = '#' . number_format_i18n( (float) $rank, 0 );
                $note = '' !== $url ? $url : 'Matched in search results';
                $state_class = 'is-found';
            } elseif ( '' !== $message ) {
                $value = 'Not found';
                $note = $message;
                $state_class = 'is-missing';
            } elseif ( '' !== $status ) {
                $value = 'Not found';
                $note = $this->visibility_status_label( $status );
                $state_class = 'is-missing';
            } else {
                $value = 'Pending';
                $note = 'Waiting for first rank refresh';
                $state_class = 'is-pending';
            }

            printf(
                '<div class="keyword-rank-row %s"><strong>%s</strong><b>%s</b><span>%s</span></div>',
                esc_attr( $state_class ),
                esc_html( $keyword ),
                esc_html( $value ),
                esc_html( $note )
            );
        }
        echo '</div>';
    }

    private function render_fold( $id, $title, $subtitle, $badge, $meta, $content ) {
        printf( '<article class="advanced-fold" data-fold="%s"><button type="button"><span></span><strong>%s<small>%s</small></strong><em>%s</em><b>%s</b><i>▾</i></button><div>%s</div></article>', esc_attr( sanitize_key( $id ) ), esc_html( $title ), esc_html( $subtitle ), esc_html( $badge ), esc_html( $meta ), $content );
    }

    private function diagnostics_fold_content() {
        $rows = '';
        foreach ( array_slice( $this->registry->all(), 0, 8, true ) as $key => $page ) {
            $path = isset( $page['path'] ) ? (string) $page['path'] : '/';
            $label = isset( $page['label'] ) ? (string) $page['label'] : (string) $key;
            $override = $this->registry->get_override( $key );
            $rows .= '<tr><td>' . esc_html( $label ) . '</td><td><code>' . esc_html( $path ) . '</code></td><td>' . esc_html( empty( $override ) ? 'Default' : 'Custom' ) . '</td></tr>';
        }
        return '<table><thead><tr><th>Page</th><th>Path</th><th>Override</th></tr></thead><tbody>' . $rows . '</tbody></table>';
    }

    private function audit_fold_content() {
        $health = $this->health_contract();
        return '<div class="audit-lines"><p><span></span> Score ' . esc_html( (string) $health['score'] ) . ' / 100</p><p><span></span> ' . esc_html( (string) $health['open_issues'] ) . ' open issues</p><p><span></span> Top issue: ' . esc_html( (string) $health['top_issue']['label'] ) . '</p></div><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="smseo_run_live_audit" />' . wp_nonce_field( 'smseo_run_live_audit', 'smseo_audit_nonce', true, false ) . '<button class="line" type="submit">Run live head audit now</button></form>';
    }

    private function overrides_fold_content() {
        $mode = $this->active_mode();
        $message = 'singularity' === $mode ? 'In Singularity mode overrides are advisory; the autonomous loop can self-correct around them.' : 'In Orbit and Capture modes overrides are authoritative inside the active scope.';
        return '<p class="fold-note">' . esc_html( $message ) . '</p><p><a class="line link-button" href="' . esc_url( admin_url( 'admin.php?page=' . self::MENU_SLUG . '#smseo-override-editor' ) ) . '">Open override editor</a></p>';
    }

    private function system_fold_content( $system ) {
        return '<div class="system-grid"><p><b>Site home</b><code>' . esc_html( home_url( '/' ) ) . '</code></p><p><b>Search visibility</b><code>' . esc_html( ! empty( $system['blog_public'] ) ? 'Public indexing enabled' : 'Discouraging search engines' ) . '</code></p><p><b>Sitemap</b><code>' . esc_html( $system['sitemap_url'] ) . '</code></p><p><b>Plugin version</b><code>' . esc_html( $system['version'] ) . '</code></p></div>';
    }

    private function render_control_plane_assets() {
        $payload = $this->dashboard_payload();
        $config = array(
            'root'    => esc_url_raw( rest_url( self::DASHBOARD_NAMESPACE ) ),
            'nonce'   => wp_create_nonce( 'wp_rest' ),
            'payload' => $payload,
        );
        ?>
        <style>
            .coverage-readout{display:flex;align-items:flex-end;gap:10px;margin:18px 0 12px}.coverage-readout strong{color:var(--ink);font-size:50px;line-height:.9;font-weight:900}.coverage-readout span{color:var(--muted);font-size:13px;font-weight:800}.coverage-facts{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}.coverage-facts span{border-radius:999px;padding:5px 10px;background:#eef5ff;color:var(--blue);font-size:12px;font-weight:800}.coverage-facts span:first-child{background:#e6f8f1;color:var(--green)}
            .keyword-rank-list{margin-top:16px;border:1px solid var(--line);border-radius:13px;background:#fff;overflow:hidden}.keyword-rank-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 16px;background:#fafbff;border-bottom:1px solid #eef0f7}.keyword-rank-head strong{font-size:14px}.keyword-rank-head span{color:var(--muted);font-size:12px}.keyword-rank-row{display:grid;grid-template-columns:minmax(0,1fr) 92px minmax(0,1.2fr);gap:12px;align-items:center;padding:12px 16px;border-bottom:1px solid #eef0f7}.keyword-rank-row:last-child{border-bottom:none}.keyword-rank-row strong{min-width:0;overflow:hidden;text-overflow:ellipsis}.keyword-rank-row b{justify-self:start;border-radius:999px;padding:4px 9px;background:#eef2ff;color:var(--blue);font-size:12px}.keyword-rank-row.is-found b{background:#e6f8f1;color:var(--green)}.keyword-rank-row.is-missing b{background:#fdf2e0;color:var(--amber)}.keyword-rank-row span{min-width:0;color:var(--muted);font-size:12px;overflow:hidden;text-overflow:ellipsis}.smseo-gsc-refresh{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:14px;border:1px solid var(--line);border-radius:13px;padding:13px 16px;background:#fafbff}.smseo-gsc-refresh strong,.smseo-gsc-refresh span{display:block}.smseo-gsc-refresh span{margin-top:3px;color:var(--muted);font-size:12px}.smseo-gsc-refresh form{margin:0;flex:none}
            .smseo-admin{max-width:1120px}.singularity-app{--ink:#0a1430;--soft:#3a4566;--muted:#8a93ad;--line:#e4e7f0;--wash:#f4f6fb;--card:#fff;--blue:#1f54ff;--deep:#0a2bb8;--cyan:#22d3ee;--green:#0fae6e;--amber:#e8950c;--red:#e23d5b;--radius:16px;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.singularity-app *{box-sizing:border-box}.singularity-masthead{display:flex;align-items:center;gap:18px;justify-content:space-between;overflow:hidden;border-radius:var(--radius);padding:24px 30px;color:#fff;background:linear-gradient(120deg,#06112e,#0a1f5c 55%,#123a9e);box-shadow:0 18px 50px rgba(10,20,48,.16)}.singularity-brand{display:flex;align-items:center;gap:16px}.singularity-brand h1{margin:0;font-size:25px;line-height:1.1;color:#fff;font-weight:800}.singularity-brand p{margin:4px 0 0;color:#a9c3ff;text-transform:uppercase;letter-spacing:.15em;font-size:12px}.singularity-mark{width:92px;height:92px;object-fit:contain;filter:drop-shadow(0 6px 22px rgba(56,140,255,.55))}.singularity-live{display:flex;align-items:center;gap:8px;border:1px solid rgba(124,196,255,.35);background:rgba(124,196,255,.14);border-radius:999px;padding:7px 13px;color:#cfe2ff;font:600 12px ui-monospace,SFMono-Regular,Menlo,monospace}.singularity-live span{width:8px;height:8px;border-radius:50%;background:var(--amber)}.singularity-live.is-live span{background:#5cf2b0}.singularity-section{margin-top:18px}.singularity-statusbar{display:none;width:100%;align-items:center;gap:14px;text-align:left;padding:15px 20px;cursor:pointer;background:var(--card);border:1px solid var(--line);border-radius:var(--radius);box-shadow:0 8px 28px rgba(10,20,48,.06)}.singularity-section.is-collapsed .singularity-statusbar{display:flex}.singularity-section.is-collapsed .singularity-panel{display:none}.singularity-statusbar .dot{width:10px;height:10px;border-radius:50%;background:var(--green);box-shadow:0 0 0 4px #e6f8f1}.singularity-statusbar .dot.warn{background:var(--amber);box-shadow:0 0 0 4px #fdf2e0}.singularity-statusbar strong{display:block;font-size:14px}.singularity-statusbar small{display:block;color:var(--muted);font-size:13px}.singularity-statusbar em{margin-left:auto;color:var(--soft);font:500 12px ui-monospace,SFMono-Regular,Menlo,monospace}.singularity-statusbar b{color:var(--muted);font-size:12px}.singularity-panel,.metric-card,.advanced-fold{background:var(--card);border:1px solid var(--line);border-radius:var(--radius);box-shadow:0 8px 28px rgba(10,20,48,.06)}.singularity-panel header{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;padding:22px 26px 18px;border-bottom:1px solid #eef0f7}.singularity-panel h2,.metric-card h3{margin:0;color:var(--ink);font-size:18px;font-weight:800}.singularity-panel p,.metric-card p{margin:4px 0 0;color:var(--muted);font-size:13px}.ghost,.primary,.line,.copy,.chip{border-radius:9px;padding:9px 14px;border:1px solid var(--line);background:#fff;color:var(--soft);cursor:pointer;font-weight:700}.primary{border-color:var(--blue);background:var(--blue);color:#fff;box-shadow:0 6px 16px rgba(31,84,255,.28)}.line,.copy{border-color:var(--blue);color:var(--blue)}.singularity-checks{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;padding:22px 26px 0}.setup-check{border:1px solid #f4cdd5;background:linear-gradient(180deg,#fdf3f5,#fff);border-radius:13px;padding:15px 16px}.setup-check.ok{border-color:#bfe9d6;background:linear-gradient(180deg,#f3fbf7,#fff)}.setup-check b{display:grid;place-items:center;width:22px;height:22px;border-radius:50%;background:var(--red);color:#fff}.setup-check.ok b{background:var(--green)}.setup-check strong{display:block;margin-top:10px}.setup-check span{display:block;color:var(--muted);font-size:12px}.singularity-gsc{margin:16px 26px;display:grid;grid-template-columns:1fr minmax(240px,360px) auto;gap:12px;align-items:center;border:1.5px dashed #c5cee8;border-radius:13px;padding:16px 18px;background:#fafbff}.singularity-gsc strong,.singularity-chatgpt strong{display:block}.singularity-gsc span,.singularity-chatgpt span{display:block;color:var(--muted);font-size:12.5px}.singularity-gsc input{width:100%;border:1px solid var(--line);border-radius:9px;padding:10px 12px}.singularity-chatgpt{margin:0 26px 26px;display:flex;align-items:center;gap:16px;border-radius:13px;padding:16px 20px;color:#dfe9ff;background:linear-gradient(110deg,#0a1d52,#15327f)}.chatgpt-bug{display:grid;place-items:center;flex:none;width:46px;height:46px;border-radius:12px;background:radial-gradient(circle at 50% 45%,#eaf7ff 0,#7cc4ff 36%,#1f54ff 72%);color:#fff;font-style:normal;font-weight:900;font-size:24px;box-shadow:0 0 0 1px rgba(255,255,255,.18),0 8px 22px rgba(31,84,255,.35)}.singularity-chatgpt strong{color:#fff}.singularity-chatgpt span{color:#aec5ff}.singularity-chatgpt code{background:rgba(255,255,255,.1);padding:2px 7px;border-radius:6px;color:#cfe2ff}.singularity-chatgpt .copy{margin-left:auto;background:rgba(255,255,255,.12);color:#fff;border-color:rgba(255,255,255,.25)}.scan-pills{display:flex;gap:10px;flex-wrap:wrap;padding:22px 26px 0}.scan-pills span{font:600 12px ui-monospace,SFMono-Regular,Menlo,monospace;padding:7px 13px;border-radius:999px;background:#eef2ff;color:#0a2bb8;border:1px solid #d6deff}.mode-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;padding:18px 26px}.mode-card{text-align:left;border:1.5px solid var(--line);border-radius:15px;padding:20px;background:#fff;cursor:pointer;transition:.16s}.mode-card:hover{transform:translateY(-2px);border-color:#aebbe6}.mode-card.is-selected{border-color:var(--blue);background:linear-gradient(180deg,#f4f7ff,#fff);box-shadow:0 10px 30px rgba(31,84,255,.16)}.mode-orbit{display:block;width:46px;height:46px;border-radius:50%;margin-bottom:14px;background:radial-gradient(circle,#fff 0,#7cc4ff 38%,#1f54ff 70%);box-shadow:0 0 0 9px #eef2ff}.mode-card strong,.mode-card em,.mode-card small,.mode-card b{display:block}.mode-card strong{font-size:16px;color:var(--ink)}.mode-card em{margin-top:3px;color:var(--muted);font:600 10.5px ui-monospace,SFMono-Regular,Menlo,monospace;text-transform:uppercase;letter-spacing:.1em}.mode-card small{margin-top:10px;color:var(--soft);line-height:1.55}.mode-card b{margin-top:14px;color:var(--blue)}.mode-footer,.capture-footer{display:flex;align-items:center;gap:14px;margin:0 26px 26px;padding-top:16px;border-top:1px solid #eef0f7}.mode-footer span{color:var(--muted);font-size:13px}.mode-footer .primary,.capture-footer .primary{margin-left:auto}.capture-picker{padding:0 26px 26px}.picker-tools{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.picker-tools input{flex:1;min-width:260px;border:1px solid var(--line);border-radius:10px;padding:10px 12px}.chip.is-on{background:var(--blue);border-color:var(--blue);color:#fff}.select-visible{display:flex;gap:10px;margin:12px 0;padding:12px 14px;border:1px solid var(--line);border-radius:11px;background:#fafbff;font-weight:700}.select-visible span{margin-left:auto;color:var(--muted);font-weight:400}.capture-list{border:1px solid var(--line);border-radius:13px;overflow:auto;max-height:420px}.capture-row{display:flex;align-items:center;gap:12px;padding:13px 16px;border-bottom:1px solid #eef0f7;cursor:pointer}.capture-row:last-child{border-bottom:none}.capture-row:hover,.capture-row.is-selected{background:#fafbff}.capture-row strong{min-width:0;flex:1}.capture-row small{display:block;color:var(--muted);font:500 11.5px ui-monospace,SFMono-Regular,Menlo,monospace;overflow:hidden;text-overflow:ellipsis}.capture-row em{font-style:normal;font-size:11px;border-radius:6px;padding:3px 8px;background:#e6f8f1;color:var(--green)}.capture-row em.unmanaged{background:#fdecef;color:var(--red)}.capture-row b{width:170px;text-align:right;color:var(--amber);font-size:11.5px}.capture-footer{position:sticky;bottom:0;background:#fff;border:1px solid var(--line);border-radius:13px;padding:14px 18px;margin:16px 0 0}.capture-footer strong small,.capture-footer small{display:block;color:var(--muted);font-weight:400}.singularity-metrics{display:grid;grid-template-columns:1.55fr 1fr;gap:16px;margin-top:18px}.metric-card{padding:22px 24px}.score{font-size:42px;font-weight:900;letter-spacing:-.04em;margin-top:12px}.score small{font-size:18px;color:var(--muted)}.delta{color:var(--green);font-weight:700}.sparkline{width:100%;height:130px;margin-top:12px}.sparkline path{stroke:#eef0f7}.sparkline polyline{fill:none;stroke:var(--blue);stroke-width:3;stroke-linecap:round;stroke-linejoin:round}.donut{width:132px;height:132px;border-radius:50%;display:grid;place-items:center;margin:18px 0;background:conic-gradient(var(--blue) var(--pct),#eef0f7 0);position:relative}.donut:after{content:"";position:absolute;inset:18px;border-radius:50%;background:#fff}.donut strong,.donut span{position:relative;z-index:1}.donut strong{font-size:28px}.donut span{display:block;color:var(--muted);font-size:12px}.visibility-card{margin-top:16px}.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:16px}.visibility-kpi{border:1px solid var(--line);border-radius:13px;padding:16px}.visibility-kpi span{font-size:10.5px;text-transform:uppercase;letter-spacing:.13em;color:var(--muted);font-weight:800}.visibility-kpi strong{display:block;font-size:22px;margin-top:8px}.visibility-kpi strong.pending{font-size:15px;color:var(--muted)}.visibility-kpi small{color:var(--amber);background:#fdf2e0;border-radius:6px;padding:2px 8px;display:inline-block;margin-top:6px}.advanced-title{margin-top:26px;padding:0 4px;color:var(--muted);font-size:12px;font-weight:900;letter-spacing:.12em;text-transform:uppercase}.advanced-folds{display:grid;gap:10px;margin-top:10px}.advanced-fold{overflow:hidden}.advanced-fold>button{display:flex;align-items:center;gap:14px;width:100%;padding:16px 20px;background:#fff;border:0;cursor:pointer;text-align:left}.advanced-fold>button span{width:34px;height:34px;border-radius:9px;background:#eef2ff}.advanced-fold strong{flex:1}.advanced-fold small{display:block;color:var(--muted);font-weight:400;margin-top:2px}.advanced-fold em{font-style:normal;border-radius:6px;padding:3px 9px;background:#e6f8f1;color:var(--green);font-size:11px;font-weight:800}.advanced-fold b{color:var(--soft);font:600 12px ui-monospace,SFMono-Regular,Menlo,monospace}.advanced-fold>div{display:none;border-top:1px solid #eef0f7;padding:18px 20px}.advanced-fold.is-open>div{display:block}.advanced-fold table{width:100%;border-collapse:collapse}.advanced-fold th,.advanced-fold td{padding:10px 8px;border-bottom:1px solid #eef0f7;text-align:left}.audit-lines p{margin:8px 0}.audit-lines span{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--green);margin-right:8px}.fold-note{margin-top:0;color:var(--soft)}.link-button{text-decoration:none;display:inline-block}.system-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.system-grid p{border:1px solid var(--line);border-radius:11px;padding:12px;margin:0}.system-grid b{display:block;text-transform:uppercase;letter-spacing:.1em;color:var(--muted);font-size:11px}.system-grid code{display:block;margin-top:6px;white-space:normal}.smseo-footer-mark{display:flex;align-items:center;justify-content:flex-end;gap:10px;margin:22px 0 8px;color:#8a93ad;font-weight:700;font-size:12px}.smseo-footer-mark img{width:112px;max-width:112px;height:auto;display:block}@media(max-width:900px){.singularity-checks,.mode-cards,.singularity-metrics,.kpis,.system-grid{grid-template-columns:1fr}.singularity-gsc{grid-template-columns:1fr}.capture-row b{display:none}.singularity-masthead{align-items:flex-start;flex-direction:column}.singularity-mark{width:76px;height:76px}}
            .singularity-chatgpt-link-form{margin-left:auto;display:flex;align-items:center;}
            .singularity-chatgpt-link{margin-bottom:16px;padding:20px;display:grid;grid-template-columns:46px minmax(0,1fr) auto auto;}
            .singularity-chatgpt-copy{min-width:0;}
            .singularity-chatgpt-copy strong{font-size:18px;}
            .singularity-chatgpt-copy span{font-size:13px;line-height:1.45;}
            .singularity-refresh-chatgpt{min-height:48px;min-width:230px;border-radius:12px;font-weight:900;white-space:normal;}
            .singularity-chatgpt-link .copy{margin-left:0;}
            .singularity-launch-path{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:0 26px 6px;}
            .launch-step{display:flex;gap:12px;min-width:0;border:1px solid #f4cdd5;background:linear-gradient(180deg,#fff7f8,#fff);border-radius:14px;padding:15px;}
            .launch-step.ok{border-color:#bfe9d6;background:linear-gradient(180deg,#f4fbf8,#fff);}
            .launch-step b{display:grid;place-items:center;flex:none;width:28px;height:28px;border-radius:50%;background:var(--red);color:#fff;font-weight:900;}
            .launch-step.ok b{background:var(--green);}
            .launch-step strong,.launch-step span,.launch-step small{display:block;}
            .launch-step strong{font-size:14px;}
            .launch-step span{margin-top:4px;color:var(--soft);font-size:12.5px;line-height:1.4;}
            .launch-step small{margin-top:8px;color:var(--muted);font:600 11px ui-monospace,SFMono-Regular,Menlo,monospace;overflow-wrap:anywhere;}
            .singularity-checks{padding-top:14px;}
            .singularity-gsc{margin-top:14px;}
            .singularity-reports .singularity-panel{overflow:hidden;}
            .report-actions{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;padding:22px 26px;}
            .report-action-card{display:flex;min-height:190px;flex-direction:column;gap:10px;border:1px solid var(--line);border-radius:15px;padding:18px;background:linear-gradient(180deg,#fff,#f7faff);}
            .report-action-card strong{font-size:15px;color:var(--ink);}
            .report-action-card span{display:block;color:var(--soft);font-size:12.5px;line-height:1.45;}
            .report-action-card button{margin-top:auto;width:100%;min-height:42px;white-space:normal;}
            .competitor-panel{display:grid;grid-template-columns:minmax(240px,.8fr) 1.2fr;gap:18px;margin:0 26px 22px;padding:18px;border:1px dashed #c5cee8;border-radius:14px;background:#fafbff;}
            .competitor-panel h3,.latest-reports h3{margin:0 0 6px;color:var(--ink);font-size:16px;}
            .competitor-panel p{margin:0;color:var(--muted);font-size:13px;line-height:1.5;}
            .competitor-panel form{display:grid;gap:10px;}
            .competitor-panel label{display:grid;grid-template-columns:96px minmax(0,1fr) minmax(0,1fr);gap:10px;align-items:center;}
            .competitor-panel label span{font-weight:800;color:var(--soft);font-size:12px;}
            .competitor-panel input{width:100%;border:1px solid var(--line);border-radius:9px;padding:9px 10px;}
            .competitor-panel button{justify-self:end;}
            .latest-reports{padding:0 26px 26px;}
            .report-list{display:grid;gap:10px;}
            .report-row{display:flex;align-items:center;gap:12px;border:1px solid var(--line);border-radius:13px;padding:14px;background:#fff;}
            .report-row div{min-width:0;flex:1;}
            .report-row strong,.report-row span{display:block;}
            .report-row span{color:var(--muted);font-size:12px;margin-top:3px;}
            @media(max-width:900px){
                .singularity-chatgpt-link{display:flex;align-items:stretch;flex-wrap:wrap;}
                .singularity-chatgpt-link-form{order:3;width:100%;margin-left:0;}
                .singularity-refresh-chatgpt{width:100%;}
                .singularity-chatgpt-link .copy{order:4;width:100%;}
                .singularity-launch-path{grid-template-columns:1fr;}
                .report-actions,.competitor-panel{grid-template-columns:1fr;}
                .competitor-panel label{grid-template-columns:1fr;}
                .report-row{align-items:stretch;flex-direction:column;}
            }
        </style>
        <script>
        window.SingularitySEO = <?php echo wp_json_encode( $config ); ?>;
        (function(){
            const cfg = window.SingularitySEO;
            let state = cfg.payload;
            let chosenMode = state.mode.mode || '';
            let pages = state.pages.pages || [];
            let selected = new Set((state.mode.capture_page_ids || []).map(Number));
            let filter = 'all';
            const api = (path, opts = {}) => fetch(cfg.root + path, Object.assign({
                headers: {'Content-Type':'application/json','X-WP-Nonce':cfg.nonce}
            }, opts)).then(r => r.json());
            document.querySelectorAll('[data-open-panel]').forEach(btn => btn.addEventListener('click', () => {
                const panel = btn.dataset.openPanel;
                document.querySelector('[data-panel="'+panel+'"]').classList.remove('is-collapsed');
                api('/ui', {method:'POST', body:JSON.stringify(panel === 'setup' ? {setup_collapsed:false} : {mode_collapsed:false})});
            }));
            document.querySelectorAll('[data-collapse-panel]').forEach(btn => btn.addEventListener('click', () => {
                const panel = btn.dataset.collapsePanel;
                document.querySelector('[data-panel="'+panel+'"]').classList.add('is-collapsed');
                api('/ui', {method:'POST', body:JSON.stringify(panel === 'setup' ? {setup_collapsed:true} : {mode_collapsed:true})});
            }));
            document.querySelectorAll('.copy').forEach(btn => btn.addEventListener('click', () => {
                const original = btn.dataset.label || btn.textContent;
                btn.dataset.label = original;
                navigator.clipboard && navigator.clipboard.writeText(btn.dataset.copy || '');
                btn.textContent = 'Copied';
                setTimeout(() => btn.textContent = original, 1200);
            }));
            const gscButton = document.getElementById('singularityGscButton');
            if (gscButton) gscButton.addEventListener('click', () => {
                const value = document.getElementById('singularityGscInput').value.trim();
                if (!value) return;
                gscButton.textContent = 'Connecting...';
                api('/setup-status', {method:'POST', body:JSON.stringify({google_search_console_property_url:value})}).then(() => location.reload());
            });
            document.querySelectorAll('.mode-card').forEach(card => card.addEventListener('click', () => {
                chosenMode = card.dataset.mode;
                document.querySelectorAll('.mode-card').forEach(c => c.classList.remove('is-selected'));
                card.classList.add('is-selected');
                document.getElementById('singularityModeHint').textContent = chosenMode === 'capture' ? 'Choose the pages Singularity should manage.' : 'Mode selected. This is enforced server side for management scope.';
                document.getElementById('singularityApplyMode').textContent = chosenMode === 'capture' ? 'Choose pages' : 'Apply mode';
            }));
            const applyMode = document.getElementById('singularityApplyMode');
            if (applyMode) applyMode.addEventListener('click', () => {
                if (chosenMode === 'capture') { openCapture(false); return; }
                if (!chosenMode) return;
                api('/mode', {method:'POST', body:JSON.stringify({mode:chosenMode})}).then(() => location.reload());
            });
            const manageRest = document.getElementById('singularityManageRest');
            if (manageRest) manageRest.addEventListener('click', () => openCapture(true));
            function openCapture(onlyUnmanaged){
                chosenMode = 'capture';
                document.getElementById('singularityModeCards').hidden = true;
                document.getElementById('singularityCapturePicker').hidden = false;
                document.getElementById('singularityApplyMode').hidden = true;
                if (onlyUnmanaged) filter = 'unmanaged';
                renderPages();
            }
            const back = document.getElementById('captureBack');
            if (back) back.addEventListener('click', () => {
                document.getElementById('singularityModeCards').hidden = false;
                document.getElementById('singularityCapturePicker').hidden = true;
                document.getElementById('singularityApplyMode').hidden = false;
            });
            document.querySelectorAll('.chip').forEach(chip => chip.addEventListener('click', () => {
                filter = chip.dataset.filter;
                document.querySelectorAll('.chip').forEach(c => c.classList.remove('is-on'));
                chip.classList.add('is-on');
                renderPages();
            }));
            const search = document.getElementById('captureSearch');
            if (search) search.addEventListener('input', renderPages);
            const all = document.getElementById('captureSelectVisible');
            if (all) all.addEventListener('change', () => {
                visiblePages().forEach(page => all.checked ? selected.add(Number(page.id)) : selected.delete(Number(page.id)));
                renderPages();
            });
            const captureApply = document.getElementById('captureApply');
            if (captureApply) captureApply.addEventListener('click', () => {
                api('/mode', {method:'POST', body:JSON.stringify({mode:'capture', capture_page_ids:Array.from(selected)})}).then(() => location.reload());
            });
            function visiblePages(){
                const q = (document.getElementById('captureSearch')?.value || '').toLowerCase();
                return pages.filter(page => {
                    if (filter === 'unmanaged' && page.managed) return false;
                    if (filter === 'issues' && (!page.issues || !page.issues.length)) return false;
                    return !q || String(page.title).toLowerCase().includes(q) || String(page.path).toLowerCase().includes(q);
                });
            }
            function renderPages(){
                const list = document.getElementById('captureList');
                if (!list) return;
                const visible = visiblePages();
                list.innerHTML = visible.map(page => {
                    const isSelected = selected.has(Number(page.id));
                    const issue = page.issues && page.issues.length ? page.issues[0] : '';
                    return '<div class="capture-row '+(isSelected?'is-selected':'')+'" data-id="'+page.id+'"><input type="checkbox" '+(isSelected?'checked':'')+' /><strong>'+escapeHtml(page.title)+'<small>'+escapeHtml(page.path || '')+'</small></strong><em class="'+(page.managed?'':'unmanaged')+'">'+(page.managed?'Managed':'Unmanaged')+'</em><b>'+escapeHtml(issue)+'</b></div>';
                }).join('') || '<div class="capture-row"><strong>No pages match<small>Adjust search or filters</small></strong></div>';
                list.querySelectorAll('.capture-row[data-id]').forEach(row => row.addEventListener('click', () => {
                    const id = Number(row.dataset.id);
                    selected.has(id) ? selected.delete(id) : selected.add(id);
                    renderPages();
                }));
                const count = selected.size;
                document.getElementById('captureCount').textContent = count;
                document.getElementById('captureConsequence').textContent = count ? 'Selected pages are managed. The rest keep their current SEO untouched.' : 'Choose which pages Singularity should manage.';
                captureApply.disabled = count < 1;
                captureApply.textContent = 'Bring '+count+' page'+(count === 1 ? '' : 's')+' under control';
            }
            function escapeHtml(value){
                return String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch]));
            }
            document.querySelectorAll('.advanced-fold>button').forEach(btn => btn.addEventListener('click', () => btn.parentElement.classList.toggle('is-open')));
            function openHashTarget(){
                const id = window.location.hash ? window.location.hash.slice(1) : '';
                if (!id) return;
                const target = document.getElementById(id);
                if (!target) return;
                if (target.tagName && target.tagName.toLowerCase() === 'details') {
                    target.open = true;
                }
                window.requestAnimationFrame(() => target.scrollIntoView({block:'start'}));
            }
            window.addEventListener('hashchange', openHashTarget);
            openHashTarget();
        })();
        </script>
        <?php
    }

    private function render_hero() {
        $logo_url = SMSEO_PLUGIN_URL . 'assets/singularity-seo-logo.png';

        echo '<section class="smseo-hero">';
        echo '<div class="smseo-hero-copy">';
        echo '<div class="smseo-eyebrow">Singularity SEO</div>';
        echo '<h1>AI-managed SEO control plane.</h1>';
        echo '<p>WordPress supplies the site state. ChatGPT works through the operating manual. Search data turns improvements into measurable visibility.</p>';
        echo '</div>';
        echo '<div class="smseo-brand-card">';
        printf( '<img src="%s" alt="Singularity SEO" />', esc_url( $logo_url ) );
        echo '<span>Artificial intelligence, real results.</span>';
        echo '</div>';
        echo '</section>';
    }

    private function render_metrics_panel() {
        $metrics_store = new Metrics_Store();
        $metrics = $metrics_store->get_metrics();
        $current = isset( $metrics['current'] ) && is_array( $metrics['current'] ) ? $metrics['current'] : null;
        $baseline = isset( $metrics['baseline'] ) && is_array( $metrics['baseline'] ) ? $metrics['baseline'] : null;
        $delta = isset( $metrics['delta'] ) ? $metrics['delta'] : null;
        $history = isset( $metrics['history'] ) && is_array( $metrics['history'] ) ? $metrics['history'] : array();
        $automation = isset( $metrics['automation'] ) && is_array( $metrics['automation'] ) ? $metrics['automation'] : array();

        echo '<section class="smseo-panel smseo-metrics" id="smseo-metrics">';
        echo '<div class="smseo-section-head">';
        echo '<div>';
        echo '<h2>SEO Health Metrics</h2>';
        echo '<p>Baseline and trend scoring from live technical SEO audits.</p>';
        echo '</div>';
        echo '<a class="button button-primary" href="#smseo-audit">Run New Snapshot</a>';
        echo '</div>';

        if ( ! $current ) {
            echo '<div class="smseo-empty-metrics">';
            echo '<strong>No health baseline yet.</strong>';
            echo '<p>Run the live audit once to create the first Singularity SEO health snapshot.</p>';
            echo '</div>';
            echo '</section>';
            return;
        }

        $summary = isset( $current['summary'] ) && is_array( $current['summary'] ) ? $current['summary'] : array();
        echo '<div class="smseo-metric-grid">';
        $this->render_metric_card( 'Current Score', (string) (int) $current['score'], isset( $current['grade'] ) ? (string) $current['grade'] : '' );
        $this->render_metric_card( 'Baseline', $baseline ? (string) (int) $baseline['score'] : '—', $baseline && isset( $baseline['captured_at'] ) ? $this->format_metric_date( $baseline['captured_at'] ) : 'Not captured' );
        $this->render_metric_card( 'Change', null === $delta ? '—' : ( ( $delta > 0 ? '+' : '' ) . (string) (int) $delta ), 'points since baseline' );
        $this->render_metric_card( 'Open Issues', isset( $summary['issue_count'] ) ? (string) (int) $summary['issue_count'] : '0', 'latest audit flags' );
        echo '</div>';

        $this->render_score_trend( $history );
        $this->render_metrics_automation_status( $automation );

        if ( ! empty( $current['top_issues'] ) && is_array( $current['top_issues'] ) ) {
            echo '<table class="widefat striped smseo-status smseo-issues-table"><thead><tr><th>Top issue</th><th>Pages</th></tr></thead><tbody>';
            foreach ( $current['top_issues'] as $issue ) {
                printf(
                    '<tr><td>%s</td><td>%d</td></tr>',
                    esc_html( isset( $issue['issue'] ) ? (string) $issue['issue'] : '' ),
                    isset( $issue['count'] ) ? (int) $issue['count'] : 0
                );
            }
            echo '</tbody></table>';
        }

        printf(
            '<p class="smseo-muted">Last snapshot: %s. Snapshots stored: %d.</p>',
            esc_html( isset( $current['captured_at'] ) ? $this->format_metric_date( $current['captured_at'] ) . ' (' . $this->relative_metric_time( $current['captured_at'] ) . ')' : 'unknown' ),
            isset( $metrics['snapshot_count'] ) ? (int) $metrics['snapshot_count'] : 0
        );
        echo '</section>';
    }

    private function render_metrics_automation_status( $automation ) {
        $enabled = ! empty( $automation['enabled'] );
        $next_run = isset( $automation['next_run_gmt'] ) ? (string) $automation['next_run_gmt'] : '';
        $last_run = isset( $automation['last_run_gmt'] ) ? (string) $automation['last_run_gmt'] : '';
        $last_error = isset( $automation['last_error'] ) ? (string) $automation['last_error'] : '';

        echo '<table class="widefat striped smseo-status smseo-automation-table"><tbody>';
        printf( '<tr><th>Automatic snapshots</th><td>%s</td></tr>', esc_html( $enabled ? 'Daily' : 'Not scheduled' ) );
        printf( '<tr><th>Next scheduled run</th><td>%s</td></tr>', esc_html( '' !== $next_run ? $this->format_metric_date( $next_run ) : 'Not scheduled' ) );
        printf( '<tr><th>Last automatic run</th><td>%s</td></tr>', esc_html( '' !== $last_run ? $this->format_metric_date( $last_run ) . ' (' . $this->relative_metric_time( $last_run ) . ')' : 'Not run yet' ) );
        if ( '' !== $last_error ) {
            printf( '<tr><th>Last automation error</th><td>%s</td></tr>', esc_html( $last_error ) );
        }
        echo '</tbody></table>';
    }

    private function render_metric_card( $label, $value, $note ) {
        echo '<div class="smseo-metric-card">';
        printf( '<span>%s</span>', esc_html( $label ) );
        printf( '<strong>%s</strong>', esc_html( $value ) );
        printf( '<small>%s</small>', esc_html( $note ) );
        echo '</div>';
    }

    private function render_visibility_panel() {
        $visibility_store = new Visibility_Store();
        $visibility = $visibility_store->get_metrics();
        $providers = isset( $visibility['providers'] ) && is_array( $visibility['providers'] ) ? $visibility['providers'] : array();
        $automation = isset( $visibility['automation'] ) && is_array( $visibility['automation'] ) ? $visibility['automation'] : array();
        $config = isset( $visibility['config'] ) && is_array( $visibility['config'] ) ? $visibility['config'] : array();
        $current = isset( $visibility['current'] ) && is_array( $visibility['current'] ) ? $visibility['current'] : null;
        $baseline = isset( $visibility['baseline'] ) && is_array( $visibility['baseline'] ) ? $visibility['baseline'] : null;
        $deltas = isset( $visibility['deltas'] ) && is_array( $visibility['deltas'] ) ? $visibility['deltas'] : array();
        $goals = isset( $visibility['goals'] ) && is_array( $visibility['goals'] ) ? $visibility['goals'] : array();
        $gsc = isset( $providers['google_search_console'] ) && is_array( $providers['google_search_console'] ) ? $providers['google_search_console'] : array();
        $rank = isset( $providers['rank_provider'] ) && is_array( $providers['rank_provider'] ) ? $providers['rank_provider'] : array();
        $cadence = isset( $config['cadence']['frequency'] ) ? (string) $config['cadence']['frequency'] : 'daily';
        $keyword_count = isset( $config['target_keywords'] ) && is_array( $config['target_keywords'] ) ? count( $config['target_keywords'] ) : 0;
        $search_console = isset( $current['search_console'] ) && is_array( $current['search_console'] ) ? $current['search_console'] : array();
        $rankings = isset( $current['rankings'] ) && is_array( $current['rankings'] ) ? $current['rankings'] : array();
        $latest_rankings = $this->latest_visibility_rankings( $visibility_store->get_snapshots() );
        if ( ! empty( $latest_rankings ) ) {
            $rankings = $latest_rankings;
        }

        echo '<section class="smseo-panel smseo-visibility" id="smseo-visibility">';
        echo '<div class="smseo-section-head">';
        echo '<div>';
        echo '<h2>Visibility Metrics</h2>';
        echo '<p>Daily search visibility and ranking framework for Google Search Console and tracked keyword movement.</p>';
        echo '</div>';
        printf(
            '<strong class="smseo-status-pill %s">%s</strong>',
            ! empty( $gsc['connected'] ) || ! empty( $rank['connected'] ) ? 'smseo-status-ready' : 'smseo-status-action',
            ! empty( $gsc['connected'] ) || ! empty( $rank['connected'] ) ? 'Provider connected' : 'Provider needed'
        );
        echo '</div>';

        echo '<div class="smseo-metric-grid">';
        $this->render_metric_card( 'Clicks', $this->visibility_number( isset( $search_console['clicks'] ) ? $search_console['clicks'] : null ), $this->visibility_delta_note( $deltas, 'clicks', 'more is better' ) );
        $this->render_metric_card( 'Impressions', $this->visibility_number( isset( $search_console['impressions'] ) ? $search_console['impressions'] : null ), $this->visibility_delta_note( $deltas, 'impressions', 'more is better' ) );
        $this->render_metric_card( 'Avg. Position', $this->visibility_number( isset( $search_console['average_position'] ) ? $search_console['average_position'] : null ), $this->visibility_delta_note( $deltas, 'average_position', 'lower is better' ) );
        $this->render_metric_card( 'Avg. Rank', $this->visibility_number( isset( $rankings['average_rank'] ) ? $rankings['average_rank'] : null ), $this->visibility_delta_note( $deltas, 'average_rank', 'lower is better' ) );
        echo '</div>';

        echo '<div class="smseo-metric-grid smseo-provider-grid">';
        $this->render_metric_card( 'Search Console', ! empty( $gsc['connected'] ) ? 'Connected' : 'Not connected', isset( $gsc['property_url'] ) && '' !== $gsc['property_url'] ? (string) $gsc['property_url'] : 'Google data pending' );
        $this->render_metric_card( 'Rank Provider', ! empty( $rank['connected'] ) ? 'Connected' : 'Not connected', isset( $rank['provider'] ) && '' !== $rank['provider'] ? (string) $rank['provider'] : 'SERP API pending' );
        $this->render_metric_card( 'Ranking Domain', isset( $rank['target_domain'] ) && '' !== (string) $rank['target_domain'] ? (string) $rank['target_domain'] : 'Not set', 'public domain checked in search results' );
        $this->render_metric_card( 'Rank Depth', isset( $rankings['result_depth'] ) && null !== $rankings['result_depth'] ? 'Top ' . (int) $rankings['result_depth'] : 'Pending', 'organic results checked per keyword' );
        $this->render_metric_card( 'Cadence', str_replace( '_', ' ', ucfirst( $cadence ) ), 'standard once daily' );
        $this->render_metric_card( 'Keywords', (string) $keyword_count, 'tracked targets configured' );
        echo '</div>';

        $this->render_keyword_rankings_table( $config, $rankings );

        if ( ! empty( $rankings['keywords'] ) && is_array( $rankings['keywords'] ) ) {
            $rank_notes = array();
            foreach ( $rankings['keywords'] as $keyword ) {
                if ( ! is_array( $keyword ) ) {
                    continue;
                }
                $label = isset( $keyword['keyword'] ) ? (string) $keyword['keyword'] : '';
                if ( '' === $label ) {
                    continue;
                }
                if ( isset( $keyword['rank'] ) && null !== $keyword['rank'] ) {
                    $rank_notes[] = sprintf( '%s: #%d', $label, (int) $keyword['rank'] );
                    continue;
                }
                if ( ! empty( $keyword['message'] ) ) {
                    $rank_notes[] = sprintf( '%s: %s', $label, (string) $keyword['message'] );
                }
            }
            if ( ! empty( $rank_notes ) ) {
                printf( '<p class="smseo-muted">Latest ranking check: %s</p>', esc_html( implode( '; ', $rank_notes ) ) );
            }
        }

        if ( $baseline && $current ) {
            printf(
                '<p class="smseo-muted">Visibility trend: traffic %s; rankings %s.</p>',
                esc_html( isset( $goals['traffic_trend'] ) ? (string) $goals['traffic_trend'] : 'pending' ),
                esc_html( isset( $goals['ranking_trend'] ) ? (string) $goals['ranking_trend'] : 'pending' )
            );
        }

        if ( $current ) {
            printf(
                '<p class="smseo-muted">Last visibility snapshot: %s. Status: %s.</p>',
                esc_html( isset( $current['captured_at'] ) ? $this->format_metric_date( $current['captured_at'] ) . ' (' . $this->relative_metric_time( $current['captured_at'] ) . ')' : 'unknown' ),
                esc_html( isset( $current['status'] ) ? (string) $current['status'] : 'unknown' )
            );
        } else {
            echo '<div class="smseo-empty-metrics"><strong>No visibility baseline yet.</strong><p>Connect Google Search Console and a rank provider to begin daily visibility snapshots.</p></div>';
        }

        $this->render_visibility_automation_status( $automation );
        echo '</section>';
    }

    private function latest_visibility_rankings( $snapshots ) {
        $snapshots = is_array( $snapshots ) ? array_reverse( $snapshots ) : array();
        foreach ( $snapshots as $snapshot ) {
            if ( ! is_array( $snapshot ) || empty( $snapshot['rankings'] ) || ! is_array( $snapshot['rankings'] ) ) {
                continue;
            }
            $rankings = $snapshot['rankings'];
            $has_keywords = ! empty( $rankings['keywords'] ) && is_array( $rankings['keywords'] );
            $has_average = isset( $rankings['average_rank'] ) && null !== $rankings['average_rank'];
            if ( ! $has_keywords && ! $has_average ) {
                continue;
            }
            $rankings['snapshot_id'] = isset( $snapshot['id'] ) ? (string) $snapshot['id'] : '';
            $rankings['captured_at'] = isset( $snapshot['captured_at'] ) ? (string) $snapshot['captured_at'] : '';
            return $rankings;
        }

        return array();
    }

    private function render_keyword_rankings_table( $config, $rankings ) {
        $keywords = isset( $config['target_keywords'] ) && is_array( $config['target_keywords'] )
            ? array_values( array_filter( $config['target_keywords'] ) )
            : array();
        if ( empty( $keywords ) ) {
            return;
        }

        $ranking_rows = array();
        if ( isset( $rankings['keywords'] ) && is_array( $rankings['keywords'] ) ) {
            foreach ( $rankings['keywords'] as $row ) {
                if ( ! is_array( $row ) || empty( $row['keyword'] ) ) {
                    continue;
                }
                $ranking_rows[ strtolower( trim( (string) $row['keyword'] ) ) ] = $row;
            }
        }

        $snapshot_label = '';
        if ( ! empty( $rankings['captured_at'] ) ) {
            $snapshot_label = $this->format_metric_date( $rankings['captured_at'] ) . ' (' . $this->relative_metric_time( $rankings['captured_at'] ) . ')';
        }

        echo '<div class="smseo-keyword-rankings">';
        echo '<div class="smseo-keyword-rankings-head">';
        echo '<div><h3>Tracked Keyword Rankings</h3><p>Configured launch keywords and the latest stored rank result. This table does not run a search.</p></div>';
        printf( '<span>%s</span>', esc_html( '' !== $snapshot_label ? 'Last rank snapshot: ' . $snapshot_label : 'No rank snapshot yet' ) );
        echo '</div>';
        echo '<table class="widefat striped smseo-keyword-rank-table">';
        echo '<thead><tr><th>Keyword</th><th>Current rank</th><th>Status</th><th>Matched URL</th><th>Depth</th></tr></thead><tbody>';

        foreach ( $keywords as $keyword ) {
            $keyword = trim( (string) $keyword );
            $row = isset( $ranking_rows[ strtolower( $keyword ) ] ) ? $ranking_rows[ strtolower( $keyword ) ] : array();
            $rank = isset( $row['rank'] ) ? $row['rank'] : null;
            $status = isset( $row['status'] ) && '' !== (string) $row['status'] ? (string) $row['status'] : '';
            $message = isset( $row['message'] ) && '' !== (string) $row['message'] ? (string) $row['message'] : '';
            $url = isset( $row['url'] ) ? (string) $row['url'] : '';
            $depth = isset( $row['checked_depth'] ) && null !== $row['checked_depth']
                ? (string) (int) $row['checked_depth']
                : ( isset( $rankings['result_depth'] ) && null !== $rankings['result_depth'] ? (string) (int) $rankings['result_depth'] : 'Pending' );

            if ( null !== $rank && '' !== (string) $rank ) {
                $rank_display = '#' . number_format_i18n( (float) $rank, 0 );
                $status_display = '' !== $status ? $this->visibility_status_label( $status ) : 'Found';
            } elseif ( '' !== $message ) {
                $rank_display = 'Not found';
                $status_display = $message;
            } elseif ( '' !== $status ) {
                $rank_display = 'Not found';
                $status_display = $this->visibility_status_label( $status );
            } else {
                $rank_display = 'Pending';
                $status_display = 'Waiting for first rank refresh';
            }

            echo '<tr>';
            printf( '<td><strong>%s</strong></td>', esc_html( $keyword ) );
            printf( '<td>%s</td>', esc_html( $rank_display ) );
            printf( '<td>%s</td>', esc_html( $status_display ) );
            if ( '' !== $url ) {
                printf( '<td><a href="%s" target="_blank" rel="noopener">%s</a></td>', esc_url( $url ), esc_html( $url ) );
            } else {
                echo '<td><span class="smseo-muted">No matched URL</span></td>';
            }
            printf( '<td>%s</td>', esc_html( $depth ) );
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</div>';
    }

    private function visibility_status_label( $status ) {
        $status = str_replace( '_', ' ', sanitize_key( (string) $status ) );
        return '' !== $status ? ucwords( $status ) : 'Pending';
    }

    private function visibility_number( $value ) {
        if ( null === $value || '' === $value ) {
            return 'Pending';
        }

        return is_numeric( $value ) ? number_format_i18n( (float) $value, is_float( $value ) ? 2 : 0 ) : (string) $value;
    }

    private function visibility_delta_note( $deltas, $key, $fallback ) {
        if ( isset( $deltas[ $key ]['delta'] ) && null !== $deltas[ $key ]['delta'] ) {
            $delta = (float) $deltas[ $key ]['delta'];
            return ( $delta > 0 ? '+' : '' ) . number_format_i18n( $delta, 2 ) . ' from baseline';
        }

        return $fallback;
    }

    private function render_visibility_automation_status( $automation ) {
        $enabled = ! empty( $automation['enabled'] );
        $next_run = isset( $automation['next_run_gmt'] ) ? (string) $automation['next_run_gmt'] : '';
        $last_run = isset( $automation['last_run_gmt'] ) ? (string) $automation['last_run_gmt'] : '';
        $last_error = isset( $automation['last_error'] ) ? (string) $automation['last_error'] : '';

        echo '<table class="widefat striped smseo-status smseo-automation-table"><tbody>';
        printf( '<tr><th>Automatic visibility updates</th><td>%s</td></tr>', esc_html( $enabled ? 'Daily' : 'Not scheduled' ) );
        printf( '<tr><th>Next scheduled run</th><td>%s</td></tr>', esc_html( '' !== $next_run ? $this->format_metric_date( $next_run ) : 'Not scheduled' ) );
        printf( '<tr><th>Last automatic run</th><td>%s</td></tr>', esc_html( '' !== $last_run ? $this->format_metric_date( $last_run ) . ' (' . $this->relative_metric_time( $last_run ) . ')' : 'Not run yet' ) );
        if ( '' !== $last_error ) {
            printf( '<tr><th>Last visibility error</th><td>%s</td></tr>', esc_html( $last_error ) );
        }
        echo '</tbody></table>';
    }

    private function render_score_trend( $history ) {
        $points = array_slice( is_array( $history ) ? $history : array(), -8 );
        if ( empty( $points ) ) {
            return;
        }

        echo '<div class="smseo-score-trend" aria-label="SEO health score trend">';
        foreach ( $points as $point ) {
            $score = isset( $point['score'] ) ? max( 0, min( 100, (int) $point['score'] ) ) : 0;
            printf(
                '<div class="smseo-score-bar" title="%s: %d"><span style="height:%d%%"></span><small>%d</small></div>',
                esc_attr( isset( $point['captured_at'] ) ? $this->format_metric_date( $point['captured_at'] ) : '' ),
                $score,
                $score,
                $score
            );
        }
        echo '</div>';
    }

    private function format_metric_date( $mysql_gmt ) {
        $timestamp = strtotime( (string) $mysql_gmt . ' UTC' );
        if ( ! $timestamp ) {
            return (string) $mysql_gmt;
        }

        return wp_date( 'M j, Y g:i A', $timestamp );
    }

    private function relative_metric_time( $mysql_gmt ) {
        $timestamp = strtotime( (string) $mysql_gmt . ' UTC' );
        if ( ! $timestamp ) {
            return 'unknown';
        }

        return human_time_diff( $timestamp, time() ) . ' ago';
    }

    private function default_controller_url() {
        return 'https://controller-nq6p.onrender.com/sse/';
    }

    private function controller_origin( $controller_url ) {
        $parts = wp_parse_url( (string) $controller_url );
        if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
            return '';
        }

        $port = isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '';
        return $parts['scheme'] . '://' . $parts['host'] . $port;
    }

    private function signed_controller_payload( $customer_id ) {
        $customer_id = sanitize_key( (string) $customer_id );
        $site_url = home_url( '/' );
        $timestamp = (string) time();
        $token = trim( (string) get_option( API::BRIDGE_TOKEN_OPTION, '' ) );
        if ( '' === $customer_id || strlen( $token ) < 24 ) {
            return array();
        }

        $message = $customer_id . '|' . $timestamp . '|' . $site_url;
        return array(
            'customer_id' => $customer_id,
            'site_url'    => $site_url,
            'ts'          => $timestamp,
            'signature'   => hash_hmac( 'sha256', $message, $token ),
        );
    }

    private function google_search_console_oauth_url( $customer_id, $controller_url ) {
        $origin = $this->controller_origin( $controller_url );
        $signed = $this->signed_controller_payload( $customer_id );
        if ( '' === $origin || empty( $signed ) ) {
            return '';
        }

        $visibility_store = new Visibility_Store();
        $visibility_config = $visibility_store->get_config();
        $property_url = isset( $visibility_config['google_search_console_property_url'] )
            ? Validation::sanitize_search_console_property( (string) $visibility_config['google_search_console_property_url'] )
            : '';
        if ( false === $property_url || '' === $property_url ) {
            $property_url = home_url( '/' );
        }

        $signed['return_url'] = admin_url( 'admin.php?page=' . self::MENU_SLUG );
        $signed['property_url'] = $property_url;
        return add_query_arg( $signed, $origin . '/integrations/google/search-console/start' );
    }

    private function default_customer_id() {
        $stored = trim( (string) get_option( self::CUSTOMER_ID_OPTION, '' ) );
        if ( '' !== $stored ) {
            $stored = sanitize_key( $stored );
            if ( $this->is_opaque_customer_id( $stored ) ) {
                return $stored;
            }
        }

        $customer_id = $this->new_opaque_customer_id();
        update_option( self::CUSTOMER_ID_OPTION, $customer_id, false );
        if ( '' !== $stored ) {
            update_option( self::HOSTED_CONNECTION_STATUS_OPTION, 'verifying', false );
            update_option( self::HOSTED_CONNECTION_MESSAGE_OPTION, 'Secure ChatGPT connection code rotated. Refresh the ChatGPT link before connecting this site.', false );
            delete_transient( self::AUTO_CONNECT_COOLDOWN_TRANSIENT );
        }

        return $customer_id;
    }

    private function is_opaque_customer_id( $customer_id ) {
        return 1 === preg_match( '/^' . preg_quote( self::CUSTOMER_ID_PREFIX, '/' ) . '[a-z0-9]{32}$/', (string) $customer_id );
    }

    private function new_opaque_customer_id() {
        $raw = function_exists( 'wp_generate_password' )
            ? wp_generate_password( 40, false, false )
            : ( function_exists( 'wp_generate_uuid4' ) ? str_replace( '-', '', wp_generate_uuid4() ) : uniqid( '', true ) );
        $raw = strtolower( preg_replace( '/[^a-z0-9]/', '', (string) $raw ) );
        if ( strlen( $raw ) < 32 ) {
            $raw .= md5( uniqid( '', true ) );
        }

        return self::CUSTOMER_ID_PREFIX . substr( $raw, 0, 32 );
    }

    private function maybe_auto_connect() {
        $customer_id = $this->default_customer_id();
        if ( $this->is_connected() || get_transient( self::AUTO_CONNECT_COOLDOWN_TRANSIENT ) ) {
            return;
        }

        set_transient( self::AUTO_CONNECT_COOLDOWN_TRANSIENT, '1', 10 * MINUTE_IN_SECONDS );
        $controller_url = trim( (string) get_option( self::CONTROLLER_URL_OPTION, $this->default_controller_url() ) );
        $this->queue_hosted_onboarding( $customer_id, $controller_url );
    }

    private function connect_site( $customer_id, $controller_url, $show_new_token_notice, $create_baseline, $timeout = 30 ) {
        $customer_id = sanitize_key( (string) $customer_id );
        $controller_url = esc_url_raw( (string) $controller_url );

        if ( '' === $customer_id || ! $this->is_opaque_customer_id( $customer_id ) ) {
            $customer_id = $this->default_customer_id();
        }
        if ( '' === $controller_url ) {
            $controller_url = $this->default_controller_url();
        }

        update_option( self::CUSTOMER_ID_OPTION, $customer_id, false );
        update_option( self::CONTROLLER_URL_OPTION, $controller_url, false );

        $generated_token = trim( (string) get_option( API::BRIDGE_TOKEN_OPTION, '' ) );
        if ( '' === $generated_token ) {
            $generated_token = wp_generate_password( 48, false, false );
            update_option( API::BRIDGE_TOKEN_OPTION, $generated_token, false );
        }

        $onboarding_result = $this->submit_hosted_onboarding( $customer_id, $controller_url, $generated_token, $timeout );
        update_option( self::HOSTED_CONNECTION_STATUS_OPTION, ! empty( $onboarding_result['ok'] ) ? 'verified' : 'failed', false );
        update_option( self::HOSTED_CONNECTION_MESSAGE_OPTION, isset( $onboarding_result['message'] ) ? (string) $onboarding_result['message'] : '', false );
        if ( $create_baseline && ! empty( $onboarding_result['ok'] ) ) {
            $metrics_store = new Metrics_Store();
            if ( ! $metrics_store->get_current_snapshot() ) {
                $auditor = new Audit_Service( $this->registry, $this->campaign_manager );
                $results = $auditor->run_live_head_audit();
                $metrics_store->create_snapshot( $results, 'connect_baseline' );
                set_transient( 'smseo_live_audit_' . get_current_user_id(), $results, 10 * MINUTE_IN_SECONDS );
            }
        }

        set_transient(
            'smseo_onboarding_result_' . get_current_user_id(),
            $onboarding_result,
            10 * MINUTE_IN_SECONDS
        );

        return $onboarding_result;
    }

    private function render_customer_setup_panel() {
        $controller_url = trim( (string) get_option( self::CONTROLLER_URL_OPTION, $this->default_controller_url() ) );
        $customer_id = $this->default_customer_id();
        $token_configured = '' !== trim( (string) get_option( API::BRIDGE_TOKEN_OPTION, '' ) );
        $metrics_store = new Metrics_Store();
        $last_snapshot = $metrics_store->get_current_snapshot();
        $visibility_store = new Visibility_Store();
        $visibility = $visibility_store->get_metrics();
        $visibility_config = isset( $visibility['config'] ) && is_array( $visibility['config'] ) ? $visibility['config'] : array();
        $visibility_providers = isset( $visibility['providers'] ) && is_array( $visibility['providers'] ) ? $visibility['providers'] : array();
        $gsc = isset( $visibility_providers['google_search_console'] ) && is_array( $visibility_providers['google_search_console'] ) ? $visibility_providers['google_search_console'] : array();
        $rank = isset( $visibility_providers['rank_provider'] ) && is_array( $visibility_providers['rank_provider'] ) ? $visibility_providers['rank_provider'] : array();
        $target_keywords = isset( $visibility_config['target_keywords'] ) && is_array( $visibility_config['target_keywords'] ) ? $visibility_config['target_keywords'] : array();
        $gsc_property_url = isset( $visibility_config['google_search_console_property_url'] ) ? (string) $visibility_config['google_search_console_property_url'] : '';
        $rank_provider_label = isset( $visibility_config['rank_provider'] ) ? (string) $visibility_config['rank_provider'] : '';
        $ranking_target_domain = isset( $visibility_config['ranking_target_domain'] ) && '' !== (string) $visibility_config['ranking_target_domain']
            ? (string) $visibility_config['ranking_target_domain']
            : (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
        $gsc_status_label = ! empty( $gsc['connected'] ) ? 'Connected' : ( '' !== $gsc_property_url ? 'Configured' : 'Not connected' );
        $rank_status_label = ! empty( $rank['connected'] ) ? 'Connected' : ( '' !== $rank_provider_label ? 'Configured' : 'Not connected' );
        $rest_status_url = rest_url( API::NAMESPACE . '/status' );
        $rest_pages_url = rest_url( API::NAMESPACE . '/pages' );
        $is_connected = $this->is_connected();
        $stored_status = (string) get_option( self::HOSTED_CONNECTION_STATUS_OPTION, '' );
        $stored_message = (string) get_option( self::HOSTED_CONNECTION_MESSAGE_OPTION, '' );
        $onboarding_result = get_transient( 'smseo_onboarding_result_' . get_current_user_id() );
        if ( ! is_array( $onboarding_result ) ) {
            $onboarding_result = array();
        }
        delete_transient( 'smseo_onboarding_result_' . get_current_user_id() );
        $setup_packet = $this->build_setup_packet( $customer_id, $controller_url, $rest_status_url, $rest_pages_url );

        echo '<section class="smseo-panel smseo-setup smseo-launch-console smseo-product-console" id="smseo-connect">';
        echo '<div class="smseo-product-head">';
        echo '<div>';
        echo '<h2>Setup</h2>';
        echo '<p>Install is complete. Singularity SEO now verifies WordPress automatically; the remaining customer steps are ChatGPT access and search data.</p>';
        echo '</div>';
        printf(
            '<strong class="smseo-status-pill %s">%s</strong>',
            $is_connected ? 'smseo-status-ready' : 'smseo-status-action',
            $is_connected ? 'WordPress connected' : 'Connection needs attention'
        );
        echo '</div>';

        if ( ! empty( $onboarding_result ) ) {
            $notice_type = isset( $onboarding_result['notice'] ) ? sanitize_key( (string) $onboarding_result['notice'] ) : '';
            $notice_class = ! empty( $onboarding_result['ok'] ) ? 'notice-success' : 'notice-error';
            if ( 'info' === $notice_type ) {
                $notice_class = 'notice-info';
            }
            $message = isset( $onboarding_result['message'] ) ? (string) $onboarding_result['message'] : '';
            printf(
                '<div class="notice %s inline"><p>%s</p></div>',
                esc_attr( $notice_class ),
                esc_html( $message )
            );
        }

        echo '<div class="smseo-chatgpt-link-card">';
        echo '<div class="smseo-link-orb" aria-hidden="true"><span>S</span></div>';
        echo '<div class="smseo-link-copy">';
        echo '<strong>Connect this site to ChatGPT</strong>';
        printf( '<p>%s</p>', esc_html( $is_connected ? 'WordPress is verified. Copy the secure ChatGPT command when you are ready to connect this site.' : 'Verify this WordPress site so ChatGPT can claim access to it.' ) );
        if ( $is_connected ) {
            printf( '<button type="button" class="button button-secondary copy" data-copy="Connect customer/site ID %s">Copy ChatGPT command</button>', esc_attr( $customer_id ) );
        } else {
            echo '<button type="button" class="button button-secondary" disabled>Verifying secure link</button>';
        }
        echo '</div>';
        echo '<form class="smseo-link-action-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_save_connection" />';
        wp_nonce_field( 'smseo_save_connection', 'smseo_connection_nonce' );
        printf( '<input type="hidden" name="smseo_customer_id" value="%s" />', esc_attr( $customer_id ) );
        printf( '<input type="hidden" name="smseo_controller_url" value="%s" />', esc_attr( $controller_url ) );
        submit_button( $is_connected ? 'Refresh ChatGPT Link' : 'Verify WordPress Site', 'primary smseo-big-go-button', 'submit', false );
        echo '</form>';
        echo '</div>';

        echo '<div class="smseo-primary-steps">';
        echo '<article class="smseo-primary-step">';
        echo '<span class="smseo-step-number">1</span>';
        echo '<div class="smseo-step-body">';
        echo '<h3>WordPress verification</h3>';
        printf( '<p>%s</p>', esc_html( $is_connected ? 'Hosted verification is complete. The secure ChatGPT command is ready to copy.' : 'Hosted verification has not completed yet. Use the connect panel above.' ) );
        echo '</div>';
        printf( '<strong class="smseo-step-state %s">%s</strong>', $is_connected ? 'is-done' : 'needs-work', esc_html( $is_connected ? 'Ready' : 'Verify' ) );
        echo '</article>';

        echo '<article class="smseo-primary-step smseo-chatgpt-step">';
        echo '<span class="smseo-step-number">2</span>';
        echo '<div class="smseo-step-body">';
        echo '<h3>ChatGPT access</h3>';
        echo '<p>After refreshing the link, copy the secure ChatGPT command and paste it into the Singularity SEO ChatGPT app.</p>';
        echo '<div class="smseo-site-id"><span>Connection code</span><code>Hidden until copied</code></div>';
        if ( $is_connected ) {
            printf( '<p class="smseo-command"><button type="button" class="button button-secondary copy" data-copy="Connect customer/site ID %s">Copy ChatGPT command</button></p>', esc_attr( $customer_id ) );
        } else {
            echo '<p class="smseo-command"><button type="button" class="button button-secondary" disabled>Verifying secure link</button></p>';
        }
        echo '</div>';
        printf( '<strong class="smseo-step-state %s">%s</strong>', $is_connected ? 'is-ready' : 'needs-work', esc_html( $is_connected ? 'Ready' : 'Waiting' ) );
        echo '</article>';

        echo '<article class="smseo-primary-step smseo-search-step">';
        echo '<span class="smseo-step-number">3</span>';
        echo '<div class="smseo-step-body">';
        echo '<h3>Search data</h3>';
        echo '<p>Set up Google Search Console and rank tracking here so health gains can turn into traffic and ranking trends. The WordPress launch plan includes up to three tracked keywords.</p>';
        echo '<div class="smseo-provider-status">';
        printf( '<span><strong>Search Console</strong>%s</span>', esc_html( $gsc_status_label ) );
        printf( '<span><strong>Rank tracking</strong>%s</span>', esc_html( $rank_status_label ) );
        echo '</div>';
        echo '<form class="smseo-search-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_save_visibility_setup" />';
        wp_nonce_field( 'smseo_save_visibility_setup', 'smseo_visibility_nonce' );
        printf(
            '<label class="smseo-field"><span>Website or Search Console property</span><input type="text" name="smseo_gsc_property_url" value="%s" placeholder="%s" /><small>Most customers can enter their website URL. Singularity matches the verified Search Console property during Google sign-in.</small></label>',
            esc_attr( $gsc_property_url ),
            esc_attr( home_url( '/' ) )
        );
        printf(
            '<label class="smseo-field"><span>Rank provider</span><input type="text" name="smseo_rank_provider" value="%s" placeholder="DataForSEO, SerpApi, Semrush..." /></label>',
            esc_attr( $rank_provider_label )
        );
        printf(
            '<label class="smseo-field"><span>Ranking domain</span><input type="text" name="smseo_ranking_target_domain" value="%s" placeholder="%s" /></label>',
            esc_attr( $ranking_target_domain ),
            esc_attr( wp_parse_url( home_url( '/' ), PHP_URL_HOST ) )
        );
        printf(
            '<label class="smseo-field smseo-wide-field"><span>Tracked keywords</span><textarea name="smseo_target_keywords" rows="3" placeholder="One keyword per line. Up to three are included.">%s</textarea><small>Leave blank and Singularity SEO will start with one site-name keyword. Add up to three when you are ready.</small></label>',
            esc_textarea( implode( "\n", $target_keywords ) )
        );
        submit_button( 'Save Search Data Setup', 'primary', 'submit', false );
        echo '</form>';
        echo '</div>';
        printf( '<strong class="smseo-step-state %s">%s</strong>', ( ! empty( $gsc['connected'] ) || ! empty( $rank['connected'] ) ) ? 'is-ready' : 'needs-work', esc_html( ( ! empty( $gsc['connected'] ) || ! empty( $rank['connected'] ) ) ? 'Ready' : 'Needed' ) );
        echo '</article>';
        echo '</div>';

        echo '<div class="smseo-launch-summary">';
        printf( '<span><strong>WordPress</strong>%s</span>', esc_html( $this->connection_status_label( $stored_status, $token_configured ) ) );
        printf(
            '<span><strong>Health</strong>%s</span>',
            esc_html( $last_snapshot && isset( $last_snapshot['captured_at'] ) ? $this->relative_metric_time( $last_snapshot['captured_at'] ) : 'Not run yet' )
        );
        printf( '<span><strong>Search data</strong>%s</span>', esc_html( ( ! empty( $gsc['connected'] ) || ! empty( $rank['connected'] ) ) ? 'Provider connected' : ( ( '' !== $gsc_property_url || '' !== $rank_provider_label ) ? 'Targets configured' : 'Provider needed' ) ) );
        echo '</div>';

        echo '<details class="smseo-support-details">';
        echo '<summary>Support details</summary>';
        echo '<table class="widefat striped smseo-status smseo-copy-table"><tbody>';
        printf( '<tr><th>Connection status</th><td>%s</td></tr>', esc_html( $this->connection_status_label( $stored_status, $token_configured ) ) );
        if ( '' !== $stored_message ) {
            printf( '<tr><th>Last hosted response</th><td>%s</td></tr>', esc_html( $stored_message ) );
        }
        printf(
            '<tr><th>Last health snapshot</th><td>%s</td></tr>',
            esc_html( $last_snapshot && isset( $last_snapshot['captured_at'] ) ? $this->format_metric_date( $last_snapshot['captured_at'] ) . ' (' . $this->relative_metric_time( $last_snapshot['captured_at'] ) . ')' : 'Not run yet' )
        );
        printf( '<tr><th>Site status URL</th><td><code>%s</code></td></tr>', esc_html( $rest_status_url ) );
        printf( '<tr><th>Managed pages URL</th><td><code>%s</code></td></tr>', esc_html( $rest_pages_url ) );
        printf( '<tr><th>ChatGPT app URL</th><td><code>%s</code></td></tr>', esc_html( $controller_url ) );
        echo '</tbody></table>';

        echo '<label class="smseo-field smseo-packet-field"><span>Launch connection details</span>';
        printf( '<textarea class="large-text code" rows="8" readonly>%s</textarea>', esc_textarea( $setup_packet ) );
        echo '<p class="description">Support fallback only. Normal customer setup uses the Copy ChatGPT command button so the connection code is not displayed.</p>';
        echo '</label>';
        echo '<form class="smseo-controller-url-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_save_connection" />';
        wp_nonce_field( 'smseo_save_connection', 'smseo_connection_nonce' );
        printf( '<input type="hidden" name="smseo_customer_id" value="%s" />', esc_attr( $customer_id ) );
        printf(
            '<label class="smseo-field"><span>Connection URL</span><input type="url" class="large-text" name="smseo_controller_url" value="%s" placeholder="https://controller.example.com/sse/" /></label>',
            esc_attr( $controller_url )
        );
        submit_button( 'Save Support URL', 'secondary', 'submit', false );
        echo '</form>';
        echo '</details>';

        echo '</section>';
    }

    private function render_takeover_panel( $just_scanned = false ) {
        $takeover_store = new Takeover_Store( $this->registry );
        $report = $takeover_store->get_report();
        $current = isset( $report['current'] ) && is_array( $report['current'] ) ? $report['current'] : null;
        $summary = $current && isset( $current['summary'] ) && is_array( $current['summary'] ) ? $current['summary'] : array();
        $recommendations = $current && isset( $current['recommendations'] ) && is_array( $current['recommendations'] ) ? $current['recommendations'] : array();
        $pages = $current && isset( $current['pages'] ) && is_array( $current['pages'] ) ? $current['pages'] : array();
        $detected_plugins = $current && isset( $current['detected_plugins'] ) && is_array( $current['detected_plugins'] ) ? $current['detected_plugins'] : array();

        echo '<section class="smseo-panel smseo-takeover" id="smseo-takeover">';
        echo '<div class="smseo-section-head">';
        echo '<div>';
        echo '<h2>SEO Takeover Scan</h2>';
        echo '<p>Singularity SEO reads existing public SEO output first, stores the baseline, and recommends a safe takeover path before expanding control.</p>';
        echo '</div>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_run_takeover_scan" />';
        wp_nonce_field( 'smseo_run_takeover_scan', 'smseo_takeover_nonce' );
        submit_button( $current ? 'Run Fresh Takeover Scan' : 'Run Takeover Scan', 'primary', 'submit', false );
        echo '</form>';
        echo '</div>';

        if ( $just_scanned ) {
            echo '<div class="notice notice-success inline"><p>Takeover scan complete. Existing SEO output was captured for review.</p></div>';
        }

        if ( ! $current ) {
            echo '<div class="smseo-empty-metrics"><strong>No takeover baseline yet.</strong><p>Run this scan before approving Singularity SEO to manage a new customer site.</p></div>';
            echo '</section>';
            return;
        }

        $readiness = isset( $summary['takeover_readiness'] ) ? (string) $summary['takeover_readiness'] : 'review_needed';
        echo '<div class="smseo-metric-grid">';
        $this->render_metric_card( 'Pages Scanned', isset( $summary['pages_scanned'] ) ? (string) (int) $summary['pages_scanned'] : '0', 'current public output' );
        $this->render_metric_card( 'Need Review', isset( $summary['pages_needing_review'] ) ? (string) (int) $summary['pages_needing_review'] : '0', 'before taking control' );
        $this->render_metric_card( 'Managed Seen', isset( $summary['managed_pages_seen'] ) ? (string) (int) $summary['managed_pages_seen'] : '0', 'already mapped' );
        $this->render_metric_card( 'Readiness', ucwords( str_replace( '_', ' ', $readiness ) ), 'recommended path' );
        echo '</div>';

        printf(
            '<p class="smseo-muted">Last takeover scan: %s. Detected SEO plugins: %s.</p>',
            esc_html( isset( $current['captured_at'] ) ? $this->format_metric_date( $current['captured_at'] ) . ' (' . $this->relative_metric_time( $current['captured_at'] ) . ')' : 'unknown' ),
            esc_html( ! empty( $detected_plugins ) ? implode( ', ', $detected_plugins ) : 'None detected' )
        );

        if ( ! empty( $recommendations ) ) {
            echo '<div class="smseo-takeover-recommendations">';
            echo '<h3>Recommended takeover path</h3>';
            echo '<ul>';
            foreach ( $recommendations as $recommendation ) {
                printf( '<li>%s</li>', esc_html( (string) $recommendation ) );
            }
            echo '</ul>';
            echo '</div>';
        }

        if ( ! empty( $pages ) ) {
            echo '<details class="smseo-takeover-pages">';
            echo '<summary><strong>Captured SEO baseline</strong><span>Titles, descriptions, canonicals, robots and schema found before takeover.</span></summary>';
            echo '<table class="widefat striped smseo-status"><thead><tr><th>Page</th><th>Status</th><th>Current SEO</th><th>Issues</th></tr></thead><tbody>';
            foreach ( array_slice( $pages, 0, 12 ) as $page ) {
                $issues = isset( $page['issues'] ) && is_array( $page['issues'] ) ? implode( '; ', $page['issues'] ) : '';
                printf(
                    '<tr><td><strong>%s</strong><br><code>%s</code></td><td>%s<br>%s</td><td>Title: %s<br>Description: %s<br>Canonical: %s</td><td>%s</td></tr>',
                    esc_html( isset( $page['label'] ) ? (string) $page['label'] : '' ),
                    esc_html( isset( $page['url'] ) ? (string) $page['url'] : '' ),
                    esc_html( isset( $page['status'] ) ? strtoupper( (string) $page['status'] ) : 'REVIEW' ),
                    esc_html( ! empty( $page['managed'] ) ? 'Managed' : 'Unmanaged' ),
                    esc_html( isset( $page['title'] ) ? (string) $page['title'] : '' ),
                    esc_html( isset( $page['description'] ) ? (string) $page['description'] : '' ),
                    esc_html( isset( $page['canonical'] ) ? (string) $page['canonical'] : '' ),
                    esc_html( '' !== $issues ? $issues : 'None' )
                );
            }
            echo '</tbody></table>';
            echo '</details>';
        }

        echo '</section>';
    }

    private function build_setup_packet( $customer_id, $controller_url, $rest_status_url, $rest_pages_url ) {
        $lines = array(
            'Singularity SEO setup packet',
            'Site: ' . home_url( '/' ),
            'Connection code: hidden in WordPress; use the Copy ChatGPT command button.',
            'WordPress REST status URL: ' . $rest_status_url,
            'WordPress REST pages URL: ' . $rest_pages_url,
            'ChatGPT app URL: ' . $controller_url,
            'ChatGPT connect command: hidden in WordPress; use the Copy ChatGPT command button.',
        );

        return implode( "\n", $lines );
    }

    private function build_onboarding_payload( $customer_id, $controller_url, $token ) {
        $customer_id = sanitize_key( (string) $customer_id );
        if ( '' === $customer_id || ! $this->is_opaque_customer_id( $customer_id ) ) {
            $customer_id = $this->new_opaque_customer_id();
            update_option( self::CUSTOMER_ID_OPTION, $customer_id, false );
        }

        return array(
            'customer_id'               => $customer_id,
            'site_url'                  => home_url( '/' ),
            'wordpress_rest_status_url' => rest_url( API::NAMESPACE . '/status' ),
            'wordpress_rest_pages_url'  => rest_url( API::NAMESPACE . '/pages' ),
            'chatgpt_app_url'           => $controller_url,
            'private_connection_key'    => $token,
        );
    }

    private function onboarding_endpoint_from_controller_url( $controller_url ) {
        $parts = wp_parse_url( $controller_url );
        if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
            return '';
        }

        $port = isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '';
        return $parts['scheme'] . '://' . $parts['host'] . $port . '/onboarding/wordpress';
    }

    private function submit_hosted_onboarding( $customer_id, $controller_url, $token, $timeout = 30 ) {
        $endpoint = $this->onboarding_endpoint_from_controller_url( $controller_url );
        if ( '' === $endpoint ) {
            return array(
                'ok'        => false,
                'retryable' => false,
                'message'   => 'Connection URL is invalid. Enter the Singularity SEO connection URL and try again.',
            );
        }

        $response = wp_remote_post(
            $endpoint,
            array(
                'timeout' => max( 3, min( 30, (int) $timeout ) ),
                'headers' => array(
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',
                ),
                'body'    => wp_json_encode( $this->build_onboarding_payload( $customer_id, $controller_url, $token ) ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return array(
                'ok'        => false,
                'retryable' => true,
                'message'   => 'Hosted verification could not be reached: ' . $response->get_error_message(),
            );
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        $body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( $code >= 200 && $code < 300 && is_array( $body ) && ! empty( $body['ok'] ) ) {
            return array(
                'ok'        => true,
                'retryable' => false,
                'message'   => 'Connected. Singularity SEO verified this WordPress site and stored the hosted customer record.',
            );
        }

        $message = is_array( $body ) && isset( $body['message'] ) ? (string) $body['message'] : 'Hosted verification failed.';
        return array(
            'ok'        => false,
            'retryable' => false,
            'message'   => $message,
        );
    }

    private function queue_hosted_onboarding( $customer_id, $controller_url ) {
        $customer_id = sanitize_key( (string) $customer_id );
        $controller_url = esc_url_raw( (string) $controller_url );

        if ( '' === $customer_id ) {
            $customer_id = $this->default_customer_id();
        }
        if ( '' === $controller_url ) {
            $controller_url = $this->default_controller_url();
        }

        $token = trim( (string) get_option( API::BRIDGE_TOKEN_OPTION, '' ) );
        if ( '' === $token ) {
            $token = wp_generate_password( 48, false, false );
            update_option( API::BRIDGE_TOKEN_OPTION, $token, false );
        }

        update_option( self::CUSTOMER_ID_OPTION, $customer_id, false );
        update_option( self::CONTROLLER_URL_OPTION, $controller_url, false );
        update_option( self::HOSTED_CONNECTION_STATUS_OPTION, 'verifying', false );
        update_option( self::HOSTED_CONNECTION_MESSAGE_OPTION, 'Singularity SEO is verifying this WordPress site in the background.', false );

        $endpoint = $this->onboarding_endpoint_from_controller_url( $controller_url );
        if ( '' === $endpoint ) {
            update_option( self::HOSTED_CONNECTION_STATUS_OPTION, 'failed', false );
            update_option( self::HOSTED_CONNECTION_MESSAGE_OPTION, 'Connection URL is invalid. Enter the Singularity SEO connection URL and try again.', false );
            return;
        }

        wp_remote_post(
            $endpoint,
            array(
                'timeout'  => 1,
                'blocking' => false,
                'headers'  => array(
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',
                ),
                'body'     => wp_json_encode( $this->build_onboarding_payload( $customer_id, $controller_url, $token ) ),
            )
        );
    }

    private function is_connected() {
        return 'verified' === (string) get_option( self::HOSTED_CONNECTION_STATUS_OPTION, '' );
    }

    private function connection_status_label( $stored_status, $token_configured ) {
        if ( 'verified' === $stored_status ) {
            return 'Hosted verified';
        }
        if ( 'verifying' === $stored_status ) {
            return 'Hosted verification in progress';
        }
        if ( 'failed' === $stored_status ) {
            return 'Hosted verification failed';
        }
        if ( $token_configured ) {
            return 'Connection prepared; hosted verification not complete';
        }
        return 'Not connected';
    }

    private function render_kpi_card( $label, $value, $note ) {
        echo '<div class="smseo-kpi-card">';
        printf( '<span>%s</span>', esc_html( $label ) );
        printf( '<strong>%s</strong>', esc_html( $value ) );
        printf( '<small>%s</small>', esc_html( $note ) );
        echo '</div>';
    }

    private function render_environment_panel() {
        $blog_public = '0' === (string) get_option( 'blog_public' )
            ? 'Discouraging search engines'
            : 'Public indexing setting enabled';
        $sitemap_url = home_url( '/wp-sitemap.xml' );

        echo '<details class="smseo-panel smseo-advanced-panel smseo-panel-system">';
        echo '<summary><strong>System Status</strong><span>WordPress visibility, sitemap and robots notes.</span></summary>';
        echo '<table class="widefat striped smseo-status">';
        echo '<tbody>';
        printf( '<tr><th>Site home</th><td>%s</td></tr>', esc_html( home_url( '/' ) ) );
        printf( '<tr><th>WordPress search visibility</th><td>%s</td></tr>', esc_html( $blog_public ) );
        printf( '<tr><th>Native sitemap</th><td><code>%s</code></td></tr>', esc_html( $sitemap_url ) );
        echo '<tr><th>robots.txt note</th><td>The plugin appends the sitemap to WordPress\' virtual robots.txt output. If the server has a physical <code>robots.txt</code> file in the web root, update that file separately.</td></tr>';
        echo '</tbody>';
        echo '</table>';
        echo '</details>';
    }

    private function render_bridge_token_form() {
        $configured = '' !== trim( (string) get_option( API::BRIDGE_TOKEN_OPTION, '' ) );

        echo '<details class="smseo-panel smseo-advanced-panel" id="smseo-bridge-token">';
        echo '<summary><strong>Support Connection</strong><span>Advanced credential fallback for support.</span></summary>';
        echo '<p>This is for Singularity SEO support and advanced troubleshooting. Most customers should not edit this value directly.</p>';
        echo '<table class="widefat striped smseo-status"><tbody>';
        printf( '<tr><th>Status</th><td>%s</td></tr>', $configured ? 'Configured' : 'Not configured' );
        echo '</tbody></table>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_save_bridge_token" />';
        wp_nonce_field( 'smseo_save_bridge_token', 'smseo_bridge_token_nonce' );
        echo '<input type="hidden" name="smseo_bridge_action" value="replace" />';
        echo '<label class="smseo-field"><span>Connection credential</span><input type="password" class="large-text" name="smseo_bridge_token" value="" autocomplete="new-password" placeholder="Paste a replacement credential" /></label>';
        echo '<p class="description">Support-only fallback. Normal customer onboarding never requires copying this credential.</p>';
        submit_button( 'Save Support Credential', 'secondary', 'submit', false );
        echo '</form>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="smseo-inline-support-form">';
        echo '<input type="hidden" name="action" value="smseo_save_bridge_token" />';
        echo '<input type="hidden" name="smseo_bridge_action" value="rotate" />';
        wp_nonce_field( 'smseo_save_bridge_token', 'smseo_bridge_token_nonce' );
        submit_button( 'Rotate Credential', 'secondary', 'submit', false );
        echo '<p class="description">Generates a new internal credential and asks the hosted Controller to verify this site again.</p>';
        echo '</form>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="smseo-inline-support-form">';
        echo '<input type="hidden" name="action" value="smseo_save_bridge_token" />';
        echo '<input type="hidden" name="smseo_bridge_action" value="clear" />';
        wp_nonce_field( 'smseo_save_bridge_token', 'smseo_bridge_token_nonce' );
        submit_button( 'Clear Credential', 'secondary', 'submit', false );
        echo '</form>';
        echo '</details>';
    }

    private function render_diagnostics_table() {
        echo '<details class="smseo-panel smseo-advanced-panel" id="smseo-managed-pages">';
        echo '<summary><strong>Managed SEO Diagnostics</strong><span>Registry matching, sitemap posture, schema and override state.</span></summary>';
        echo '<table class="widefat striped smseo-diagnostics">';
        echo '<thead><tr>';
        echo '<th>Section</th>';
        echo '<th>Path</th>';
        echo '<th>Resolved WP ID</th>';
        echo '<th>Robots</th>';
        echo '<th>Sitemap</th>';
        echo '<th>Schema</th>';
        echo '<th>Override</th>';
        echo '<th>Campaign</th>';
        echo '</tr></thead><tbody>';

        foreach ( $this->registry->keys() as $key ) {
            $page = $this->registry->get_effective( $key );
            $page = $this->campaign_manager->apply( $page );
            $post_id = $this->registry->resolve_post_id( $page );
            $robots = isset( $page['robots_preset'] ) ? $page['robots_preset'] : 'index_follow';
            $schema = isset( $page['schema_label'] ) ? $page['schema_label'] : 'Configured schema';
            $overrides = $this->registry->get_override( $key );
            $override_label = empty( $overrides ) ? 'Default' : 'Custom';
            $campaign_status = isset( $page['campaign_status'] ) ? ucfirst( $page['campaign_status'] ) : '—';

            echo '<tr>';
            printf( '<td><strong>%s</strong></td>', esc_html( isset( $page['label'] ) ? $page['label'] : $key ) );
            $path_display = isset( $page['path'] ) ? (string) $page['path'] : '';
            if ( isset( $page['path_aliases'] ) && is_array( $page['path_aliases'] ) && ! empty( $page['path_aliases'] ) ) {
                $aliases = array_map( 'strval', $page['path_aliases'] );
                $path_display .= ' | aliases: ' . implode( ', ', $aliases );
            }
            printf( '<td><code>%s</code></td>', esc_html( $path_display ) );
            printf( '<td>%s</td>', $post_id > 0 ? esc_html( (string) $post_id ) : '<span class="smseo-muted">Path-only / archive</span>' );
            printf( '<td><code>%s</code></td>', esc_html( $robots ) );
            printf( '<td>%s</td>', esc_html( $this->sitemap_manager->page_sitemap_status( $page ) ) );
            printf( '<td>%s</td>', esc_html( $schema ) );
            printf( '<td>%s</td>', esc_html( $override_label ) );
            printf( '<td>%s</td>', esc_html( $campaign_status ) );
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</details>';
    }

    private function render_live_audit_form() {
        echo '<section class="smseo-panel" id="smseo-audit">';
        echo '<h2>Live Front-End Head Audit</h2>';
        echo '<p>This audits the actual front-end HTML returned by the site for every managed SEO section and checks title, description, canonical, robots, Open Graph, Twitter/X, and JSON-LD validity.</p>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_run_live_audit" />';
        wp_nonce_field( 'smseo_run_live_audit', 'smseo_live_audit_nonce' );
        submit_button( 'Run Live Head Audit', 'primary', 'submit', false );
        echo '</form>';
        echo '</section>';
    }

    private function render_live_audit_results( $results ) {
        echo '<section class="smseo-panel" id="smseo-audit-results">';
        echo '<h2>Live Head Audit Results</h2>';

        if ( empty( $results ) ) {
            echo '<p class="smseo-audit-fail">No audit results were available. Run the live head audit again.</p>';
            echo '</section>';
            return;
        }

        $pass = 0;
        $fail = 0;
        $skip = 0;

        foreach ( $results as $row ) {
            if ( isset( $row['status'] ) && 'PASS' === $row['status'] ) {
                $pass++;
            } elseif ( isset( $row['status'] ) && 'SKIP' === $row['status'] ) {
                $skip++;
            } else {
                $fail++;
            }
        }

        printf(
            '<p><strong>%s passed</strong> / <strong>%s skipped</strong> / <strong>%s flagged</strong>.</p>',
            esc_html( (string) $pass ),
            esc_html( (string) $skip ),
            esc_html( (string) $fail )
        );

        echo '<table class="widefat striped smseo-audit-table">';
        echo '<thead><tr>';
        echo '<th>Section</th>';
        echo '<th>Fetched URL</th>';
        echo '<th>Status</th>';
        echo '<th>Title</th>';
        echo '<th>Meta / Canonical / Robots</th>';
        echo '<th>Social</th>';
        echo '<th>Schema</th>';
        echo '<th>Flags</th>';
        echo '</tr></thead><tbody>';

        foreach ( $results as $row ) {
            $status = isset( $row['status'] ) ? $row['status'] : 'FAIL';
            $status_class = 'PASS' === $status ? 'smseo-audit-pass' : ( 'SKIP' === $status ? 'smseo-audit-skip' : 'smseo-audit-fail' );
            $flags = isset( $row['flags'] ) && is_array( $row['flags'] ) && ! empty( $row['flags'] )
                ? implode( '; ', $row['flags'] )
                : '—';

            echo '<tr>';
            printf( '<td><strong>%s</strong></td>', esc_html( isset( $row['label'] ) ? $row['label'] : 'Unknown' ) );
            printf( '<td><code>%s</code><br><span class="smseo-muted">HTTP %s</span></td>', esc_html( isset( $row['url'] ) ? $row['url'] : '' ), esc_html( isset( $row['http_code'] ) ? (string) $row['http_code'] : '—' ) );
            printf( '<td><strong class="%s">%s</strong></td>', esc_attr( $status_class ), esc_html( $status ) );
            printf(
                '<td><strong>%s</strong><br><span class="smseo-muted">Titles: %s</span></td>',
                esc_html( isset( $row['title'] ) ? $row['title'] : '' ),
                esc_html( isset( $row['title_count'] ) ? (string) $row['title_count'] : '0' )
            );
            printf(
                '<td>Descriptions: %s<br>Canonicals: %s<br>Robots: %s</td>',
                esc_html( isset( $row['description_count'] ) ? (string) $row['description_count'] : '0' ),
                esc_html( isset( $row['canonical_count'] ) ? (string) $row['canonical_count'] : '0' ),
                esc_html( isset( $row['robots_count'] ) ? (string) $row['robots_count'] : '0' )
            );
            printf(
                '<td>OG title/desc/url: %s/%s/%s<br>Twitter title/desc: %s/%s</td>',
                esc_html( isset( $row['og_title_count'] ) ? (string) $row['og_title_count'] : '0' ),
                esc_html( isset( $row['og_description_count'] ) ? (string) $row['og_description_count'] : '0' ),
                esc_html( isset( $row['og_url_count'] ) ? (string) $row['og_url_count'] : '0' ),
                esc_html( isset( $row['twitter_title_count'] ) ? (string) $row['twitter_title_count'] : '0' ),
                esc_html( isset( $row['twitter_description_count'] ) ? (string) $row['twitter_description_count'] : '0' )
            );
            printf(
                '<td>JSON-LD: %s<br>Valid: %s<br>Invalid: %s</td>',
                esc_html( isset( $row['schema_count'] ) ? (string) $row['schema_count'] : '0' ),
                esc_html( isset( $row['schema_valid'] ) ? (string) $row['schema_valid'] : '0' ),
                esc_html( isset( $row['schema_invalid'] ) ? (string) $row['schema_invalid'] : '0' )
            );
            printf( '<td>%s</td>', esc_html( $flags ) );
            echo '</tr>';
        }

        echo '</tbody></table>';
        echo '</section>';
    }

    public function handle_run_live_audit() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this audit.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_run_live_audit', 'smseo_live_audit_nonce' );

        $auditor = new Audit_Service( $this->registry, $this->campaign_manager );
        $results = $auditor->run_live_head_audit();
        $metrics_store = new Metrics_Store();
        $metrics_store->create_snapshot( $results, 'admin_audit' );
        set_transient( 'smseo_live_audit_' . get_current_user_id(), $results, 10 * MINUTE_IN_SECONDS );

        wp_safe_redirect( add_query_arg( 'smseo_audit', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    public function handle_run_takeover_scan() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to run this scan.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_run_takeover_scan', 'smseo_takeover_nonce' );

        $takeover_store = new Takeover_Store( $this->registry );
        $takeover_store->create_scan( 'admin_scan' );

        wp_safe_redirect( add_query_arg( 'smseo_takeover', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG . '#smseo-takeover' ) ) );
        exit;
    }

    public function handle_create_report() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to create reports.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_create_report', 'smseo_report_nonce' );

        $type = isset( $_POST['smseo_report_type'] )
            ? sanitize_key( wp_unslash( $_POST['smseo_report_type'] ) )
            : 'baseline';
        $report_store = new Report_Store( $this->registry, $this->product_store );
        $report = $report_store->create_report( $type, 'admin' );
        if ( is_wp_error( $report ) ) {
            wp_safe_redirect( add_query_arg( 'smseo_error', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
            exit;
        }

        wp_safe_redirect( add_query_arg( 'smseo_report', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    public function handle_save_competitors() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to save competitors.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_save_competitors', 'smseo_competitors_nonce' );

        $names = isset( $_POST['smseo_competitor_name'] ) && is_array( $_POST['smseo_competitor_name'] )
            ? array_map( 'sanitize_text_field', wp_unslash( $_POST['smseo_competitor_name'] ) )
            : array();
        $domains = isset( $_POST['smseo_competitor_domain'] ) && is_array( $_POST['smseo_competitor_domain'] )
            ? array_map( 'sanitize_text_field', wp_unslash( $_POST['smseo_competitor_domain'] ) )
            : array();
        $items = array();
        for ( $i = 0; $i < Report_Store::MAX_COMPETITORS; $i++ ) {
            $items[] = array(
                'name'   => isset( $names[ $i ] ) ? (string) $names[ $i ] : '',
                'domain' => isset( $domains[ $i ] ) ? (string) $domains[ $i ] : '',
            );
        }

        $report_store = new Report_Store( $this->registry, $this->product_store );
        $report_store->update_competitors( $items );

        wp_safe_redirect( add_query_arg( 'smseo_competitors', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    public function handle_download_report() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to download reports.', 'sunset-marquis-seo-manager' ) );
        }

        $id = isset( $_GET['smseo_report_id'] ) ? sanitize_key( wp_unslash( $_GET['smseo_report_id'] ) ) : '';
        check_admin_referer( 'smseo_download_report_' . $id );

        $format = isset( $_GET['smseo_format'] ) ? sanitize_key( wp_unslash( $_GET['smseo_format'] ) ) : 'html';
        $report_store = new Report_Store( $this->registry, $this->product_store );
        $report = $report_store->get_report( $id );
        if ( ! is_array( $report ) ) {
            wp_die( esc_html__( 'Report not found.', 'sunset-marquis-seo-manager' ) );
        }

        $filename = sanitize_file_name( 'singularity-seo-' . $id );
        if ( 'pdf' === $format ) {
            nocache_headers();
            header( 'Content-Type: application/pdf' );
            header( 'Content-Disposition: attachment; filename="' . $filename . '.pdf"' );
            echo $report_store->render_pdf( $report ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            exit;
        }

        nocache_headers();
        header( 'Content-Type: text/html; charset=utf-8' );
        header( 'Content-Disposition: inline; filename="' . $filename . '.html"' );
        echo $report_store->render_html( $report ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    public function handle_save_bridge_token() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to save this token.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_save_bridge_token', 'smseo_bridge_token_nonce' );

        $bridge_action = isset( $_POST['smseo_bridge_action'] )
            ? sanitize_key( wp_unslash( $_POST['smseo_bridge_action'] ) )
            : 'replace';
        $token = isset( $_POST['smseo_bridge_token'] )
            ? sanitize_text_field( wp_unslash( $_POST['smseo_bridge_token'] ) )
            : '';
        $token = trim( $token );

        if ( 'rotate' === $bridge_action ) {
            $token = wp_generate_password( 48, false, false );
            update_option( API::BRIDGE_TOKEN_OPTION, $token, false );
            $customer_id = $this->default_customer_id();
            $controller_url = trim( (string) get_option( self::CONTROLLER_URL_OPTION, $this->default_controller_url() ) );
            delete_transient( self::AUTO_CONNECT_COOLDOWN_TRANSIENT );
            $this->queue_hosted_onboarding( $customer_id, $controller_url );
            set_transient(
                'smseo_onboarding_result_' . get_current_user_id(),
                array(
                    'ok'      => false,
                    'notice'  => 'info',
                    'message' => 'Support credential rotated. Hosted verification is running in the background.',
                ),
                10 * MINUTE_IN_SECONDS
            );
        } elseif ( 'clear' === $bridge_action ) {
            delete_option( API::BRIDGE_TOKEN_OPTION );
            update_option( self::HOSTED_CONNECTION_STATUS_OPTION, 'failed', false );
            update_option( self::HOSTED_CONNECTION_MESSAGE_OPTION, 'Support credential cleared. Refresh ChatGPT Link after adding or rotating a credential.', false );
        } elseif ( '' !== $token ) {
            update_option( API::BRIDGE_TOKEN_OPTION, $token, false );
            update_option( self::HOSTED_CONNECTION_STATUS_OPTION, 'verifying', false );
            update_option( self::HOSTED_CONNECTION_MESSAGE_OPTION, 'Support credential replaced. Refresh ChatGPT Link if hosted verification does not complete automatically.', false );
        }

        wp_safe_redirect( add_query_arg( 'smseo_bridge_token_updated', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    public function handle_save_connection() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to save connection settings.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_save_connection', 'smseo_connection_nonce' );

        $customer_id = isset( $_POST['smseo_customer_id'] )
            ? sanitize_key( wp_unslash( $_POST['smseo_customer_id'] ) )
            : '';
        $controller_url = isset( $_POST['smseo_controller_url'] )
            ? esc_url_raw( wp_unslash( $_POST['smseo_controller_url'] ) )
            : '';

        delete_transient( self::AUTO_CONNECT_COOLDOWN_TRANSIENT );
        $onboarding_result = $this->connect_site( $customer_id, $controller_url, true, true, 6 );
        if ( empty( $onboarding_result['ok'] ) && ! empty( $onboarding_result['retryable'] ) ) {
            $this->queue_hosted_onboarding( $customer_id, $controller_url );
            set_transient(
                'smseo_onboarding_result_' . get_current_user_id(),
                array(
                    'ok'      => false,
                    'notice'  => 'info',
                    'message' => 'Hosted verification is still running in the background. The dashboard will show Hosted verified after the Controller confirms this site.',
                ),
                10 * MINUTE_IN_SECONDS
            );
        }

        wp_safe_redirect( add_query_arg( 'smseo_connection_updated', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    public function handle_save_visibility_setup() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to save search data setup.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_save_visibility_setup', 'smseo_visibility_nonce' );

        $property_url = isset( $_POST['smseo_gsc_property_url'] )
            ? Validation::sanitize_search_console_property( wp_unslash( $_POST['smseo_gsc_property_url'] ) )
            : '';
        $property_url = false === $property_url ? '' : $property_url;
        $rank_provider = isset( $_POST['smseo_rank_provider'] )
            ? sanitize_text_field( wp_unslash( $_POST['smseo_rank_provider'] ) )
            : '';
        $ranking_target_domain = isset( $_POST['smseo_ranking_target_domain'] )
            ? sanitize_text_field( wp_unslash( $_POST['smseo_ranking_target_domain'] ) )
            : '';
        $keywords_text = isset( $_POST['smseo_target_keywords'] )
            ? sanitize_textarea_field( wp_unslash( $_POST['smseo_target_keywords'] ) )
            : '';
        $keywords = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $keywords_text ) ) );

        $visibility_store = new Visibility_Store();
        $visibility_store->update_config(
            array(
                'google_search_console_property_url' => $property_url,
                'google_search_console_connected'    => false,
                'rank_provider'                      => $rank_provider,
                'ranking_target_domain'              => $ranking_target_domain,
                'rank_provider_connected'            => false,
                'target_keywords'                    => $keywords,
            )
        );
        $visibility_store->create_snapshot( 'admin_setup' );

        wp_safe_redirect( add_query_arg( 'smseo_visibility_updated', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    public function handle_refresh_search_console() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to test Search Console.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_refresh_search_console', 'smseo_gsc_refresh_nonce' );

        $result = ( new Visibility_Scheduler() )->run_search_console_refresh_now();
        $ok = ! empty( $result['ok'] );
        $message = isset( $result['message'] ) ? sanitize_text_field( (string) $result['message'] ) : '';
        set_transient(
            'smseo_gsc_refresh_' . get_current_user_id(),
            '' !== $message ? $message : ( $ok ? 'Search Console refreshed successfully.' : 'Search Console refresh failed.' ),
            5 * MINUTE_IN_SECONDS
        );

        wp_safe_redirect(
            add_query_arg(
                'smseo_gsc_refresh',
                $ok ? 'ok' : 'error',
                admin_url( 'admin.php?page=' . self::MENU_SLUG . '#smseo-visibility' )
            )
        );
        exit;
    }

    private function render_edit_form() {
        echo '<details class="smseo-panel smseo-advanced-panel" id="smseo-override-editor">';
        echo '<summary><strong>Managed SEO Overrides</strong><span>Manual field overrides for approved registry entries.</span></summary>';
        echo '<p>Only the fields below are editable in this adapter. Structured data graphs, entity IDs and sitemap logic remain code-controlled.</p>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="smseo_save_overrides" />';
        wp_nonce_field( 'smseo_save_overrides', 'smseo_nonce' );

        foreach ( $this->registry->keys() as $key ) {
            $base = $this->registry->get( $key );
            $effective = $this->registry->get_effective( $key );
            $override = $this->registry->get_override( $key );
            $label = isset( $effective['label'] ) ? $effective['label'] : $key;
            $path = isset( $effective['path'] ) ? $effective['path'] : '';

            echo '<details class="smseo-page-card">';
            printf( '<summary><strong>%s</strong> <code>%s</code></summary>', esc_html( $label ), esc_html( $path ) );
            echo '<div class="smseo-fields">';

            $this->render_text_input( $key, 'title', 'SEO title', isset( $effective['title'] ) ? $effective['title'] : '' );
            $this->render_text_input( $key, 'canonical', 'Canonical URL override', isset( $effective['canonical'] ) ? $effective['canonical'] : '' );

            if ( 'homepage' === $key ) {
                $campaign = isset( $effective['campaign'] ) && is_array( $effective['campaign'] ) ? $effective['campaign'] : array();
                echo '<div class="smseo-callout">Homepage descriptions are campaign-managed. Meta, Open Graph, Twitter/X and homepage WebPage schema descriptions use the active description until the expiration date, then switch to the evergreen version automatically.</div>';
                $this->render_date_input( $key, 'campaign_expires_on', 'Campaign expiration date', isset( $campaign['expires_on'] ) ? $campaign['expires_on'] : '2026-07-20' );
                $this->render_textarea( $key, 'campaign_active_description', 'Active homepage description', isset( $campaign['active_description'] ) ? $campaign['active_description'] : '' );
                $this->render_textarea( $key, 'campaign_evergreen_description', 'Evergreen homepage description', isset( $campaign['evergreen_description'] ) ? $campaign['evergreen_description'] : '' );
                $this->render_textarea( $key, 'campaign_active_hotel_description', 'Active homepage Hotel schema description', isset( $campaign['active_hotel_description'] ) ? $campaign['active_hotel_description'] : '' );
                $this->render_textarea( $key, 'campaign_evergreen_hotel_description', 'Evergreen homepage Hotel schema description', isset( $campaign['evergreen_hotel_description'] ) ? $campaign['evergreen_hotel_description'] : '' );
            } else {
                $this->render_textarea( $key, 'description', 'Meta description', isset( $effective['description'] ) ? $effective['description'] : '' );
                $this->render_textarea( $key, 'og_description', 'Open Graph description', isset( $effective['og']['description'] ) ? $effective['og']['description'] : '' );
                $this->render_textarea( $key, 'twitter_description', 'Twitter/X description', isset( $effective['twitter']['description'] ) ? $effective['twitter']['description'] : '' );
            }

            $this->render_text_input( $key, 'og_title', 'Open Graph title', isset( $effective['og']['title'] ) ? $effective['og']['title'] : '' );
            $this->render_text_input( $key, 'twitter_title', 'Twitter/X title', isset( $effective['twitter']['title'] ) ? $effective['twitter']['title'] : '' );
            $this->render_robots_select( $key, isset( $override['robots_preset'] ) ? $override['robots_preset'] : 'default' );

            echo '</div>';
            echo '</details>';
        }

        submit_button( 'Save SEO Overrides' );
        echo '</form>';
        echo '</details>';
    }

    private function render_reset_form() {
        echo '<details class="smseo-panel smseo-advanced-panel smseo-reset">';
        echo '<summary><strong>Reset Overrides</strong><span>Clear administrator-saved SEO overrides.</span></summary>';
        echo '<p>This resets only administrator-saved SEO overrides. The approved plugin registry remains intact.</p>';
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'Reset all saved SEO overrides?\');">';
        echo '<input type="hidden" name="action" value="smseo_reset_overrides" />';
        wp_nonce_field( 'smseo_reset_overrides', 'smseo_reset_nonce' );
        submit_button( 'Reset Overrides to Plugin Defaults', 'secondary' );
        echo '</form>';
        echo '</details>';
    }

    private function render_agency_footer() {
        $logo_url = SMSEO_PLUGIN_URL . 'assets/agency689-horz-blue.svg';

        echo '<section class="smseo-footer-mark">';
        echo '<span>Singularity SEO by</span>';
        printf( '<img src="%s" alt="Agency689" />', esc_url( $logo_url ) );
        echo '</section>';
    }

    private function render_text_input( $key, $field, $label, $value ) {
        printf(
            '<label class="smseo-field"><span>%s</span><input type="text" class="large-text" name="overrides[%s][%s]" value="%s" /></label>',
            esc_html( $label ),
            esc_attr( $key ),
            esc_attr( $field ),
            esc_attr( $value )
        );
    }

    private function render_date_input( $key, $field, $label, $value ) {
        printf(
            '<label class="smseo-field"><span>%s</span><input type="date" name="overrides[%s][%s]" value="%s" /></label>',
            esc_html( $label ),
            esc_attr( $key ),
            esc_attr( $field ),
            esc_attr( $value )
        );
    }

    private function render_textarea( $key, $field, $label, $value ) {
        printf(
            '<label class="smseo-field"><span>%s</span><textarea class="large-text" rows="3" name="overrides[%s][%s]">%s</textarea></label>',
            esc_html( $label ),
            esc_attr( $key ),
            esc_attr( $field ),
            esc_textarea( $value )
        );
    }

    private function render_robots_select( $key, $selected ) {
        $options = array(
            'default' => 'Use plugin default',
            'index_follow' => 'Index, follow',
            'noindex_follow' => 'Noindex, follow',
            'noindex_nofollow' => 'Noindex, nofollow',
        );

        echo '<label class="smseo-field"><span>Robots override</span>';
        printf( '<select name="overrides[%s][robots_preset]">', esc_attr( $key ) );

        foreach ( $options as $value => $label ) {
            printf(
                '<option value="%s"%s>%s</option>',
                esc_attr( $value ),
                selected( $selected, $value, false ),
                esc_html( $label )
            );
        }

        echo '</select></label>';
    }

    public function handle_save_overrides() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to save these settings.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_save_overrides', 'smseo_nonce' );

        $submitted = isset( $_POST['overrides'] ) && is_array( $_POST['overrides'] )
            ? wp_unslash( $_POST['overrides'] )
            : array();

        $clean = array();
        $validation_errors = array();

        foreach ( $this->registry->keys() as $key ) {
            $base = $this->registry->get( $key );

            if ( ! isset( $submitted[ $key ] ) || ! is_array( $submitted[ $key ] ) || ! is_array( $base ) ) {
                continue;
            }

            $row = $submitted[ $key ];
            $entry = array();

            $this->maybe_store_text_override( $entry, $row, $base, 'title' );
            $this->maybe_store_url_override( $entry, $row, $base, 'canonical', $validation_errors, $key );

            if ( 'homepage' === $key ) {
                $campaign = isset( $base['campaign'] ) && is_array( $base['campaign'] ) ? $base['campaign'] : array();
                $this->maybe_store_date_override( $entry, $row, $campaign, 'campaign_expires_on', 'expires_on', $validation_errors, $key );
                $this->maybe_store_textarea_override( $entry, $row, $campaign, 'campaign_active_description', 'active_description' );
                $this->maybe_store_textarea_override( $entry, $row, $campaign, 'campaign_evergreen_description', 'evergreen_description' );
                $this->maybe_store_textarea_override( $entry, $row, $campaign, 'campaign_active_hotel_description', 'active_hotel_description' );
                $this->maybe_store_textarea_override( $entry, $row, $campaign, 'campaign_evergreen_hotel_description', 'evergreen_hotel_description' );
            } else {
                $this->maybe_store_textarea_override( $entry, $row, $base, 'description' );
                $this->maybe_store_nested_textarea_override( $entry, $row, $base, 'og_description', 'og', 'description' );
                $this->maybe_store_nested_textarea_override( $entry, $row, $base, 'twitter_description', 'twitter', 'description' );
            }

            $this->maybe_store_nested_text_override( $entry, $row, $base, 'og_title', 'og', 'title' );
            $this->maybe_store_nested_text_override( $entry, $row, $base, 'twitter_title', 'twitter', 'title' );
            $this->maybe_store_robots_override( $entry, $row );

            if ( ! empty( $entry ) ) {
                $clean[ $key ] = $entry;
            }
        }

        if ( ! empty( $validation_errors ) ) {
            set_transient( 'smseo_save_errors_' . get_current_user_id(), $validation_errors, 5 * MINUTE_IN_SECONDS );
            wp_safe_redirect( add_query_arg( 'smseo_error', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
            exit;
        }

        $this->registry->update_overrides( $clean );

        wp_safe_redirect( add_query_arg( 'smseo_updated', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    public function handle_reset_overrides() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to reset these settings.', 'sunset-marquis-seo-manager' ) );
        }

        check_admin_referer( 'smseo_reset_overrides', 'smseo_reset_nonce' );
        $this->registry->reset_overrides();

        wp_safe_redirect( add_query_arg( 'smseo_reset', '1', admin_url( 'admin.php?page=' . self::MENU_SLUG ) ) );
        exit;
    }

    private function maybe_store_text_override( &$entry, $row, $base, $field ) {
        if ( ! isset( $row[ $field ] ) ) {
            return;
        }

        $value = sanitize_text_field( $row[ $field ] );
        $default = isset( $base[ $field ] ) ? (string) $base[ $field ] : '';

        if ( '' !== $value && $value !== $default ) {
            $entry[ $field ] = $value;
        }
    }

    private function maybe_store_url_override( &$entry, $row, $base, $field, &$validation_errors, $key ) {
        if ( ! isset( $row[ $field ] ) ) {
            return;
        }

        $value = Validation::sanitize_absolute_http_url( $row[ $field ] );
        if ( false === $value ) {
            $validation_errors[] = sprintf(
                '%s canonical URL must be an absolute HTTP or HTTPS URL without embedded credentials.',
                isset( $base['label'] ) ? (string) $base['label'] : (string) $key
            );
            return;
        }

        $default = isset( $base[ $field ] ) ? (string) $base[ $field ] : '';

        if ( '' !== $value && $value !== $default ) {
            $entry[ $field ] = $value;
        }
    }

    private function maybe_store_textarea_override( &$entry, $row, $base, $field, $base_field = null ) {
        if ( ! isset( $row[ $field ] ) ) {
            return;
        }

        $value = sanitize_textarea_field( $row[ $field ] );
        $lookup = null === $base_field ? $field : $base_field;
        $default = isset( $base[ $lookup ] ) ? (string) $base[ $lookup ] : '';

        if ( '' !== $value && $value !== $default ) {
            $entry[ $field ] = $value;
        }
    }

    private function maybe_store_date_override( &$entry, $row, $base, $field, $base_field, &$validation_errors, $key ) {
        if ( ! isset( $row[ $field ] ) ) {
            return;
        }

        $value = sanitize_text_field( $row[ $field ] );
        $default = isset( $base[ $base_field ] ) ? (string) $base[ $base_field ] : '';

        if ( '' !== $value && ! Validation::is_valid_iso_date( $value ) ) {
            $validation_errors[] = sprintf(
                '%s campaign expiration must be a real calendar date in YYYY-MM-DD format.',
                'homepage' === $key ? 'Homepage' : (string) $key
            );
            return;
        }

        if ( '' !== $value && $value !== $default ) {
            $entry[ $field ] = $value;
        }
    }

    private function maybe_store_nested_text_override( &$entry, $row, $base, $field, $parent, $child ) {
        if ( ! isset( $row[ $field ] ) ) {
            return;
        }

        $value = sanitize_text_field( $row[ $field ] );
        $default = isset( $base[ $parent ][ $child ] ) ? (string) $base[ $parent ][ $child ] : '';

        if ( '' !== $value && $value !== $default ) {
            $entry[ $field ] = $value;
        }
    }

    private function maybe_store_nested_textarea_override( &$entry, $row, $base, $field, $parent, $child ) {
        if ( ! isset( $row[ $field ] ) ) {
            return;
        }

        $value = sanitize_textarea_field( $row[ $field ] );
        $default = isset( $base[ $parent ][ $child ] ) ? (string) $base[ $parent ][ $child ] : '';

        if ( '' !== $value && $value !== $default ) {
            $entry[ $field ] = $value;
        }
    }

    private function maybe_store_robots_override( &$entry, $row ) {
        if ( ! isset( $row['robots_preset'] ) ) {
            return;
        }

        $value = sanitize_key( $row['robots_preset'] );
        $allowed = array( 'default', 'index_follow', 'noindex_follow', 'noindex_nofollow' );

        if ( in_array( $value, $allowed, true ) && 'default' !== $value ) {
            $entry['robots_preset'] = $value;
        }
    }

    private function render_admin_styles() {
        echo '<style>
            .smseo-admin{
                --smseo-blue:#086cf5;
                --smseo-cyan:#00a6ff;
                --smseo-green:#10a45a;
                --smseo-ink:#07152d;
                --smseo-muted:#5c6670;
                --smseo-line:#dbe5f2;
                --smseo-soft:#f5f9ff;
                --smseo-panel:#ffffff;
                color:var(--smseo-ink);
                max-width:1380px;
            }
            .smseo-admin *{box-sizing:border-box;}
            .smseo-admin .notice{border-radius:6px;margin:16px 0;}
            .smseo-hero{
                position:relative;
                display:grid;
                grid-template-columns:minmax(0,1fr) 320px;
                gap:24px;
                align-items:stretch;
                margin:18px 0 18px;
                padding:34px;
                overflow:hidden;
                background:
                    linear-gradient(135deg,rgba(8,108,245,.14),rgba(8,108,245,0) 38%),
                    linear-gradient(135deg,#ffffff 0%,#f1f7ff 100%);
                border:1px solid var(--smseo-line);
                border-radius:8px;
                box-shadow:0 16px 42px rgba(23,34,45,.08);
            }
            .smseo-hero:after{
                content:"";
                position:absolute;
                inset:auto -90px -110px auto;
                width:260px;
                height:260px;
                border:46px solid rgba(8,108,245,.12);
                border-radius:50%;
                pointer-events:none;
            }
            .smseo-eyebrow{
                color:#086cf5;
                font-size:12px;
                font-weight:800;
                letter-spacing:0;
                text-transform:uppercase;
                margin:0 0 12px;
            }
            .smseo-hero h1{
                margin:0;
                max-width:760px;
                color:var(--smseo-ink);
                font-size:34px;
                line-height:1.08;
                font-weight:800;
                letter-spacing:0;
            }
            .smseo-hero p{
                max-width:720px;
                margin:14px 0 0;
                color:var(--smseo-muted);
                font-size:15px;
                line-height:1.6;
            }
            .smseo-hero-actions{
                display:flex;
                gap:10px;
                flex-wrap:wrap;
                margin-top:22px;
            }
            .smseo-admin .button-primary{
                background:var(--smseo-blue);
                border-color:var(--smseo-blue);
                color:#fff;
                font-weight:700;
                box-shadow:none;
            }
            .smseo-admin .button-primary:hover,
            .smseo-admin .button-primary:focus{
                background:#008fc4;
                border-color:#008fc4;
                color:#fff;
            }
            .smseo-button-ghost{
                border-color:#9bcfe2!important;
                color:#0757c7!important;
                background:#fff!important;
                font-weight:700;
            }
            .smseo-brand-card{
                position:relative;
                z-index:1;
                display:flex;
                flex-direction:column;
                justify-content:center;
                gap:16px;
                padding:24px;
                background:rgba(255,255,255,.76);
                border:1px solid rgba(8,108,245,.22);
                border-radius:8px;
                box-shadow:0 12px 30px rgba(8,108,245,.08);
            }
            .smseo-brand-card img{width:100%;max-width:310px;height:auto;align-self:center;}
            .smseo-brand-card span{color:var(--smseo-muted);font-weight:600;line-height:1.45;text-align:center;}
            .smseo-kpis{
                display:grid;
                grid-template-columns:repeat(4,minmax(0,1fr));
                gap:14px;
                margin:0 0 18px;
            }
            .smseo-kpi-card{
                padding:18px;
                background:var(--smseo-panel);
                border:1px solid var(--smseo-line);
                border-radius:8px;
                box-shadow:0 10px 24px rgba(23,34,45,.05);
            }
            .smseo-kpi-card span{
                display:block;
                color:#086cf5;
                font-size:11px;
                font-weight:800;
                letter-spacing:0;
                text-transform:uppercase;
            }
            .smseo-kpi-card strong{
                display:block;
                margin-top:8px;
                font-size:26px;
                line-height:1.1;
                color:var(--smseo-ink);
            }
            .smseo-kpi-card small{
                display:block;
                margin-top:8px;
                color:var(--smseo-muted);
                font-size:12px;
                line-height:1.35;
            }
            .smseo-metric-grid{
                display:grid;
                grid-template-columns:repeat(4,minmax(0,1fr));
                gap:14px;
                margin:16px 0;
            }
            .smseo-metric-card{
                min-height:116px;
                padding:16px;
                border:1px solid var(--smseo-line);
                border-radius:8px;
                background:#fff;
            }
            .smseo-metric-card span{
                display:block;
                color:#006fae;
                font-size:12px;
                font-weight:800;
                letter-spacing:0;
                text-transform:uppercase;
            }
            .smseo-metric-card strong{
                display:block;
                margin-top:10px;
                color:var(--smseo-ink);
                font-size:32px;
                line-height:1;
            }
            .smseo-metric-card small{
                display:block;
                margin-top:9px;
                color:var(--smseo-muted);
                font-size:12px;
            }
            .smseo-empty-metrics{
                padding:18px;
                border:1px solid var(--smseo-line);
                border-radius:8px;
                background:var(--smseo-soft);
            }
            .smseo-empty-metrics strong{display:block;color:var(--smseo-ink);}
            .smseo-keyword-rankings{
                margin:18px 0;
                padding:18px;
                border:1px solid var(--smseo-line);
                border-radius:10px;
                background:#fff;
            }
            .smseo-keyword-rankings-head{
                display:flex;
                align-items:flex-start;
                justify-content:space-between;
                gap:16px;
                margin-bottom:14px;
            }
            .smseo-keyword-rankings-head h3{
                margin:0 0 4px;
                color:var(--smseo-ink);
                font-size:17px;
            }
            .smseo-keyword-rankings-head p{
                margin:0;
                color:var(--smseo-muted);
            }
            .smseo-keyword-rankings-head span{
                white-space:nowrap;
                color:#0757c7;
                background:#eef5ff;
                border-radius:999px;
                padding:5px 10px;
                font-size:12px;
                font-weight:800;
            }
            .smseo-keyword-rank-table td,.smseo-keyword-rank-table th{
                vertical-align:top;
            }
            .smseo-keyword-rank-table a{
                word-break:break-word;
            }
            .smseo-score-trend{
                display:flex;
                align-items:end;
                gap:10px;
                height:150px;
                margin:18px 0;
                padding:14px;
                border:1px solid var(--smseo-line);
                border-radius:8px;
                background:linear-gradient(180deg,#fff,#f7fbfd);
            }
            .smseo-score-bar{
                display:flex;
                flex:1;
                min-width:28px;
                height:118px;
                flex-direction:column;
                justify-content:flex-end;
                gap:6px;
                text-align:center;
            }
            .smseo-score-bar span{
                display:block;
                min-height:3px;
                border-radius:6px 6px 0 0;
                background:linear-gradient(180deg,#0a84ff,#0757c7);
            }
            .smseo-score-bar small{
                color:var(--smseo-muted);
                font-size:11px;
                font-weight:800;
            }
            .smseo-section-head{
                display:flex;
                align-items:flex-start;
                justify-content:space-between;
                gap:18px;
                margin-bottom:16px;
            }
            .smseo-section-head h2{margin-bottom:6px;}
            .smseo-section-head p{margin:0;}
            .smseo-status-pill{
                display:inline-flex;
                align-items:center;
                min-height:30px;
                padding:5px 12px;
                border-radius:999px;
                font-size:12px;
                white-space:nowrap;
            }
            .smseo-status-ready{color:#087f3f;background:#e9f8ef;}
            .smseo-status-action{color:#0757c7;background:#eef5ff;}
            .smseo-checkbox{
                display:flex;
                align-items:center;
                gap:8px;
                min-height:30px;
                color:#26323d;
                font-weight:700;
            }
            .smseo-copy-table{margin-top:16px;}
            .smseo-panel{
                background:var(--smseo-panel);
                border:1px solid var(--smseo-line);
                border-radius:8px;
                padding:22px 24px;
                margin:18px 0;
                box-shadow:0 10px 28px rgba(23,34,45,.05);
            }
            .smseo-panel h2{
                margin:0 0 12px;
                color:var(--smseo-ink);
                font-size:20px;
                line-height:1.25;
            }
            .smseo-panel p{color:var(--smseo-muted);line-height:1.55;}
            .smseo-launch-console{
                padding:26px;
                overflow:hidden;
                border-color:#b9d8ff;
                box-shadow:0 18px 48px rgba(8,108,245,.12);
            }
            .smseo-product-console{
                background:
                    linear-gradient(135deg,rgba(8,108,245,.06),rgba(16,164,90,.04)),
                    #fff;
            }
            .smseo-product-head{
                display:flex;
                align-items:flex-start;
                justify-content:space-between;
                gap:18px;
                margin-bottom:18px;
                padding-bottom:18px;
                border-bottom:1px solid var(--smseo-line);
            }
            .smseo-product-head h2{
                margin:0 0 8px;
                font-size:24px;
            }
            .smseo-product-head p{
                max-width:760px;
                margin:0;
                font-size:14px;
            }
            .smseo-primary-steps{
                display:grid;
                grid-template-columns:1fr;
                gap:12px;
            }
            .smseo-chatgpt-link-card{
                display:grid;
                grid-template-columns:76px minmax(0,1fr) auto;
                align-items:center;
                gap:18px;
                margin:0 0 16px;
                padding:22px;
                border:1px solid rgba(31,84,255,.28);
                border-radius:12px;
                color:#fff;
                background:radial-gradient(circle at 86% 18%,rgba(34,211,238,.28),transparent 34%),linear-gradient(120deg,#071640,#102f82 58%,#1f54ff);
                box-shadow:0 18px 44px rgba(10,31,92,.18);
            }
            .smseo-link-orb{
                display:grid;
                place-items:center;
                width:76px;
                height:76px;
                border-radius:50%;
                background:radial-gradient(circle at 50% 45%,#fff 0,#8bd9ff 26%,#1f54ff 62%,#071640 100%);
                box-shadow:0 0 0 9px rgba(255,255,255,.08),0 12px 28px rgba(31,84,255,.36);
            }
            .smseo-link-orb span{
                color:#fff;
                font-size:38px;
                font-weight:900;
                line-height:1;
            }
            .smseo-link-copy strong{
                display:block;
                color:#fff;
                font-size:22px;
                line-height:1.15;
            }
            .smseo-link-copy p{
                max-width:680px;
                margin:7px 0 10px;
                color:#cfe2ff;
                font-size:14px;
                line-height:1.45;
            }
            .smseo-link-copy code{
                display:inline-block;
                padding:5px 9px;
                border-radius:7px;
                color:#eaf7ff;
                background:rgba(255,255,255,.12);
                border:1px solid rgba(255,255,255,.18);
            }
            .smseo-link-action-form{margin:0;}
            .smseo-link-action-form .button.smseo-big-go-button{
                min-height:54px;
                min-width:220px;
                margin:0;
                padding:0 22px;
                border:0;
                border-radius:10px;
                color:#06112e;
                background:#fff;
                box-shadow:0 10px 24px rgba(0,0,0,.22);
                font-size:15px;
                font-weight:900;
                white-space:normal;
            }
            .smseo-link-action-form .button.smseo-big-go-button:hover,
            .smseo-link-action-form .button.smseo-big-go-button:focus{
                color:#06112e;
                background:#eaf7ff;
            }
            .smseo-primary-step{
                position:relative;
                display:grid;
                grid-template-columns:42px minmax(0,1fr) auto;
                gap:16px;
                align-items:start;
                padding:18px;
                border:1px solid var(--smseo-line);
                border-radius:8px;
                background:#fff;
                box-shadow:0 10px 26px rgba(23,34,45,.04);
            }
            .smseo-step-number{
                display:inline-flex;
                align-items:center;
                justify-content:center;
                width:42px;
                height:42px;
                border-radius:50%;
                color:#fff;
                background:linear-gradient(135deg,var(--smseo-blue),var(--smseo-cyan));
                font-size:18px;
                font-weight:900;
            }
            .smseo-step-body h3{
                margin:0 0 7px;
                color:var(--smseo-ink);
                font-size:18px;
                line-height:1.2;
            }
            .smseo-step-body p{
                margin:0 0 12px;
            }
            .smseo-step-state{
                display:inline-flex;
                align-items:center;
                justify-content:center;
                min-width:76px;
                min-height:30px;
                padding:5px 10px;
                border-radius:999px;
                font-size:12px;
                text-transform:uppercase;
            }
            .smseo-step-state.is-done,
            .smseo-step-state.is-ready{color:#087f3f;background:#e9f8ef;}
            .smseo-step-state.needs-work{color:#8a5a00;background:#fff4d7;}
            .smseo-inline-form,
            .smseo-search-form{
                display:grid;
                grid-template-columns:minmax(180px,280px) auto;
                gap:12px;
                align-items:end;
                max-width:520px;
            }
            .smseo-search-form{
                grid-template-columns:repeat(2,minmax(0,1fr));
                max-width:820px;
            }
            .smseo-link-form{
                grid-template-columns:minmax(180px,260px) minmax(220px,auto);
                max-width:620px;
            }
            .smseo-link-form .smseo-refresh-link-button{
                min-height:42px;
                padding:0 18px;
                border-radius:8px;
                font-weight:800;
                white-space:normal;
            }
            .smseo-search-form .button{justify-self:start;}
            .smseo-wide-field{grid-column:1/-1;}
            .smseo-site-id{
                display:inline-grid;
                gap:6px;
                min-width:280px;
                margin:2px 0 12px;
                padding:12px 14px;
                border:1px solid #b8d7ff;
                border-radius:8px;
                background:#f7fbff;
            }
            .smseo-site-id span{
                color:#006fae;
                font-size:11px;
                font-weight:900;
                text-transform:uppercase;
            }
            .smseo-site-id code{
                display:block;
                width:max-content;
                max-width:100%;
                color:var(--smseo-ink);
                background:transparent;
                padding:0;
                font-size:20px;
                font-weight:900;
                overflow-wrap:anywhere;
            }
            .smseo-command{
                padding:10px 12px;
                border-left:4px solid var(--smseo-blue);
                background:#eef5ff;
                border-radius:6px;
                color:var(--smseo-ink)!important;
            }
            .smseo-provider-status{
                display:grid;
                grid-template-columns:repeat(2,minmax(0,180px));
                gap:10px;
                margin:0 0 14px;
            }
            .smseo-provider-status span{
                display:grid;
                gap:6px;
                padding:11px 12px;
                border:1px solid var(--smseo-line);
                border-radius:8px;
                background:#f8fbff;
                color:var(--smseo-muted);
            }
            .smseo-provider-status strong{
                color:#006fae;
                font-size:11px;
                text-transform:uppercase;
            }
            .smseo-launch-summary{
                display:grid;
                grid-template-columns:repeat(3,minmax(0,1fr));
                gap:12px;
                margin:18px 0;
            }
            .smseo-launch-summary span{
                display:grid;
                gap:8px;
                min-height:84px;
                padding:14px;
                border:1px solid var(--smseo-line);
                border-radius:8px;
                background:#fff;
                color:var(--smseo-muted);
                overflow-wrap:anywhere;
            }
            .smseo-launch-summary strong{
                color:#006fae;
                font-size:11px;
                text-transform:uppercase;
            }
            .smseo-support-details{
                margin-top:18px;
                border:1px solid var(--smseo-line);
                border-radius:8px;
                background:#fff;
                overflow:hidden;
            }
            .smseo-support-details summary{
                cursor:pointer;
                padding:14px 16px;
                color:var(--smseo-ink);
                font-weight:900;
                background:#f6f9fd;
            }
            .smseo-advanced-panel{
                padding:0;
                overflow:hidden;
            }
            .smseo-advanced-panel > summary{
                display:flex;
                align-items:center;
                justify-content:space-between;
                gap:18px;
                cursor:pointer;
                padding:18px 22px;
                color:var(--smseo-ink);
                background:#f6f9fd;
            }
            .smseo-advanced-panel > summary strong{
                font-size:16px;
            }
            .smseo-advanced-panel > summary span{
                color:var(--smseo-muted);
                font-size:12px;
                line-height:1.35;
                text-align:right;
            }
            .smseo-advanced-panel > p,
            .smseo-advanced-panel > form,
            .smseo-advanced-panel > table,
            .smseo-advanced-panel > .smseo-page-card{
                margin:18px 22px;
            }
            .smseo-advanced-panel > table{
                width:calc(100% - 44px);
            }
            .smseo-support-details .smseo-status,
            .smseo-support-details .smseo-field,
            .smseo-support-details .smseo-controller-url-form{
                margin:16px;
            }
            .smseo-controller-url-form{
                display:grid;
                gap:12px;
            }
            .smseo-status,
            .smseo-diagnostics,
            .smseo-audit-table{
                border:1px solid var(--smseo-line);
                border-radius:8px;
                overflow:hidden;
                box-shadow:none;
            }
            .smseo-status th{width:260px;}
            .smseo-admin .widefat th{
                color:#26323d;
                background:#f3f9fc;
                font-weight:800;
            }
            .smseo-admin .widefat td,
            .smseo-admin .widefat th{
                border-color:#e5eef3;
                padding:12px 14px;
            }
            .smseo-page-card{
                border:1px solid var(--smseo-line);
                background:#fff;
                margin:14px 0;
                padding:0;
                border-radius:8px;
                overflow:hidden;
                box-shadow:0 6px 16px rgba(23,34,45,.04);
            }
            .smseo-page-card summary{
                cursor:pointer;
                padding:15px 18px;
                background:linear-gradient(90deg,#f6f9ff,#fff);
                color:var(--smseo-ink);
            }
            .smseo-page-card[open] summary{
                border-bottom:1px solid var(--smseo-line);
            }
            .smseo-page-card summary strong{font-size:14px;}
            .smseo-page-card code,
            .smseo-admin code{
                color:#0757c7;
                background:#eef5ff;
                border-radius:4px;
                padding:2px 6px;
            }
            .smseo-fields{
                padding:18px;
                display:grid;
                grid-template-columns:repeat(2,minmax(0,1fr));
                gap:16px;
            }
            .smseo-field{
                display:grid;
                gap:7px;
            }
            .smseo-field span{
                color:#26323d;
                font-weight:800;
            }
            .smseo-field small{
                color:#6b7785;
                line-height:1.45;
            }
            .smseo-field input,
            .smseo-field select,
            .smseo-field textarea{
                border-color:#c6d9e4;
                border-radius:6px;
                box-shadow:none;
            }
            .smseo-field input:focus,
            .smseo-field select:focus,
            .smseo-field textarea:focus{
                border-color:var(--smseo-blue);
                box-shadow:0 0 0 1px var(--smseo-blue);
            }
            .smseo-field textarea{min-height:86px;}
            .smseo-callout{
                grid-column:1/-1;
                background:#eef5ff;
                border-left:4px solid var(--smseo-blue);
                padding:13px 15px;
                color:#27566b;
                border-radius:6px;
            }
            .smseo-muted{color:var(--smseo-muted);}
            .smseo-reset{border-color:#f0d2d2;background:#fffafa;}
            .smseo-diagnostics td,.smseo-diagnostics th{vertical-align:top;}
            .smseo-audit-table td,.smseo-audit-table th{vertical-align:top;}
            .smseo-audit-pass{
                display:inline-block;
                color:#087f3f;
                background:#e9f8ef;
                border-radius:999px;
                padding:3px 9px;
            }
            .smseo-audit-fail{
                display:inline-block;
                color:#b42318;
                background:#fff0ee;
                border-radius:999px;
                padding:3px 9px;
            }
            .smseo-audit-skip{
                display:inline-block;
                color:#755118;
                background:#fff8e7;
                border-radius:999px;
                padding:3px 9px;
            }
            .smseo-footer-mark{
                display:flex;
                align-items:center;
                justify-content:flex-end;
                gap:14px;
                margin:24px 0 8px;
                color:var(--smseo-muted);
                font-weight:700;
            }
            .smseo-footer-mark img{width:150px;height:auto;}
            @media (max-width:1100px){
                .smseo-hero{grid-template-columns:1fr;}
                .smseo-kpis{grid-template-columns:repeat(2,minmax(0,1fr));}
                .smseo-metric-grid{grid-template-columns:repeat(2,minmax(0,1fr));}
                .smseo-search-form{grid-template-columns:1fr;}
            }
            @media (max-width:760px){
                .smseo-hero{padding:24px;}
                .smseo-hero h1{font-size:28px;}
                .smseo-kpis{grid-template-columns:1fr;}
                .smseo-product-head{display:block;}
                .smseo-product-head .smseo-status-pill{display:inline-flex;margin-top:12px;}
                .smseo-primary-step{grid-template-columns:1fr;}
                .smseo-step-state{justify-self:start;}
                .smseo-inline-form{grid-template-columns:1fr;max-width:none;}
                .smseo-chatgpt-link-card{grid-template-columns:1fr;}
                .smseo-link-action-form .button.smseo-big-go-button{width:100%;}
                .smseo-provider-status{grid-template-columns:1fr;}
                .smseo-launch-summary{grid-template-columns:1fr;}
                .smseo-section-head{display:block;}
                .smseo-fields{grid-template-columns:1fr;}
                .smseo-footer-mark{justify-content:flex-start;align-items:flex-start;flex-direction:column;}
            }
        </style>';
    }
}
