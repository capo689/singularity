<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Report_Store {
    const REPORTS_OPTION = 'smseo_reports';
    const COMPETITORS_OPTION = 'smseo_competitors';
    const MAX_REPORTS = 40;
    const MAX_COMPETITORS = 5;

    private $registry;
    private $product_store;

    public function __construct( Registry $registry, Product_Store $product_store ) {
        $this->registry = $registry;
        $this->product_store = $product_store;
    }

    public function list_reports() {
        $reports = get_option( self::REPORTS_OPTION, array() );
        $reports = is_array( $reports ) ? $reports : array();
        uasort(
            $reports,
            function ( $a, $b ) {
                return strcmp( isset( $b['created_at'] ) ? $b['created_at'] : '', isset( $a['created_at'] ) ? $a['created_at'] : '' );
            }
        );

        return $reports;
    }

    public function get_report( $id ) {
        $id = sanitize_key( (string) $id );
        $reports = $this->list_reports();
        return isset( $reports[ $id ] ) && is_array( $reports[ $id ] ) ? $reports[ $id ] : null;
    }

    public function get_competitors() {
        $items = get_option( self::COMPETITORS_OPTION, array() );
        $items = is_array( $items ) ? $items : array();

        return array_slice( array_values( array_filter( array_map( array( $this, 'sanitize_competitor' ), $items ) ) ), 0, self::MAX_COMPETITORS );
    }

    public function update_competitors( $items ) {
        $clean = array();
        foreach ( (array) $items as $item ) {
            $competitor = $this->sanitize_competitor( $item );
            if ( ! empty( $competitor['domain'] ) || ! empty( $competitor['name'] ) ) {
                $clean[] = $competitor;
            }
        }

        $clean = array_slice( $clean, 0, self::MAX_COMPETITORS );
        update_option( self::COMPETITORS_OPTION, $clean, false );

        return $clean;
    }

    public function create_report( $type, $source = 'admin', $context = array() ) {
        $type = sanitize_key( (string) $type );
        if ( ! in_array( $type, array( 'baseline', 'monthly', 'campaign', 'competitive' ), true ) ) {
            return new \WP_Error( 'smseo_invalid_report_type', 'Report type must be baseline, monthly, campaign, or competitive.', array( 'status' => 400 ) );
        }

        $now = current_time( 'mysql', true );
        $report = array(
            'id'          => $this->new_id( 'report' ),
            'type'        => $type,
            'label'       => $this->type_label( $type ),
            'created_at'  => $now,
            'source'      => sanitize_key( (string) $source ),
            'site'        => array(
                'name' => wp_strip_all_tags( (string) get_bloginfo( 'name' ) ),
                'url'  => home_url( '/' ),
            ),
            'summary'     => $this->summary_for_type( $type ),
            'sections'    => $this->sections_for_type( $type, $context ),
            'competitors' => $this->get_competitors(),
            'prompt'      => 'competitive' === $type ? $this->competitive_prompt( $context ) : '',
        );

        $reports = $this->list_reports();
        $reports[ $report['id'] ] = $this->sanitize_report( $report );
        uasort(
            $reports,
            function ( $a, $b ) {
                return strcmp( isset( $b['created_at'] ) ? $b['created_at'] : '', isset( $a['created_at'] ) ? $a['created_at'] : '' );
            }
        );
        if ( count( $reports ) > self::MAX_REPORTS ) {
            $reports = array_slice( $reports, 0, self::MAX_REPORTS, true );
        }
        update_option( self::REPORTS_OPTION, $reports, false );

        return $reports[ $report['id'] ];
    }

    public function dashboard_payload() {
        $reports = array_values( $this->list_reports() );
        $latest = array_slice( $reports, 0, 5 );
        $public_latest = array();
        foreach ( $latest as $report ) {
            $public_latest[] = $this->public_report_summary( $report );
        }

        return array(
            'competitor_limit' => self::MAX_COMPETITORS,
            'competitors'      => $this->get_competitors(),
            'latest'           => $public_latest,
            'count'            => count( $reports ),
        );
    }

    public function public_report_summary( $report ) {
        return array(
            'id'         => isset( $report['id'] ) ? (string) $report['id'] : '',
            'type'       => isset( $report['type'] ) ? (string) $report['type'] : '',
            'label'      => isset( $report['label'] ) ? (string) $report['label'] : '',
            'created_at' => isset( $report['created_at'] ) ? (string) $report['created_at'] : '',
            'summary'    => isset( $report['summary'] ) && is_array( $report['summary'] ) ? $report['summary'] : array(),
        );
    }

    public function render_html( $report ) {
        $report = $this->sanitize_report( $report );
        $logo = esc_url( SMSEO_PLUGIN_URL . 'assets/singularity-seo-logo.png' );
        $title = isset( $report['label'] ) ? (string) $report['label'] : 'Singularity SEO Report';
        $site = isset( $report['site']['url'] ) ? (string) $report['site']['url'] : home_url( '/' );
        $created = isset( $report['created_at'] ) ? (string) $report['created_at'] : '';
        $summary = isset( $report['summary'] ) && is_array( $report['summary'] ) ? $report['summary'] : array();
        $sections = isset( $report['sections'] ) && is_array( $report['sections'] ) ? $report['sections'] : array();

        ob_start();
        ?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title><?php echo esc_html( $title ); ?></title>
    <style>
        :root{--ink:#08142f;--blue:#1f54ff;--line:#dfe5f4;--muted:#66708b;--soft:#f5f8ff;--green:#10a66a;--amber:#b36b00;}
        body{margin:0;background:#eef2f8;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;}
        .report{max-width:980px;margin:28px auto;background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 24px 70px rgba(8,20,47,.14);}
        header{padding:30px 36px;background:linear-gradient(115deg,#071947,#163da7);color:#fff;display:flex;align-items:center;justify-content:space-between;gap:24px;}
        header img{width:260px;max-width:45%;height:auto;background:#fff;border-radius:12px;padding:10px;}
        header h1{margin:0;font-size:30px;line-height:1.08;} header p{margin:8px 0 0;color:#c8d7ff;}
        main{padding:30px 36px 36px;}
        .cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:28px;}
        .card{border:1px solid var(--line);border-radius:14px;padding:16px;background:linear-gradient(180deg,#fff,#f8faff);}
        .card span{display:block;color:var(--muted);font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;}
        .card strong{display:block;margin-top:7px;font-size:23px;line-height:1.1;}
        section{border-top:1px solid var(--line);padding-top:22px;margin-top:22px;}
        h2{margin:0 0 10px;font-size:20px;} p{line-height:1.55;} ul{margin:10px 0 0 20px;padding:0;} li{margin:6px 0;}
        pre{white-space:pre-wrap;background:#f5f7fc;border:1px solid var(--line);border-radius:12px;padding:14px;line-height:1.45;}
        footer{display:flex;justify-content:space-between;gap:18px;padding:18px 36px 28px;color:var(--muted);font-size:12px;}
        @media print{body{background:#fff}.report{margin:0;box-shadow:none;border-radius:0}.no-print{display:none}}
        @media(max-width:760px){.cards{grid-template-columns:1fr 1fr}header{display:block}header img{max-width:100%;margin-top:18px}}
    </style>
</head>
<body>
<article class="report">
    <header>
        <div>
            <h1><?php echo esc_html( $title ); ?></h1>
            <p><?php echo esc_html( $site ); ?> · <?php echo esc_html( $this->format_date( $created ) ); ?></p>
        </div>
        <img src="<?php echo $logo; ?>" alt="Singularity SEO" />
    </header>
    <main>
        <div class="cards">
            <?php foreach ( $summary as $label => $value ) : ?>
                <div class="card"><span><?php echo esc_html( $this->human_label( $label ) ); ?></span><strong><?php echo esc_html( is_scalar( $value ) ? (string) $value : wp_json_encode( $value ) ); ?></strong></div>
            <?php endforeach; ?>
        </div>
        <?php foreach ( $sections as $section ) : ?>
            <section>
                <h2><?php echo esc_html( isset( $section['title'] ) ? (string) $section['title'] : '' ); ?></h2>
                <p><?php echo esc_html( isset( $section['body'] ) ? (string) $section['body'] : '' ); ?></p>
                <?php if ( ! empty( $section['items'] ) && is_array( $section['items'] ) ) : ?>
                    <ul>
                        <?php foreach ( $section['items'] as $item ) : ?>
                            <li><?php echo esc_html( (string) $item ); ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>
        <?php endforeach; ?>
        <?php if ( ! empty( $report['prompt'] ) ) : ?>
            <section>
                <h2>ChatGPT Review Prompt</h2>
                <p>Use this prompt in the Singularity SEO ChatGPT app to run the strategic competitor review.</p>
                <pre><?php echo esc_html( (string) $report['prompt'] ); ?></pre>
            </section>
        <?php endif; ?>
    </main>
    <footer>
        <span>Singularity SEO</span>
        <span>Verified data and AI-assisted recommendations should be reviewed before publication.</span>
    </footer>
</article>
</body>
</html>
        <?php
        return (string) ob_get_clean();
    }

    public function render_pdf( $report ) {
        $page_streams = $this->pdf_page_streams( $report );
        $page_count = count( $page_streams );
        $page_ids = range( 4, 3 + $page_count );
        $content_ids = range( 4 + $page_count, 3 + ( 2 * $page_count ) );

        $objects = array();
        $objects[] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objects[] = "<< /Type /Pages /Kids [" . implode( ' ', array_map( function ( $id ) { return $id . ' 0 R'; }, $page_ids ) ) . "] /Count " . $page_count . " >>";
        $objects[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";

        foreach ( $page_ids as $index => $page_id ) {
            $objects[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R >> >> /Contents " . $content_ids[ $index ] . " 0 R >>";
        }
        foreach ( $page_streams as $content ) {
            $objects[] = "<< /Length " . strlen( $content ) . " >>\nstream\n" . $content . "endstream";
        }

        $pdf = "%PDF-1.4\n";
        $offsets = array( 0 );
        foreach ( $objects as $index => $object ) {
            $offsets[] = strlen( $pdf );
            $pdf .= ( $index + 1 ) . " 0 obj\n" . $object . "\nendobj\n";
        }
        $xref = strlen( $pdf );
        $pdf .= "xref\n0 " . ( count( $objects ) + 1 ) . "\n0000000000 65535 f \n";
        for ( $i = 1; $i < count( $offsets ); $i++ ) {
            $pdf .= sprintf( "%010d 00000 n \n", $offsets[ $i ] );
        }
        $pdf .= "trailer\n<< /Size " . ( count( $objects ) + 1 ) . " /Root 1 0 R >>\nstartxref\n" . $xref . "\n%%EOF";

        return $pdf;
    }

    private function summary_for_type( $type ) {
        $metrics = ( new Metrics_Store() )->get_metrics();
        $visibility = ( new Visibility_Store() )->get_metrics();
        $current = isset( $metrics['current'] ) && is_array( $metrics['current'] ) ? $metrics['current'] : array();
        $summary = isset( $current['summary'] ) && is_array( $current['summary'] ) ? $current['summary'] : array();
        $visibility_current = isset( $visibility['current'] ) && is_array( $visibility['current'] ) ? $visibility['current'] : array();
        $rankings = isset( $visibility_current['rankings'] ) && is_array( $visibility_current['rankings'] ) ? $visibility_current['rankings'] : array();

        return array(
            'health_score'  => isset( $current['score'] ) ? (int) $current['score'] . '/100' : 'Pending',
            'grade'         => isset( $current['grade'] ) ? (string) $current['grade'] : 'Not scanned',
            'managed_pages' => count( $this->registry->keys() ),
            'open_issues'   => isset( $summary['issue_count'] ) ? (int) $summary['issue_count'] : 0,
            'keywords'      => isset( $rankings['tracked_keywords'] ) ? (int) $rankings['tracked_keywords'] : 0,
            'report_type'   => $this->type_label( $type ),
        );
    }

    private function sections_for_type( $type, $context ) {
        if ( 'baseline' === $type ) {
            return $this->baseline_sections();
        }
        if ( 'monthly' === $type ) {
            return $this->monthly_sections();
        }
        if ( 'campaign' === $type ) {
            return $this->campaign_sections();
        }
        return $this->competitive_sections( $context );
    }

    private function baseline_sections() {
        $metrics = ( new Metrics_Store() )->get_metrics();
        $health = isset( $metrics['current'] ) && is_array( $metrics['current'] ) ? $metrics['current'] : array();
        $health_summary = isset( $health['summary'] ) && is_array( $health['summary'] ) ? $health['summary'] : array();
        $takeover = ( new Takeover_Store( $this->registry ) )->get_report();
        $current = isset( $takeover['current'] ) && is_array( $takeover['current'] ) ? $takeover['current'] : array();
        $summary = isset( $current['summary'] ) && is_array( $current['summary'] ) ? $current['summary'] : array();
        $visibility = $this->visibility_context();
        $managed_count = count( $this->registry->keys() );
        $pages_scanned = isset( $summary['pages_scanned'] ) ? (int) $summary['pages_scanned'] : 0;
        $pages_needing_review = isset( $summary['pages_needing_review'] ) ? (int) $summary['pages_needing_review'] : 0;
        $current_issues = isset( $health_summary['issue_count'] ) ? (int) $health_summary['issue_count'] : 0;

        return array(
            array(
                'title' => 'Current Baseline',
                'body'  => 'This report captures the current technical SEO baseline, managed coverage, and connected reporting sources.',
                'items'  => array(
                    'Managed registry pages: ' . $managed_count,
                    'Current technical health: ' . ( isset( $health['score'] ) ? (int) $health['score'] . '/100' : 'Pending' ) . ' ' . ( isset( $health['grade'] ) ? (string) $health['grade'] : '' ),
                    'Current open issues: ' . $current_issues,
                    'Setup scan pages captured: ' . $pages_scanned,
                    'Setup scan pages needing review at capture: ' . $pages_needing_review,
                    'Search Console: ' . $visibility['gsc_label'],
                    'Rank tracking: ' . $visibility['rank_label'],
                ),
            ),
            array(
                'title' => 'Recommended Next Moves',
                'body'  => 'Use this as the install-day reference point before approving changes or measuring improvement.',
                'items'  => $this->baseline_recommendations( $visibility, $managed_count, $pages_scanned ),
            ),
        );
    }

    private function monthly_sections() {
        $activity = $this->product_store->activity_summary();
        $visibility = ( new Visibility_Store() )->get_metrics();
        $goals = isset( $visibility['goals'] ) && is_array( $visibility['goals'] ) ? $visibility['goals'] : array();
        $visibility_context = $this->visibility_context( $visibility );
        $traffic_trend = isset( $goals['traffic_trend'] ) ? (string) $goals['traffic_trend'] : 'pending';
        $ranking_trend = isset( $goals['ranking_trend'] ) ? (string) $goals['ranking_trend'] : 'pending';
        if ( $visibility_context['gsc_connected'] && 'pending' === strtolower( $traffic_trend ) ) {
            $traffic_trend = 'connected; awaiting measurable Search Console rows';
        }
        if ( $visibility_context['rank_connected'] && 'pending' === strtolower( $ranking_trend ) ) {
            $ranking_trend = 'connected; awaiting scheduled rank movement';
        }

        return array(
            array(
                'title' => 'Progress Summary',
                'body'  => 'This report summarizes health trend, search visibility, and governed SEO work completed during the reporting window.',
                'items'  => array(
                    'Recorded changes: ' . ( isset( $activity['changes']['total'] ) ? (int) $activity['changes']['total'] : 0 ),
                    'Proposal count: ' . ( isset( $activity['proposals']['total'] ) ? (int) $activity['proposals']['total'] : 0 ),
                    'Traffic trend: ' . $traffic_trend,
                    'Ranking trend: ' . $ranking_trend,
                    'Search Console: ' . $visibility_context['gsc_label'],
                    'Rank tracking: ' . $visibility_context['rank_label'],
                ),
            ),
            array(
                'title' => 'Next Reporting Priorities',
                'body'  => 'The strongest monthly reports combine technical health, ranking movement, Search Console traffic, and a clear narrative of what improved.',
                'items'  => $this->monthly_recommendations( $visibility_context ),
            ),
        );
    }

    private function visibility_context( $visibility = null ) {
        $visibility = is_array( $visibility ) ? $visibility : ( new Visibility_Store() )->get_metrics();
        $providers = isset( $visibility['providers'] ) && is_array( $visibility['providers'] ) ? $visibility['providers'] : array();
        $gsc = isset( $providers['google_search_console'] ) && is_array( $providers['google_search_console'] ) ? $providers['google_search_console'] : array();
        $rank = isset( $providers['rank_provider'] ) && is_array( $providers['rank_provider'] ) ? $providers['rank_provider'] : array();
        $current = isset( $visibility['current'] ) && is_array( $visibility['current'] ) ? $visibility['current'] : array();
        $current_search = isset( $current['search_console'] ) && is_array( $current['search_console'] ) ? $current['search_console'] : array();
        $current_rank = isset( $current['rankings'] ) && is_array( $current['rankings'] ) ? $current['rankings'] : array();

        $gsc_connected = ! empty( $gsc['connected'] );
        $rank_connected = ! empty( $rank['connected'] );
        $gsc_property = isset( $gsc['property_url'] ) && '' !== (string) $gsc['property_url'] ? (string) $gsc['property_url'] : ( isset( $current_search['property_url'] ) ? (string) $current_search['property_url'] : '' );
        $rank_provider = isset( $rank['provider'] ) && '' !== (string) $rank['provider'] ? (string) $rank['provider'] : ( isset( $current_rank['provider'] ) ? (string) $current_rank['provider'] : '' );
        $target_domain = isset( $rank['target_domain'] ) && '' !== (string) $rank['target_domain'] ? (string) $rank['target_domain'] : ( isset( $current_rank['target_domain'] ) ? (string) $current_rank['target_domain'] : '' );

        return array(
            'gsc_connected'  => $gsc_connected,
            'rank_connected' => $rank_connected,
            'gsc_label'      => $gsc_connected ? 'Connected' . ( '' !== $gsc_property ? ' (' . $gsc_property . ')' : '' ) : 'Not connected',
            'rank_label'     => $rank_connected ? 'Connected' . ( '' !== $rank_provider ? ' (' . $rank_provider . ( '' !== $target_domain ? ', ' . $target_domain : '' ) . ')' : '' ) : 'Not connected',
        );
    }

    private function baseline_recommendations( $visibility, $managed_count, $pages_scanned ) {
        $items = array();
        $items[] = ! empty( $visibility['gsc_connected'] )
            ? 'Search Console is connected; let Google return measurable query and page rows before claiming traffic movement.'
            : 'Connect Google Search Console when traffic reporting is part of the customer test.';
        $items[] = ! empty( $visibility['rank_connected'] )
            ? 'Rank tracking is connected; run refreshes intentionally within the three-keyword launch cap.'
            : 'Connect the rank provider before measuring keyword movement.';
        $items[] = $pages_scanned > 0 && $managed_count >= $pages_scanned
            ? 'Managed coverage is complete for the scanned page set.'
            : 'Review unmanaged pages before moving from Orbit into broader Capture or Singularity control.';
        $items[] = 'Create or apply broad SEO changes as governed batches and preserve rollback IDs.';

        return $items;
    }

    private function monthly_recommendations( $visibility ) {
        $items = array();
        $items[] = ! empty( $visibility['gsc_connected'] )
            ? 'Review the first Search Console query and page rows after Google returns measurable data.'
            : 'Connect Google Search Console for clicks, impressions, CTR, and average position.';
        $items[] = ! empty( $visibility['rank_connected'] )
            ? 'Use rank refreshes deliberately under the three-keyword launch cap and report not-found results as valid observations.'
            : 'Connect the rank provider before reporting keyword movement.';
        $items[] = 'Tie applied changes to visibility movement once enough data accumulates.';
        $items[] = 'Keep applied-change history and rollback IDs visible in the improvement narrative.';

        return $items;
    }

    private function campaign_sections() {
        $homepage = $this->registry->get_effective( 'homepage' );
        $homepage = ( new Campaign_Manager() )->apply( $homepage );
        $campaign = isset( $homepage['campaign'] ) && is_array( $homepage['campaign'] ) ? $homepage['campaign'] : array();

        return array(
            array(
                'title' => 'Campaign Status',
                'body'  => 'This report checks the active campaign posture and expiration-safe SEO fields.',
                'items'  => array(
                    'Homepage campaign status: ' . ( isset( $homepage['campaign_status'] ) ? (string) $homepage['campaign_status'] : 'none' ),
                    'Campaign expires: ' . ( isset( $campaign['expires_on'] ) ? (string) $campaign['expires_on'] : 'not set' ),
                    'Expiration logic protects the site from stale campaign metadata.',
                ),
            ),
            array(
                'title' => 'Campaign Recommendations',
                'body'  => 'Campaign SEO should be specific, time-aware, and easy to roll back.',
                'items'  => array(
                    'Use campaign pages only when the offer or event is live and factual.',
                    'Set expiration dates before applying promotional metadata.',
                    'Verify canonical, social, schema, and title output after approval.',
                ),
            ),
        );
    }

    private function competitive_sections( $context ) {
        $competitors = $this->get_competitors();
        $items = array();
        foreach ( $competitors as $competitor ) {
            $items[] = trim( (string) $competitor['name'] . ' ' . (string) $competitor['domain'] );
        }
        if ( empty( $items ) ) {
            $items[] = 'No competitors saved yet. Ask ChatGPT to identify up to five competitors from the site, service area, page intent, and tracked search terms.';
        }

        return array(
            array(
                'title' => 'Competitive Review Setup',
                'body'  => 'This report prepares the inputs for a ChatGPT-assisted Singularity SEO competitive review. WordPress stores the competitors; ChatGPT performs the strategic analysis when the user asks.',
                'items'  => $items,
            ),
            array(
                'title' => 'Review Output To Capture',
                'body'  => 'The review should return structured competitor intelligence that can become dashboard cards later.',
                'items'  => array(
                    'Top observed keywords or topics for each competitor.',
                    'Their strongest page or content advantage.',
                    'Our best opportunity to close the gap.',
                    'Recommended next SEO action, with professional language.',
                ),
            ),
        );
    }

    private function competitive_prompt( $context ) {
        $competitors = $this->get_competitors();
        $lines = array();
        foreach ( $competitors as $competitor ) {
            $name = isset( $competitor['name'] ) ? (string) $competitor['name'] : '';
            $domain = isset( $competitor['domain'] ) ? (string) $competitor['domain'] : '';
            if ( '' !== $name || '' !== $domain ) {
                $lines[] = '- ' . trim( $name . ' ' . $domain );
            }
        }
        $competitor_text = ! empty( $lines )
            ? implode( "\n", $lines )
            : 'No competitors were provided. Identify up to five likely competitors from the site, location, business model, managed pages, and tracked search terms.';

        return "Run a Singularity SEO competitive review for " . home_url( '/' ) . ".\n\n"
            . "Use the Singularity SEO operating manual, site status, managed pages, health metrics, visibility metrics, and any available search context. "
            . "Keep language professional: use terms like outperform, close the gap, capture opportunity, and build advantage.\n\n"
            . "Competitors:\n" . $competitor_text . "\n\n"
            . "Return:\n"
            . "1. Competitive summary.\n"
            . "2. Top observed keywords or topics for each competitor.\n"
            . "3. Their strongest page or content advantage.\n"
            . "4. Our current gaps and opportunities.\n"
            . "5. Recommended next SEO actions.\n"
            . "6. A dashboard-ready JSON block with domain, top_keywords, strongest_page, our_opportunity, recommended_action, and status for each competitor.";
    }

    private function sanitize_competitor( $item ) {
        $item = is_array( $item ) ? $item : array( 'domain' => (string) $item );
        $name = isset( $item['name'] ) ? sanitize_text_field( (string) $item['name'] ) : '';
        $domain = isset( $item['domain'] ) ? $this->clean_domain( (string) $item['domain'] ) : '';
        $notes = isset( $item['notes'] ) ? sanitize_textarea_field( (string) $item['notes'] ) : '';
        if ( '' === $name && '' === $domain ) {
            return array();
        }

        return array(
            'name'   => $name,
            'domain' => $domain,
            'notes'  => $notes,
        );
    }

    private function sanitize_report( $report ) {
        $report = is_array( $report ) ? $report : array();
        return array(
            'id'          => isset( $report['id'] ) ? sanitize_key( (string) $report['id'] ) : '',
            'type'        => isset( $report['type'] ) ? sanitize_key( (string) $report['type'] ) : '',
            'label'       => isset( $report['label'] ) ? sanitize_text_field( (string) $report['label'] ) : '',
            'created_at'  => isset( $report['created_at'] ) ? sanitize_text_field( (string) $report['created_at'] ) : '',
            'source'      => isset( $report['source'] ) ? sanitize_key( (string) $report['source'] ) : '',
            'site'        => isset( $report['site'] ) && is_array( $report['site'] ) ? array_map( 'sanitize_text_field', $report['site'] ) : array(),
            'summary'     => isset( $report['summary'] ) && is_array( $report['summary'] ) ? $this->sanitize_nested_text( $report['summary'] ) : array(),
            'sections'    => isset( $report['sections'] ) && is_array( $report['sections'] ) ? $this->sanitize_nested_text( $report['sections'] ) : array(),
            'competitors' => isset( $report['competitors'] ) && is_array( $report['competitors'] ) ? array_map( array( $this, 'sanitize_competitor' ), $report['competitors'] ) : array(),
            'prompt'      => isset( $report['prompt'] ) ? sanitize_textarea_field( (string) $report['prompt'] ) : '',
        );
    }

    private function sanitize_nested_text( $value ) {
        if ( is_array( $value ) ) {
            $clean = array();
            foreach ( $value as $key => $child ) {
                $clean[ is_int( $key ) ? $key : sanitize_key( (string) $key ) ] = $this->sanitize_nested_text( $child );
            }
            return $clean;
        }
        if ( is_bool( $value ) ) {
            return $value;
        }
        if ( is_numeric( $value ) ) {
            return $value;
        }
        return sanitize_textarea_field( (string) $value );
    }

    private function clean_domain( $domain ) {
        $domain = strtolower( trim( (string) $domain ) );
        if ( '' === $domain ) {
            return '';
        }
        $host = wp_parse_url( false === strpos( $domain, '://' ) ? 'https://' . $domain : $domain, PHP_URL_HOST );
        $host = strtolower( trim( (string) $host, ". \t\n\r\0\x0B" ) );
        if ( 0 === strpos( $host, 'www.' ) ) {
            $host = substr( $host, 4 );
        }

        return preg_match( '/^[a-z0-9.-]+\.[a-z]{2,}$/', $host ) ? $host : '';
    }

    private function type_label( $type ) {
        $labels = array(
            'baseline'    => 'Baseline SEO Report',
            'monthly'     => 'Monthly Progress Report',
            'campaign'    => 'Campaign Status Report',
            'competitive' => 'Competitive Review Brief',
        );

        return isset( $labels[ $type ] ) ? $labels[ $type ] : 'Singularity SEO Report';
    }

    private function human_label( $key ) {
        return ucwords( str_replace( '_', ' ', (string) $key ) );
    }

    private function format_date( $mysql_gmt ) {
        $timestamp = strtotime( (string) $mysql_gmt . ' UTC' );
        return $timestamp ? wp_date( 'M j, Y g:i A', $timestamp ) : (string) $mysql_gmt;
    }

    private function pdf_page_streams( $report ) {
        $report = $this->sanitize_report( $report );
        $pages = array();
        $ops = array();
        $y = $this->pdf_draw_page_header( $ops, $report, true );
        $y = $this->pdf_draw_summary_cards( $ops, isset( $report['summary'] ) && is_array( $report['summary'] ) ? $report['summary'] : array(), $y );

        foreach ( (array) $report['sections'] as $section ) {
            if ( $y < 175 ) {
                $this->pdf_draw_footer( $ops );
                $pages[] = implode( "\n", $ops ) . "\n";
                $ops = array();
                $y = $this->pdf_draw_page_header( $ops, $report, false );
            }
            $y = $this->pdf_draw_section( $ops, $section, $y );
        }

        $this->pdf_draw_footer( $ops );
        $pages[] = implode( "\n", $ops ) . "\n";

        return $pages;
    }

    private function pdf_draw_page_header( &$ops, $report, $first_page ) {
        $title = isset( $report['label'] ) ? (string) $report['label'] : 'Singularity SEO Report';
        $site = isset( $report['site']['url'] ) ? (string) $report['site']['url'] : home_url( '/' );
        $created = isset( $report['created_at'] ) ? (string) $report['created_at'] : '';
        $this->pdf_rect( $ops, 0, 666, 612, 126, '0.027 0.094 0.278' );
        $this->pdf_rect( $ops, 0, 666, 612, 14, '0.118 0.329 1' );
        $this->pdf_text( $ops, 'Singularity SEO', 42, 746, 17, '1 1 1' );
        $this->pdf_text( $ops, $title, 42, 714, $first_page ? 24 : 18, '1 1 1' );
        $this->pdf_text( $ops, $site . ' - ' . $this->format_date( $created ), 42, 690, 10, '0.78 0.84 1' );
        $this->pdf_rect( $ops, 444, 718, 126, 34, '0.078 0.203 0.565' );
        $this->pdf_text( $ops, 'AI-MANAGED SEO', 462, 731, 9, '0.82 0.9 1' );

        return 626;
    }

    private function pdf_draw_summary_cards( &$ops, $summary, $y ) {
        $x = 42;
        $card_width = 164;
        $card_height = 58;
        $gap = 12;
        $index = 0;
        foreach ( $summary as $label => $value ) {
            $row = (int) floor( $index / 3 );
            $col = $index % 3;
            $cx = $x + ( $col * ( $card_width + $gap ) );
            $cy = $y - ( $row * ( $card_height + 12 ) );
            $this->pdf_rect( $ops, $cx, $cy - $card_height, $card_width, $card_height, '0.965 0.978 1' );
            $this->pdf_text( $ops, strtoupper( $this->human_label( $label ) ), $cx + 12, $cy - 20, 7, '0.38 0.44 0.56' );
            $this->pdf_text( $ops, is_scalar( $value ) ? (string) $value : wp_json_encode( $value ), $cx + 12, $cy - 42, 16, '0.031 0.078 0.184' );
            $index++;
        }

        $rows = max( 1, (int) ceil( max( 1, count( $summary ) ) / 3 ) );
        return $y - ( $rows * ( $card_height + 12 ) ) - 8;
    }

    private function pdf_draw_section( &$ops, $section, $y ) {
        $title = isset( $section['title'] ) ? (string) $section['title'] : '';
        $body = isset( $section['body'] ) ? (string) $section['body'] : '';
        $this->pdf_rect( $ops, 42, $y - 2, 528, 1.2, '0.82 0.87 0.96' );
        $this->pdf_text( $ops, $title, 42, $y - 24, 15, '0.031 0.078 0.184' );
        $y -= 44;
        foreach ( $this->wrap_text( $body, 92 ) as $wrapped ) {
            $this->pdf_text( $ops, $wrapped, 42, $y, 9, '0.25 0.29 0.38' );
            $y -= 13;
        }
        if ( ! empty( $section['items'] ) && is_array( $section['items'] ) ) {
            $y -= 3;
            foreach ( $section['items'] as $item ) {
                foreach ( $this->wrap_text( (string) $item, 86 ) as $index => $wrapped ) {
                    $prefix = 0 === $index ? '- ' : '  ';
                    $this->pdf_text( $ops, $prefix . $wrapped, 54, $y, 9, '0.031 0.078 0.184' );
                    $y -= 13;
                }
            }
        }

        return $y - 18;
    }

    private function pdf_draw_footer( &$ops ) {
        $this->pdf_rect( $ops, 42, 46, 528, 1, '0.82 0.87 0.96' );
        $this->pdf_text( $ops, 'Singularity SEO by Agency689', 42, 28, 9, '0.38 0.44 0.56' );
        $this->pdf_text( $ops, 'Review AI-assisted recommendations before publication.', 374, 28, 8, '0.38 0.44 0.56' );
    }

    private function pdf_rect( &$ops, $x, $y, $w, $h, $color ) {
        $ops[] = $color . " rg\n" . $this->pdf_number( $x ) . ' ' . $this->pdf_number( $y ) . ' ' . $this->pdf_number( $w ) . ' ' . $this->pdf_number( $h ) . ' re f';
    }

    private function pdf_text( &$ops, $text, $x, $y, $size, $color ) {
        $ops[] = "BT\n" . $color . " rg\n/F1 " . $this->pdf_number( $size ) . " Tf\n" . $this->pdf_number( $x ) . ' ' . $this->pdf_number( $y ) . " Td\n(" . $this->pdf_escape( $text ) . ") Tj\nET";
    }

    private function pdf_number( $value ) {
        return rtrim( rtrim( sprintf( '%.3F', (float) $value ), '0' ), '.' );
    }

    private function wrap_text( $text, $width ) {
        $text = preg_replace( '/\s+/', ' ', (string) $text );
        return explode( "\n", wordwrap( $text, $width, "\n", true ) );
    }

    private function pdf_escape( $text ) {
        $text = preg_replace( '/[^\x20-\x7E]/', '', (string) $text );
        return str_replace( array( '\\', '(', ')' ), array( '\\\\', '\\(', '\\)' ), $text );
    }

    private function new_id( $prefix ) {
        $uuid = function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( '', true );
        return sanitize_key( $prefix . '_' . str_replace( '-', '', $uuid ) );
    }
}
