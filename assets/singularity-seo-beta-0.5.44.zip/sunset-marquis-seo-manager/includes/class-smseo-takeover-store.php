<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Takeover_Store {
    const SCANS_OPTION = 'smseo_takeover_scans';
    const MAX_SCANS = 20;
    const FETCH_TIMEOUT_SECONDS = 10;
    const MAX_PAGES_PER_SCAN = 30;

    private $registry;

    public function __construct( Registry $registry ) {
        $this->registry = $registry;
    }

    public function get_report() {
        $scans = $this->get_scans();
        $current = ! empty( $scans ) ? end( $scans ) : null;

        return array(
            'current'        => $current,
            'scan_count'     => count( $scans ),
            'history'        => $this->history_points( $scans ),
            'takeover_modes' => array(
                array(
                    'key'         => 'monitor_only',
                    'label'       => 'Monitor only',
                    'description' => 'Keep existing public SEO output and use Singularity SEO for audits, reporting and recommendations.',
                ),
                array(
                    'key'         => 'selected_pages',
                    'label'       => 'Manage selected pages',
                    'description' => 'Approve specific pages or fields before Singularity SEO controls public metadata.',
                ),
                array(
                    'key'         => 'recommended_pages',
                    'label'       => 'Manage recommended pages',
                    'description' => 'Use the takeover report to prioritize pages with missing, weak or conflicting SEO.',
                ),
            ),
        );
    }

    public function create_scan( $source = 'manual' ) {
        $items = $this->scan_items();
        $summary = $this->summarize( $items );

        $scan = array(
            'id'              => 'takeover_' . gmdate( 'YmdHis' ),
            'captured_at'     => current_time( 'mysql', true ),
            'source'          => sanitize_key( (string) $source ),
            'site'            => array(
                'home_url'    => home_url( '/' ),
                'site_url'    => site_url( '/' ),
                'blog_public' => '0' !== (string) get_option( 'blog_public' ),
            ),
            'detected_plugins' => $this->detected_seo_plugins(),
            'summary'         => $summary,
            'recommendations' => $this->recommendations( $summary ),
            'pages'           => $items,
        );

        $scans = $this->get_scans();
        $scans[] = $scan;
        if ( count( $scans ) > self::MAX_SCANS ) {
            $scans = array_slice( $scans, -1 * self::MAX_SCANS );
        }
        update_option( self::SCANS_OPTION, $scans, false );

        return $scan;
    }

    public function get_scans() {
        $scans = get_option( self::SCANS_OPTION, array() );
        return is_array( $scans ) ? array_values( $scans ) : array();
    }

    private function scan_items() {
        $targets = $this->scan_targets();
        $items = array();

        foreach ( $targets as $target ) {
            $items[] = $this->scan_url( $target );
        }

        return $items;
    }

    private function scan_targets() {
        $targets = array();
        $seen = array();

        $front_id = (int) get_option( 'page_on_front' );
        $home_url = home_url( '/' );
        $targets[] = array(
            'post_id'     => $front_id,
            'label'       => 'Homepage',
            'url'         => $home_url,
            'path'        => '/',
            'managed_key' => $this->registry->key_for_post_id( $front_id ),
        );
        $seen[ untrailingslashit( $home_url ) ] = true;

        $posts = get_posts(
            array(
                'post_type'      => 'page',
                'post_status'    => 'publish',
                'posts_per_page' => self::MAX_PAGES_PER_SCAN,
                'orderby'        => 'menu_order title',
                'order'          => 'ASC',
            )
        );

        foreach ( $posts as $post ) {
            if ( ! $post instanceof \WP_Post ) {
                continue;
            }
            $url = get_permalink( $post );
            if ( ! is_string( $url ) || '' === $url ) {
                continue;
            }
            $url_key = untrailingslashit( $url );
            if ( isset( $seen[ $url_key ] ) ) {
                continue;
            }
            $seen[ $url_key ] = true;
            $targets[] = array(
                'post_id'     => (int) $post->ID,
                'label'       => get_the_title( $post ),
                'url'         => $url,
                'path'        => $this->registry->normalize_path( $url ),
                'managed_key' => $this->registry->key_for_post_id( $post->ID ),
            );
            if ( count( $targets ) >= self::MAX_PAGES_PER_SCAN ) {
                break;
            }
        }

        return $targets;
    }

    private function scan_url( $target ) {
        $row = array(
            'post_id'              => isset( $target['post_id'] ) ? (int) $target['post_id'] : 0,
            'label'                => isset( $target['label'] ) ? sanitize_text_field( (string) $target['label'] ) : '',
            'url'                  => isset( $target['url'] ) ? esc_url_raw( (string) $target['url'] ) : '',
            'path'                 => isset( $target['path'] ) ? sanitize_text_field( (string) $target['path'] ) : '',
            'managed'              => ! empty( $target['managed_key'] ),
            'managed_key'          => isset( $target['managed_key'] ) ? sanitize_key( (string) $target['managed_key'] ) : '',
            'http_code'            => 0,
            'status'               => 'fail',
            'issues'               => array(),
            'title'                => '',
            'title_count'          => 0,
            'description'          => '',
            'description_count'    => 0,
            'canonical'            => '',
            'canonical_count'      => 0,
            'robots'               => '',
            'robots_count'         => 0,
            'og_title_count'       => 0,
            'og_description_count' => 0,
            'twitter_title_count'  => 0,
            'schema_count'         => 0,
            'schema_valid'         => 0,
            'schema_invalid'       => 0,
        );

        if ( '' === $row['url'] ) {
            $row['issues'][] = 'Missing URL';
            return $row;
        }

        $fetch_url = $this->cache_busted_url( $row['url'], 'smseo_scan_bust' );
        $row['fetch_url'] = $fetch_url;
        $response = wp_remote_get(
            $fetch_url,
            $this->fresh_request_args( 'Singularity SEO Takeover Scan/' . ( defined( 'SMSEO_VERSION' ) ? SMSEO_VERSION : 'unknown' ) )
        );

        if ( is_wp_error( $response ) ) {
            $row['issues'][] = 'Fetch failed: ' . $response->get_error_message();
            return $row;
        }

        $row['http_code'] = (int) wp_remote_retrieve_response_code( $response );
        $html = (string) wp_remote_retrieve_body( $response );
        if ( $row['http_code'] < 200 || $row['http_code'] >= 400 ) {
            $row['issues'][] = 'Unexpected HTTP response';
        }
        if ( '' === trim( $html ) ) {
            $row['issues'][] = 'Empty HTML response';
            return $row;
        }
        if ( ! class_exists( '\\DOMDocument' ) ) {
            $row['issues'][] = 'DOMDocument unavailable; scan parser cannot inspect HTML';
            return $row;
        }

        libxml_use_internal_errors( true );
        $dom = new \DOMDocument();
        $loaded = $dom->loadHTML( $html, LIBXML_NOWARNING | LIBXML_NOERROR );
        libxml_clear_errors();
        if ( ! $loaded ) {
            $row['issues'][] = 'HTML parser failed';
            return $row;
        }

        $xpath = new \DOMXPath( $dom );
        $titles = $xpath->query( '//head/title' );
        $row['title_count'] = $titles ? (int) $titles->length : 0;
        if ( $titles && $titles->length > 0 ) {
            $row['title'] = trim( sanitize_text_field( (string) $titles->item( 0 )->textContent ) );
        }

        $row['description_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="description"]' );
        $row['description'] = $this->xpath_attr( $xpath, '//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="description"]', 'content' );
        $row['canonical_count'] = $this->xpath_count( $xpath, '//head/link[translate(@rel,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="canonical"]' );
        $row['canonical'] = $this->xpath_attr( $xpath, '//head/link[translate(@rel,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="canonical"]', 'href' );
        $row['robots_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="robots"]' );
        $row['robots'] = $this->xpath_attr( $xpath, '//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="robots"]', 'content' );
        $row['og_title_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@property,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="og:title"]' );
        $row['og_description_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@property,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="og:description"]' );
        $row['twitter_title_count'] = $this->xpath_count( $xpath, '//head/meta[translate(@name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="twitter:title"]' );

        $schema_nodes = $xpath->query( '//head/script[translate(@type,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz")="application/ld+json"]' );
        $row['schema_count'] = $schema_nodes ? (int) $schema_nodes->length : 0;
        if ( $schema_nodes ) {
            foreach ( $schema_nodes as $schema_node ) {
                $decoded = json_decode( trim( (string) $schema_node->textContent ), true );
                if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
                    $row['schema_valid']++;
                } else {
                    $row['schema_invalid']++;
                }
            }
        }

        $row['issues'] = array_merge( $row['issues'], $this->page_issues( $row ) );
        $row['status'] = empty( $row['issues'] ) ? 'pass' : 'review';

        return $row;
    }

    private function page_issues( $row ) {
        $issues = array();
        if ( 1 !== (int) $row['title_count'] ) {
            $issues[] = 'Title tag count needs review';
        }
        if ( '' === (string) $row['title'] ) {
            $issues[] = 'Missing title text';
        } elseif ( strlen( (string) $row['title'] ) > 70 ) {
            $issues[] = 'Title may be too long';
        }
        if ( 1 !== (int) $row['description_count'] ) {
            $issues[] = 'Meta description count needs review';
        }
        if ( '' === (string) $row['description'] ) {
            $issues[] = 'Missing meta description';
        } elseif ( strlen( (string) $row['description'] ) > 170 ) {
            $issues[] = 'Meta description may be too long';
        }
        if ( 1 !== (int) $row['canonical_count'] ) {
            $issues[] = 'Canonical count needs review';
        }
        if ( 0 === (int) $row['schema_count'] ) {
            $issues[] = 'No JSON-LD schema detected';
        }
        if ( (int) $row['schema_invalid'] > 0 ) {
            $issues[] = 'Invalid JSON-LD schema detected';
        }
        if ( false !== stripos( (string) $row['robots'], 'noindex' ) ) {
            $issues[] = 'Page is noindex';
        }
        if ( 0 === (int) $row['og_title_count'] || 0 === (int) $row['og_description_count'] ) {
            $issues[] = 'Open Graph tags incomplete';
        }
        if ( 0 === (int) $row['twitter_title_count'] ) {
            $issues[] = 'Twitter/X title missing';
        }

        return array_values( array_unique( $issues ) );
    }

    private function summarize( $items ) {
        $summary = array(
            'pages_scanned'         => count( $items ),
            'pages_passing'         => 0,
            'pages_needing_review'  => 0,
            'managed_pages_seen'    => 0,
            'unmanaged_pages_seen'  => 0,
            'missing_titles'        => 0,
            'missing_descriptions'  => 0,
            'canonical_issues'      => 0,
            'schema_issues'         => 0,
            'social_issues'         => 0,
            'noindex_pages'         => 0,
            'takeover_readiness'    => 'review_needed',
        );

        foreach ( $items as $item ) {
            if ( ! empty( $item['managed'] ) ) {
                $summary['managed_pages_seen']++;
            } else {
                $summary['unmanaged_pages_seen']++;
            }
            if ( 'pass' === (string) $item['status'] ) {
                $summary['pages_passing']++;
            } else {
                $summary['pages_needing_review']++;
            }
            if ( '' === (string) $item['title'] ) {
                $summary['missing_titles']++;
            }
            if ( '' === (string) $item['description'] ) {
                $summary['missing_descriptions']++;
            }
            if ( 1 !== (int) $item['canonical_count'] ) {
                $summary['canonical_issues']++;
            }
            if ( 0 === (int) $item['schema_count'] || (int) $item['schema_invalid'] > 0 ) {
                $summary['schema_issues']++;
            }
            if ( 0 === (int) $item['og_title_count'] || 0 === (int) $item['og_description_count'] || 0 === (int) $item['twitter_title_count'] ) {
                $summary['social_issues']++;
            }
            if ( false !== stripos( (string) $item['robots'], 'noindex' ) ) {
                $summary['noindex_pages']++;
            }
        }

        if ( 0 === $summary['pages_needing_review'] && $summary['pages_scanned'] > 0 ) {
            $summary['takeover_readiness'] = 'ready_for_control';
        } elseif ( $summary['pages_passing'] > 0 ) {
            $summary['takeover_readiness'] = 'selective_takeover_recommended';
        }

        return $summary;
    }

    private function recommendations( $summary ) {
        $recommendations = array();
        if ( $summary['unmanaged_pages_seen'] > 0 ) {
            $recommendations[] = 'Review unmanaged published pages and decide which should be brought under Singularity SEO control.';
        }
        if ( $summary['missing_titles'] > 0 || $summary['missing_descriptions'] > 0 ) {
            $recommendations[] = 'Prioritize pages with missing title or meta description text.';
        }
        if ( $summary['canonical_issues'] > 0 ) {
            $recommendations[] = 'Fix canonical tag count issues before full takeover.';
        }
        if ( $summary['schema_issues'] > 0 ) {
            $recommendations[] = 'Add or repair JSON-LD schema on priority pages.';
        }
        if ( $summary['social_issues'] > 0 ) {
            $recommendations[] = 'Complete Open Graph and Twitter/X metadata for share previews.';
        }
        if ( $summary['noindex_pages'] > 0 ) {
            $recommendations[] = 'Confirm noindex pages are intentional before measuring SEO visibility.';
        }
        if ( empty( $recommendations ) ) {
            $recommendations[] = 'Current SEO output is clean enough for a controlled page-by-page takeover plan.';
        }

        return $recommendations;
    }

    private function detected_seo_plugins() {
        $active = get_option( 'active_plugins', array() );
        $network_active = is_multisite() ? array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) : array();
        $plugins = array_merge( (array) $active, $network_active );
        $known = array(
            'wordpress-seo' => 'Yoast SEO',
            'all-in-one-seo' => 'All in One SEO',
            'aioseo'        => 'All in One SEO',
            'wp-seopress'   => 'SEOPress',
            'the-seo-framework' => 'The SEO Framework',
        );
        $detected = array();
        foreach ( $plugins as $plugin ) {
            foreach ( $known as $needle => $label ) {
                if ( false !== stripos( (string) $plugin, $needle ) ) {
                    $detected[] = $label;
                }
            }
        }

        return array_values( array_unique( $detected ) );
    }

    private function xpath_count( \DOMXPath $xpath, $query ) {
        $nodes = $xpath->query( $query );
        return $nodes ? (int) $nodes->length : 0;
    }

    private function cache_busted_url( $url, $arg_name ) {
        return add_query_arg( $arg_name, rawurlencode( (string) microtime( true ) ), $url );
    }

    private function fresh_request_args( $user_agent ) {
        return array(
            'timeout'     => self::FETCH_TIMEOUT_SECONDS,
            'redirection' => 3,
            'user-agent'  => $user_agent,
            'headers'     => array(
                'Cache-Control' => 'no-cache, no-store, max-age=0',
                'Pragma'        => 'no-cache',
                'Expires'       => '0',
            ),
        );
    }

    private function xpath_attr( \DOMXPath $xpath, $query, $attr ) {
        $nodes = $xpath->query( $query );
        if ( ! $nodes || $nodes->length < 1 ) {
            return '';
        }
        $node = $nodes->item( 0 );
        if ( ! $node instanceof \DOMElement ) {
            return '';
        }

        return sanitize_text_field( (string) $node->getAttribute( $attr ) );
    }

    private function history_points( $scans ) {
        $points = array();
        foreach ( $scans as $scan ) {
            $summary = isset( $scan['summary'] ) && is_array( $scan['summary'] ) ? $scan['summary'] : array();
            $points[] = array(
                'captured_at'           => isset( $scan['captured_at'] ) ? (string) $scan['captured_at'] : '',
                'pages_scanned'         => isset( $summary['pages_scanned'] ) ? (int) $summary['pages_scanned'] : 0,
                'pages_needing_review'  => isset( $summary['pages_needing_review'] ) ? (int) $summary['pages_needing_review'] : 0,
                'takeover_readiness'    => isset( $summary['takeover_readiness'] ) ? (string) $summary['takeover_readiness'] : '',
            );
        }

        return $points;
    }
}
