<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Validation {
    public static function sanitize_absolute_http_url( $value ) {
        $raw = trim( (string) $value );

        if ( '' === $raw ) {
            return '';
        }

        $url = esc_url_raw( $raw, array( 'http', 'https' ) );
        if ( '' === $url ) {
            return false;
        }

        $parts = wp_parse_url( $url );
        if ( ! is_array( $parts ) ) {
            return false;
        }

        $scheme = isset( $parts['scheme'] ) ? strtolower( (string) $parts['scheme'] ) : '';
        $host = isset( $parts['host'] ) ? trim( (string) $parts['host'] ) : '';

        if ( ! in_array( $scheme, array( 'http', 'https' ), true ) || '' === $host ) {
            return false;
        }

        if ( isset( $parts['user'] ) || isset( $parts['pass'] ) ) {
            return false;
        }

        return $url;
    }

    public static function sanitize_search_console_property( $value ) {
        $raw = trim( (string) $value );

        if ( '' === $raw ) {
            return '';
        }

        if ( 0 === strpos( strtolower( $raw ), 'sc-domain:' ) ) {
            $domain = strtolower( trim( substr( $raw, strlen( 'sc-domain:' ) ) ) );
            $domain = preg_replace( '/^www\./', '', $domain );
            if ( preg_match( '/^(?!-)(?:[a-z0-9-]{1,63}\.)+[a-z]{2,63}$/', $domain ) ) {
                return 'sc-domain:' . $domain;
            }

            return false;
        }

        return self::sanitize_absolute_http_url( $raw );
    }

    public static function is_valid_iso_date( $value ) {
        if ( ! is_string( $value ) ) {
            return false;
        }

        $value = trim( $value );
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
            return false;
        }

        $year = (int) substr( $value, 0, 4 );
        $month = (int) substr( $value, 5, 2 );
        $day = (int) substr( $value, 8, 2 );

        return checkdate( $month, $day, $year );
    }
}
