<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Product_Store {
    const OPERATING_MANUAL_OPTION = 'smseo_operating_manual';
    const PROPOSALS_OPTION = 'smseo_proposals';
    const CHANGES_OPTION = 'smseo_changes';
    const MAX_CHANGES = 250;
    const STALE_PROPOSAL_TTL = 86400;

    public function get_operating_manual() {
        $manual = get_option( self::OPERATING_MANUAL_OPTION, '' );
        if ( is_string( $manual ) && '' !== trim( $manual ) ) {
            return $manual;
        }

        return $this->bundled_operating_manual();
    }

    public function get_operating_manual_updated_at() {
        $updated_at = (string) get_option( 'smseo_operating_manual_updated_at', '' );
        if ( '' !== $updated_at ) {
            return $updated_at;
        }

        return 'bundled-' . ( defined( 'SMSEO_VERSION' ) ? SMSEO_VERSION : 'current' );
    }

    public function list_proposals() {
        return $this->expire_stale_open_proposals( $this->raw_proposals() );
    }

    public function get_proposal( $id ) {
        $id = sanitize_key( (string) $id );
        $items = $this->raw_proposals();
        return isset( $items[ $id ] ) && is_array( $items[ $id ] ) ? $items[ $id ] : null;
    }

    public function save_proposal( $proposal ) {
        $proposal = $this->sanitize_proposal( $proposal );
        if ( empty( $proposal['id'] ) ) {
            $proposal['id'] = $this->new_id( 'proposal' );
        }
        if ( empty( $proposal['created_at'] ) ) {
            $proposal['created_at'] = current_time( 'mysql', true );
        }
        if ( empty( $proposal['status'] ) ) {
            $proposal['status'] = 'draft';
        }

        $items = $this->raw_proposals();
        $items[ $proposal['id'] ] = $proposal;
        update_option( self::PROPOSALS_OPTION, $items, false );

        return $proposal;
    }

    public function update_proposal_status( $id, $status, $extra = array() ) {
        $proposal = $this->get_proposal( $id );
        if ( ! is_array( $proposal ) ) {
            return null;
        }

        $status = sanitize_key( (string) $status );
        $proposal['status'] = $status;

        foreach ( (array) $extra as $key => $value ) {
            $proposal[ sanitize_key( (string) $key ) ] = $this->sanitize_value( $value );
        }

        return $this->save_proposal( $proposal );
    }

    public function list_changes() {
        $items = get_option( self::CHANGES_OPTION, array() );
        return is_array( $items ) ? $items : array();
    }

    public function get_change( $id ) {
        $id = sanitize_key( (string) $id );
        $items = $this->list_changes();
        return isset( $items[ $id ] ) && is_array( $items[ $id ] ) ? $items[ $id ] : null;
    }

    public function update_change( $id, $fields ) {
        $id = sanitize_key( (string) $id );
        $items = $this->list_changes();
        if ( empty( $items[ $id ] ) || ! is_array( $items[ $id ] ) ) {
            return null;
        }

        foreach ( (array) $fields as $key => $value ) {
            $items[ $id ][ sanitize_key( (string) $key ) ] = $this->sanitize_value( $value );
        }

        $items[ $id ] = $this->sanitize_change( $items[ $id ] );
        update_option( self::CHANGES_OPTION, $items, false );

        return $items[ $id ];
    }

    public function record_change( $change ) {
        $change = $this->sanitize_change( $change );
        if ( empty( $change['id'] ) ) {
            $change['id'] = $this->new_id( 'change' );
        }
        if ( empty( $change['created_at'] ) ) {
            $change['created_at'] = current_time( 'mysql', true );
        }

        $items = $this->list_changes();
        $items[ $change['id'] ] = $change;

        if ( count( $items ) > self::MAX_CHANGES ) {
            uasort(
                $items,
                function ( $a, $b ) {
                    return strcmp( isset( $b['created_at'] ) ? $b['created_at'] : '', isset( $a['created_at'] ) ? $a['created_at'] : '' );
                }
            );
            $items = array_slice( $items, 0, self::MAX_CHANGES, true );
        }

        update_option( self::CHANGES_OPTION, $items, false );
        return $change;
    }

    public function activity_summary() {
        $proposals = $this->list_proposals();
        $changes = $this->list_changes();
        $proposal_statuses = array();

        foreach ( $proposals as $proposal ) {
            $status = isset( $proposal['status'] ) ? (string) $proposal['status'] : 'unknown';
            $proposal_statuses[ $status ] = isset( $proposal_statuses[ $status ] ) ? $proposal_statuses[ $status ] + 1 : 1;
        }

        return array(
            'proposals' => array(
                'total' => count( $proposals ),
                'by_status' => $proposal_statuses,
            ),
            'changes' => array(
                'total' => count( $changes ),
                'latest' => array_values( array_slice( array_reverse( $changes ), 0, 5 ) ),
            ),
        );
    }

    private function raw_proposals() {
        $items = get_option( self::PROPOSALS_OPTION, array() );
        return is_array( $items ) ? $items : array();
    }

    private function expire_stale_open_proposals( $items ) {
        $items = is_array( $items ) ? $items : array();
        $changed = false;
        $now = time();
        foreach ( $items as $id => $proposal ) {
            if ( ! is_array( $proposal ) ) {
                continue;
            }
            $status = isset( $proposal['status'] ) ? (string) $proposal['status'] : 'draft';
            if ( ! in_array( $status, array( 'draft', 'pending_approval', 'approved' ), true ) ) {
                continue;
            }

            $created_at = isset( $proposal['created_at'] ) ? strtotime( (string) $proposal['created_at'] . ' UTC' ) : false;
            if ( false === $created_at || ( $now - $created_at ) < self::STALE_PROPOSAL_TTL ) {
                continue;
            }

            $items[ $id ]['status'] = 'expired';
            $items[ $id ]['expired_at'] = current_time( 'mysql', true );
            $items[ $id ]['expiration_reason'] = 'Automatically expired stale open proposal after 24 hours.';
            $changed = true;
        }

        if ( $changed ) {
            update_option( self::PROPOSALS_OPTION, $items, false );
        }

        return $items;
    }

    private function bundled_operating_manual() {
        $manuals = array();
        $path = defined( 'SMSEO_PLUGIN_DIR' ) ? SMSEO_PLUGIN_DIR . 'includes/config/operating-manuals.php' : '';
        if ( '' !== $path && file_exists( $path ) ) {
            $manuals = include $path;
        }
        $manuals = is_array( $manuals ) ? $manuals : array();
        $host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
        if ( 0 === strpos( $host, 'www.' ) ) {
            $host = substr( $host, 4 );
        }
        if ( 'agency689.com' === $host && ! empty( $manuals['agency689'] ) ) {
            return (string) $manuals['agency689'];
        }

        return isset( $manuals['default'] ) ? (string) $manuals['default'] : '';
    }

    private function sanitize_proposal( $proposal ) {
        $proposal = is_array( $proposal ) ? $proposal : array();
        $allowed = array(
            'id',
            'status',
            'page_key',
            'proposal_type',
            'risk_tier',
            'approval_mode',
            'reason',
            'plain_english_summary',
            'current_values',
            'proposed_values',
            'changes',
            'risk_notes',
            'autopilot_eligible',
            'expires_at',
            'approval_notes',
            'created_at',
            'approved_at',
            'applied_at',
            'expired_at',
            'expiration_reason',
            'audit_before',
            'audit_after',
            'change_id',
        );

        return $this->sanitize_allowed_keys( $proposal, $allowed );
    }

    private function sanitize_change( $change ) {
        $change = is_array( $change ) ? $change : array();
        $allowed = array(
            'id',
            'proposal_id',
            'actor',
            'page_key',
            'fields_changed',
            'before',
            'after',
            'pages',
            'created_at',
            'rollback_available',
        );

        return $this->sanitize_allowed_keys( $change, $allowed );
    }

    private function sanitize_allowed_keys( $item, $allowed ) {
        $clean = array();
        foreach ( $allowed as $key ) {
            if ( array_key_exists( $key, $item ) ) {
                $clean[ $key ] = $this->sanitize_value( $item[ $key ] );
            }
        }
        return $clean;
    }

    private function sanitize_value( $value ) {
        if ( is_array( $value ) ) {
            $clean = array();
            foreach ( $value as $key => $child ) {
                $clean[ sanitize_key( (string) $key ) ] = $this->sanitize_value( $child );
            }
            return $clean;
        }

        if ( is_bool( $value ) ) {
            return $value;
        }

        return sanitize_textarea_field( (string) $value );
    }

    private function new_id( $prefix ) {
        $uuid = function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( '', true );
        return sanitize_key( $prefix . '_' . str_replace( '-', '', $uuid ) );
    }
}
