<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Cache_Manager {
    public static function purge_targets( $targets ) {
        $targets = is_array( $targets ) ? array_values( $targets ) : array();
        $urls = array();
        $post_ids = array();
        $actions = array();

        foreach ( $targets as $target ) {
            if ( ! is_array( $target ) ) {
                continue;
            }
            $url = isset( $target['url'] ) ? esc_url_raw( (string) $target['url'] ) : '';
            if ( '' !== $url ) {
                $urls[] = $url;
            }
            $post_id = isset( $target['post_id'] ) ? (int) $target['post_id'] : 0;
            if ( $post_id > 0 ) {
                $post_ids[] = $post_id;
            }
        }

        $urls = array_values( array_unique( array_filter( $urls ) ) );
        $post_ids = array_values( array_unique( array_filter( $post_ids ) ) );

        foreach ( $post_ids as $post_id ) {
            clean_post_cache( $post_id );
        }
        if ( ! empty( $post_ids ) ) {
            $actions[] = 'clean_post_cache';
        }

        foreach ( $urls as $url ) {
            do_action( 'smseo_purge_url_cache', $url );

            if ( function_exists( 'w3tc_flush_url' ) ) {
                w3tc_flush_url( $url );
                $actions[] = 'w3tc_flush_url';
            }

            if ( function_exists( 'rocket_clean_files' ) ) {
                rocket_clean_files( array( $url ) );
                $actions[] = 'rocket_clean_files';
            }

            if ( function_exists( 'sg_cachepress_purge_url' ) ) {
                sg_cachepress_purge_url( $url );
                $actions[] = 'sg_cachepress_purge_url';
            }

            do_action( 'litespeed_purge_url', $url );
            $actions[] = 'litespeed_purge_url';
        }

        if ( function_exists( 'wp_cache_clear_cache' ) ) {
            wp_cache_clear_cache();
            $actions[] = 'wp_cache_clear_cache';
        }

        if ( class_exists( '\\autoptimizeCache' ) && is_callable( array( '\\autoptimizeCache', 'clearall' ) ) ) {
            \autoptimizeCache::clearall();
            $actions[] = 'autoptimizeCache::clearall';
        }

        do_action( 'smseo_after_seo_output_change', $urls, $post_ids );

        return array(
            'attempted' => true,
            'urls'      => $urls,
            'post_ids'  => $post_ids,
            'actions'   => array_values( array_unique( $actions ) ),
            'message'   => 'Singularity SEO requested cache purge after SEO output changed. Verify public output with cache-busted reads.',
        );
    }
}
