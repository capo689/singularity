<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Plugin {
    private static $instance = null;

    private $registry;
    private $campaign_manager;
    private $context;
    private $robots_manager;
    private $sitemap_manager;
    private $product_store;

    public static function boot() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public static function activate() {
        if ( ! get_option( Registry::OVERRIDES_OPTION, null ) ) {
            add_option( Registry::OVERRIDES_OPTION, array(), '', false );
        }
        if ( ! get_option( Registry::MANAGED_PAGES_OPTION, null ) ) {
            add_option( Registry::MANAGED_PAGES_OPTION, array(), '', false );
        }
        if ( ! get_option( Product_Store::PROPOSALS_OPTION, null ) ) {
            add_option( Product_Store::PROPOSALS_OPTION, array(), '', false );
        }
        if ( ! get_option( Product_Store::CHANGES_OPTION, null ) ) {
            add_option( Product_Store::CHANGES_OPTION, array(), '', false );
        }
        if ( ! get_option( Takeover_Store::SCANS_OPTION, null ) ) {
            add_option( Takeover_Store::SCANS_OPTION, array(), '', false );
        }
        if ( ! get_option( Report_Store::REPORTS_OPTION, null ) ) {
            add_option( Report_Store::REPORTS_OPTION, array(), '', false );
        }
        if ( ! get_option( Report_Store::COMPETITORS_OPTION, null ) ) {
            add_option( Report_Store::COMPETITORS_OPTION, array(), '', false );
        }
        if ( ! get_option( Admin::MODE_OPTION, null ) ) {
            add_option( Admin::MODE_OPTION, '', '', false );
        }
        if ( ! get_option( Admin::CAPTURE_PAGE_IDS_OPTION, null ) ) {
            add_option( Admin::CAPTURE_PAGE_IDS_OPTION, array(), '', false );
        }
        Health_Scheduler::schedule();
        Visibility_Scheduler::schedule();

        flush_rewrite_rules();
    }

    public static function deactivate() {
        Health_Scheduler::unschedule();
        Visibility_Scheduler::unschedule();
        flush_rewrite_rules();
    }

    private function __construct() {
        $this->registry = new Registry();
        $this->product_store = new Product_Store();
        $this->campaign_manager = new Campaign_Manager();
        $this->context = new Context( $this->registry, $this->campaign_manager );

        // This plugin prints canonical URLs itself.
        remove_action( 'wp_head', 'rel_canonical' );

        new Title_Manager( $this->context );
        new Meta_Renderer( $this->context );
        new Schema_Renderer( $this->context );

        $this->robots_manager = new Robots_Manager( $this->context, $this->registry );
        $this->sitemap_manager = new Sitemap_Manager( $this->registry, $this->robots_manager );

        new Robots_Txt_Manager();
        new Health_Scheduler( $this->registry, $this->campaign_manager );
        new Visibility_Scheduler();
        new API(
            $this->registry,
            $this->campaign_manager,
            $this->sitemap_manager,
            $this->robots_manager,
            $this->product_store
        );

        new Admin(
            $this->registry,
            $this->campaign_manager,
            $this->sitemap_manager,
            $this->robots_manager,
            $this->product_store
        );
    }

}
