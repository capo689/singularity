<?php
namespace SMSEO;

defined( 'ABSPATH' ) || exit;

class Meta_Renderer {
    private $context;

    public function __construct( Context $context ) {
        $this->context = $context;
        add_action( 'template_redirect', array( $this, 'start_metadata_dedupe_buffer' ), 0 );
        add_action( 'wp_head', array( $this, 'render' ), 1 );
    }

    public function start_metadata_dedupe_buffer() {
        if ( is_admin() || wp_doing_ajax() || ! $this->context->is_frontend_render_context() ) {
            return;
        }

        if ( ! is_array( $this->context->current_managed_page() ) && ! is_singular() ) {
            return;
        }

        ob_start( array( $this, 'dedupe_metadata_head' ) );
    }

    public function dedupe_metadata_head( $html ) {
        if ( ! is_string( $html ) || false === stripos( $html, '<head' ) ) {
            return $html;
        }

        return preg_replace_callback(
            '/<head\b[^>]*>.*?<\/head>/is',
            array( $this, 'dedupe_head_callback' ),
            $html,
            1
        );
    }

    private function dedupe_head_callback( $matches ) {
        $head = isset( $matches[0] ) ? (string) $matches[0] : '';
        preg_match_all( '/<meta\s+[^>]*name=(["\'])description\1[^>]*>\s*/i', $head, $description_tags, PREG_OFFSET_CAPTURE );

        if ( empty( $description_tags[0] ) || count( $description_tags[0] ) < 2 ) {
            return $head;
        }

        $keep_index = 0;
        $singularity_start = stripos( $head, '<!-- Singularity SEO:' );
        $singularity_end = false !== $singularity_start ? stripos( $head, '<!-- /Singularity SEO:', $singularity_start ) : false;
        if ( false !== $singularity_start ) {
            foreach ( $description_tags[0] as $index => $tag ) {
                $offset = $tag[1];
                if ( $offset >= $singularity_start && ( false === $singularity_end || $offset <= $singularity_end ) ) {
                    $keep_index = $index;
                    break;
                }
            }
        }

        // Keep the Singularity-controlled description when present; remove duplicates from other site output.
        for ( $i = count( $description_tags[0] ) - 1; $i >= 1; $i-- ) {
            if ( $i === $keep_index ) {
                continue;
            }
            $tag = $description_tags[0][ $i ][0];
            $offset = $description_tags[0][ $i ][1];
            $head = substr_replace( $head, '', $offset, strlen( $tag ) );
        }
        if ( 0 !== $keep_index ) {
            $tag = $description_tags[0][0][0];
            $offset = $description_tags[0][0][1];
            $head = substr_replace( $head, '', $offset, strlen( $tag ) );
        }

        return $head;
    }

    public function render() {
        if ( ! $this->context->is_frontend_render_context() ) {
            return;
        }

        $page = $this->context->current_managed_page();

        if ( is_array( $page ) ) {
            $this->render_managed( $page );
            return;
        }

        $this->render_fallback();
    }

    private function render_managed( $page ) {
        $description = isset( $page['description'] ) ? $page['description'] : '';
        $canonical = isset( $page['canonical'] ) ? $page['canonical'] : '';
        $og = isset( $page['og'] ) && is_array( $page['og'] ) ? $page['og'] : array();
        $twitter = isset( $page['twitter'] ) && is_array( $page['twitter'] ) ? $page['twitter'] : array();

        echo "\n<!-- Singularity SEO: Metadata -->\n";

        if ( '' !== $description ) {
            printf( '<meta name="description" content="%s" />' . "\n", esc_attr( $description ) );
        }

        if ( '' !== $canonical ) {
            printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( $canonical ) );
        }

        $this->render_open_graph(
            isset( $og['title'] ) ? $og['title'] : ( isset( $page['title'] ) ? $page['title'] : '' ),
            isset( $og['description'] ) ? $og['description'] : $description,
            isset( $og['image'] ) ? $og['image'] : '',
            isset( $og['image_alt'] ) ? $og['image_alt'] : '',
            $canonical,
            'website'
        );

        $this->render_twitter(
            isset( $twitter['card'] ) ? $twitter['card'] : 'summary_large_image',
            isset( $twitter['title'] ) ? $twitter['title'] : ( isset( $page['title'] ) ? $page['title'] : '' ),
            isset( $twitter['description'] ) ? $twitter['description'] : $description,
            isset( $twitter['image'] ) ? $twitter['image'] : '',
            isset( $twitter['image_alt'] ) ? $twitter['image_alt'] : ''
        );

        echo "<!-- /Singularity SEO: Metadata -->\n";
    }

    private function render_fallback() {
        if ( ! is_singular() ) {
            return;
        }

        $canonical = $this->context->fallback_canonical();
        $title = $this->context->fallback_title();
        $description = $this->context->fallback_description();
        $image = $this->fallback_image();
        $image_alt = $this->fallback_image_alt();
        $og_type = is_singular( 'post' ) ? 'article' : 'website';

        echo "\n<!-- Singularity SEO: Fallback Metadata -->\n";

        if ( '' !== $description ) {
            printf( '<meta name="description" content="%s" />' . "\n", esc_attr( $description ) );
        }

        if ( '' !== $canonical ) {
            printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( $canonical ) );
        }

        $this->render_open_graph( $title, $description, $image, $image_alt, $canonical, $og_type );
        $this->render_twitter( 'summary_large_image', $title, $description, $image, $image_alt );

        echo "<!-- /Singularity SEO: Fallback Metadata -->\n";
    }

    private function render_open_graph( $title, $description, $image, $image_alt, $url, $type ) {
        echo '<meta property="og:locale" content="en_US" />' . "\n";
        printf( '<meta property="og:type" content="%s" />' . "\n", esc_attr( $type ) );
        printf( '<meta property="og:site_name" content="%s" />' . "\n", esc_attr( $this->site_name() ) );

        if ( '' !== $url ) {
            printf( '<meta property="og:url" content="%s" />' . "\n", esc_url( $url ) );
        }

        if ( '' !== $title ) {
            printf( '<meta property="og:title" content="%s" />' . "\n", esc_attr( $title ) );
        }

        if ( '' !== $description ) {
            printf( '<meta property="og:description" content="%s" />' . "\n", esc_attr( $description ) );
        }

        if ( '' !== $image ) {
            printf( '<meta property="og:image" content="%s" />' . "\n", esc_url( $image ) );
            printf( '<meta property="og:image:secure_url" content="%s" />' . "\n", esc_url( $image ) );
            echo '<meta property="og:image:width" content="1200" />' . "\n";
            echo '<meta property="og:image:height" content="630" />' . "\n";
            echo '<meta property="og:image:type" content="image/jpeg" />' . "\n";

            if ( '' !== $image_alt ) {
                printf( '<meta property="og:image:alt" content="%s" />' . "\n", esc_attr( $image_alt ) );
            }
        }
    }

    private function render_twitter( $card, $title, $description, $image, $image_alt ) {
        printf( '<meta name="twitter:card" content="%s" />' . "\n", esc_attr( $card ) );

        if ( '' !== $title ) {
            printf( '<meta name="twitter:title" content="%s" />' . "\n", esc_attr( $title ) );
        }

        if ( '' !== $description ) {
            printf( '<meta name="twitter:description" content="%s" />' . "\n", esc_attr( $description ) );
        }

        if ( '' !== $image ) {
            printf( '<meta name="twitter:image" content="%s" />' . "\n", esc_url( $image ) );
        }

        if ( '' !== $image_alt ) {
            printf( '<meta name="twitter:image:alt" content="%s" />' . "\n", esc_attr( $image_alt ) );
        }
    }

    private function site_name() {
        $site_name = get_bloginfo( 'name' );
        return '' !== (string) $site_name ? (string) $site_name : wp_parse_url( home_url( '/' ), PHP_URL_HOST );
    }

    private function fallback_image() {
        if ( is_singular() && has_post_thumbnail() ) {
            $image = get_the_post_thumbnail_url( null, 'large' );
            if ( is_string( $image ) && '' !== $image ) {
                return $image;
            }
        }

        $site_icon = get_site_icon_url( 512 );
        return is_string( $site_icon ) ? $site_icon : '';
    }

    private function fallback_image_alt() {
        if ( is_singular() && has_post_thumbnail() ) {
            $thumbnail_id = get_post_thumbnail_id();
            $alt = $thumbnail_id ? get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true ) : '';
            if ( '' !== (string) $alt ) {
                return (string) $alt;
            }
        }

        return $this->site_name();
    }
}
