<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'smseo_overrides' );
delete_option( 'smseo_managed_pages' );
delete_option( 'smseo_bridge_token' );
delete_option( 'smseo_controller_url' );
delete_option( 'smseo_customer_id' );
delete_option( 'smseo_hosted_connection_status' );
delete_option( 'smseo_hosted_connection_message' );
delete_option( 'smseo_operating_manual' );
delete_option( 'smseo_proposals' );
delete_option( 'smseo_changes' );
delete_option( 'smseo_takeover_scans' );
delete_option( 'smseo_health_snapshots' );
delete_option( 'smseo_daily_health_last_run' );
delete_option( 'smseo_daily_health_last_error' );
delete_option( 'smseo_visibility_snapshots' );
delete_option( 'smseo_visibility_config' );
delete_option( 'smseo_daily_visibility_last_run' );
delete_option( 'smseo_daily_visibility_last_error' );
delete_option( 'singularity_mode' );
delete_option( 'singularity_capture_page_ids' );
delete_option( 'singularity_setup_status' );
delete_option( 'singularity_mode_applied_at' );
delete_option( 'singularity_mode_log' );
delete_transient( 'smseo_auto_connect_cooldown' );
wp_clear_scheduled_hook( 'smseo_daily_health_snapshot' );
wp_clear_scheduled_hook( 'smseo_daily_visibility_snapshot' );

global $wpdb;
$wpdb->delete( $wpdb->usermeta, array( 'meta_key' => 'singularity_ui_setup_collapsed' ) );
$wpdb->delete( $wpdb->usermeta, array( 'meta_key' => 'singularity_ui_mode_collapsed' ) );
