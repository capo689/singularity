<?php
/**
 * Plugin Name: Singularity SEO
 * Plugin URI: https://agency689.com/
 * Description: AI-managed SEO control plane for WordPress sites, including approved metadata, JSON-LD schema, robots controls, sitemap behavior, live audits, proposals and rollback.
 * Version: 0.5.50
 * Author: Agency689
 * License: GPL-2.0-or-later
 * Text Domain: sunset-marquis-seo-manager
 */

defined( 'ABSPATH' ) || exit;

define( 'SMSEO_VERSION', '0.5.50' );
define( 'SMSEO_PLUGIN_FILE', __FILE__ );
define( 'SMSEO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SMSEO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-registry.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-product-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-validation.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-campaign-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-context.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-title-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-meta-renderer.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-schema-renderer.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-robots-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-sitemap-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-robots-txt-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-cache-manager.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-audit-service.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-takeover-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-metrics-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-health-scheduler.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-visibility-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-visibility-scheduler.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-report-store.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-api.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-admin.php';
require_once SMSEO_PLUGIN_DIR . 'includes/class-smseo-plugin.php';

register_activation_hook( __FILE__, array( '\SMSEO\Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( '\SMSEO\Plugin', 'deactivate' ) );

add_action( 'plugins_loaded', array( '\SMSEO\Plugin', 'boot' ), 20 );
