=== Singularity SEO ===
Contributors: agency689
Tags: seo, schema, robots, sitemap, ai seo
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.5.50
License: GPLv2 or later

AI-managed SEO control plane for WordPress sites.

== What this plugin does ==

* Replaces generic SEO-plugin output with an approved, site-specific SEO registry.
* Controls custom document titles through WordPress title filters.
* Outputs approved meta descriptions, canonical tags, Open Graph tags and Twitter/X tags.
* Outputs approved JSON-LD schema graphs for priority managed pages.
* Controls robots meta directives for managed pages.
* Uses WordPress native XML sitemaps and excludes managed noindex pages or mapped taxonomy archives where applicable.
* Adds a robots.txt sitemap reference.
* Supports campaign-aware homepage descriptions that expire back to evergreen copy.
* Provides a top-level Singularity SEO control plane with setup, mode, metrics and advanced diagnostics.
* Exposes authenticated WordPress REST API endpoints for the Singularity SEO control plane.
* Exposes current-site page discovery so the control plane can distinguish managed pages from unmanaged pages on the installed environment.
* Captures a non-destructive SEO Takeover Scan so existing site SEO can be reviewed before Singularity SEO expands control.
* Starts generic customer installs in scan-first mode, then materializes a customer-specific managed registry after Capture or Singularity mode approval, creating the setup scan automatically when needed.
* Generates branded Baseline, Competitive Review, Monthly Progress and Campaign Status reports with HTML preview and PDF download.
* Stores up to five competitors for ChatGPT-assisted competitive review workflows.
* Allows ChatGPT to bring discovered setup-scan pages under Singularity management before creating governed proposals.
* Supports batch SEO proposals so multiple page updates can be reviewed, applied and rolled back as one governed operation.
* Exposes a customer-safe capabilities endpoint so ChatGPT can discover supported features, limits, report types and protected-governance status without changing SEO output.

== Installation ==

1. Upload the plugin ZIP in WordPress under Plugins > Add New > Upload Plugin.
2. Activate Singularity SEO.
3. Visit Singularity SEO in the WordPress admin menu, or Settings > Singularity SEO.
4. WordPress verifies itself automatically when the Singularity SEO dashboard opens.
5. Open ChatGPT, click Copy ChatGPT command in the dashboard and paste the copied secure command into the Singularity SEO ChatGPT app.
6. Save the Google Search Console property, rank provider and tracked keywords in Search Data.

== Important registry note ==

Generic customer installs start in scan-first mode and do not ship another customer's SEO metadata as their active registry. The bundled flagship registry is only loaded for the Sunset Marquis demo/customer environment or by explicit developer opt-in.

== Admin editing ==

This adapter allows administrator overrides for:
* SEO title
* Canonical URL
* Meta description, where applicable
* Open Graph title and description
* Twitter/X title and description
* Robots presets
* Homepage campaign expiration and active/evergreen description fields when a campaign is configured

Structured schema graphs are controlled fields: bundled registry schema renders by default, and governed schema JSON-LD overrides can be proposed, applied and rolled back through batch workflows.

== Sitemaps ==

The plugin relies on WordPress native sitemaps:
* /wp-sitemap.xml

The plugin appends the sitemap line through WordPress' virtual robots.txt output. If the server uses a physical robots.txt file in the web root, update that file separately.

== Changelog ==

= 0.5.50 =
* Fixes the active dashboard Coverage card so managed-page count comes from the Singularity registry instead of the capped setup/capture scan total.
* Prevents larger managed sites from appearing as 30 managed pages just because the setup scan samples 30 public pages.

= 0.5.49 =
* Updates the WordPress override editor copy so schema JSON-LD is correctly described as a governed batch-controlled field.
* Keeps entity IDs and sitemap logic code-controlled while making schema override support explicit for launch testing.

= 0.5.48 =
* Adds governed schema JSON-LD overrides as controlled batch/apply/rollback fields.
* Exposes schema override capability and editable schema fields through REST page reads.
* Validates schema JSON-LD before saving so invalid schema proposals cannot publish.
* Allows schema proposal payloads through `schema_json`, `schema_jsonld` or `schema_graph` while storing one normalized `schema_json` override.

= 0.5.47 =
* Tightens Sunset Marquis recovery so accidental skipped-page registry rows are removed instead of retained.
* Marks future setup-scan adoptions so intentional later adoptions survive the Sunset recovery cleanup.
* Keeps bundled flagship pages, approved adopted pages and future marked adopted pages while dropping duplicate generated rows.

= 0.5.46 =
* Fixes setup-scan adoption so selected unmanaged pages are merged into the existing managed registry instead of replacing it.
* Skips duplicate adopted pages by post ID or path to keep the registry stable across repeated adoption runs.
* Restores bundled Sunset Marquis flagship pages alongside customer-adopted pages when recovering from a partial adoption registry.

= 0.5.45 =
* Separates Search Console and rank-tracking refresh status in the dashboard.
* Adds a manual rank tracking test path that uses the hosted quota-guarded ranking refresh.
* Keeps Search Console metrics and rank rows visible even when their latest snapshots are stored separately.
* Allows competitive reports created through ChatGPT to persist selected competitors into the WordPress dashboard.

= 0.5.44 =
* Added a read-only capabilities endpoint for stable ChatGPT feature discovery.
* Capabilities expose plugin version, managed page count, plan limits, supported report types, visibility data state and protected-governance status.
* Keeps public connector behavior stable so normal WordPress plugin updates do not require customers to reconnect ChatGPT.

= 0.5.43 =
* Protects bundled operating manuals and proprietary SEO brain content from customer-facing REST/tool output.
* Operating-manual reads now return a customer-safe governance summary, claim boundaries, approval rules, technical safety rules and visibility rules instead of the full internal manual text.
* Keeps operating manuals release-bundled and read-only while preserving safe ChatGPT guidance.

= 0.5.42 =
* Added a Search Console-only refresh test path for launch verification and support.
* The dashboard can now test Google Search Console without running SerpApi/rank refreshes.
* Added a WordPress REST support endpoint for Search Console-only refresh checks.

= 0.5.41 =
* Improved scheduled Google Search Console refresh errors so the dashboard stores the Controller or Google failure detail instead of only `HTTP 400`.
* Keeps connected/no-row visibility states intact while making real refresh failures actionable.

= 0.5.40 =
* Replaced the first-screen Coverage donut with a clearer managed-page count and status facts.
* Keeps coverage easy to scan when all managed pages are already under Singularity control.

= 0.5.39 =
* Added tracked keyword/rank rows to the active first-screen Visibility dashboard card.
* Shows rank, not-found, pending and matched URL state where customers actually look first.

= 0.5.38 =
* Added a visible tracked-keyword ranking table to the WordPress Visibility Metrics dashboard.
* Shows configured keywords, latest rank/not-found state, matched URL, checked depth and last ranking snapshot without running a rank refresh.

= 0.5.37 =
* Capped standard WordPress rank tracking at three tracked keywords to match the launch SerpApi daily search budget.
* Updated Search Data dashboard, reports and bundled operating manual copy around the three-keyword launch cap.

= 0.5.35 =
* Fixed secure connection-code rotation so a legacy verified domain ID is rotated before the hosted verification check runs.
* Clears the onboarding cooldown after ID rotation so the new secure code is submitted to the hosted Controller immediately.
* Disables Copy ChatGPT command until the hosted record for the current secure code is verified.

= 0.5.34 =
* Bundled read-only operating manuals so ChatGPT/manual reads are never blank on launch installs.
* Added Agency689-specific governance manual packaged through the WordPress release path.
* Automatically expires stale open proposals after 24 hours so old test proposals do not clutter the active decision queue.
* Added explicit visibility data-state messaging for connected Search Console or rank providers that have not returned measurable rows yet.

= 0.5.33 =
* Replaced predictable domain-based ChatGPT connection IDs with opaque secure connection codes for new and legacy installs.
* Hid the full ChatGPT connection code from the normal dashboard and support packet; the full command is only copied through the explicit Copy ChatGPT command action.
* Rotates legacy domain-derived IDs into secure IDs and asks the hosted connection to refresh under the new code.

= 0.5.32 =
* Made Baseline and Monthly reports reflect connected Google Search Console and rank-provider state.
* Reframed setup-scan findings as historical baseline data instead of current SEO issues.
* Upgraded PDF report rendering with branded headers, summary cards, sections and footers.
* Updated Search Console dashboard copy so customers can enter a normal website URL.

= 0.5.31 =
* Fixed Google Search Console Domain property support for `sc-domain:` property identifiers.
* Uses the saved Search Console property when launching OAuth instead of forcing the WordPress home URL.
* Allows Domain properties in the WordPress Search Data field and REST visibility configuration.

= 0.5.30 =
* Locked the operating manual REST endpoint to read-only so governance manuals ship through product releases instead of customer-facing tool writes.
* Added no-store headers to visibility config reads/writes to prevent stale rank-provider configuration readback.
* Added explicit persisted visibility config readback after config updates.

= 0.5.29 =
* Added cache-busted live audit and takeover scan fetches so verification checks fresh public output after writes and rollback.
* Added cache purge requests after page, proposal, batch and rollback SEO output changes.
* Added metadata de-duplication for managed front-end output so Singularity-owned pages do not ship duplicate meta descriptions from theme/plugin leftovers.
* Expanded batch apply/rollback responses with changed fields, skipped pages and cache purge status for faster ChatGPT verification.

= 0.5.26 =
* Release-candidate hardening for the fresh-site write flow.
* Verifies the setup-scan adoption endpoint during packaging so generic installs cannot ship without a path from scanned pages to managed pages.
* Aligns the WordPress package with the hosted ChatGPT adoption tool required before governed proposals can be created on a new site.

= 0.5.25 =
* Added a setup-scan adoption endpoint so generic customer sites can move from discovered pages to managed pages without manual registry work.
* Supports recommended, selected-path, selected-post and all-page adoption from the latest non-destructive takeover scan.
* Keeps adoption separate from SEO copy changes so ChatGPT can create proposals after the managed-page foundation exists.

= 0.5.24 =
* Added Singularity Reports for baseline, competitive review, monthly progress and campaign status workflows.
* Added branded HTML preview and lightweight PDF download for generated reports.
* Added a five-competitor launch cap and a professional ChatGPT handoff prompt for competitive reviews.

= 0.5.23 =
* Capped standard WordPress rank tracking at three keywords for predictable launch costs.
* Added a starter keyword fallback so new sites begin with one measurable ranking target.
* Clarified dashboard keyword setup copy around the included keyword launch limit.

= 0.5.22 =
* Added secure hosted Google Search Console OAuth launch links signed with the internal WordPress bridge credential.
* Updated Search Console setup so pasted property URLs are treated as pending until Google OAuth completes.
* Added daily signed Controller refresh calls so connected Search Console properties can feed visibility snapshots.

= 0.5.21 =
* Refined the launch dashboard onboarding path with clearer WordPress, ChatGPT and search-data states.
* Promoted the ChatGPT connection action to a first-screen primary control.
* Clarified that Google Search Console is a reporting enhancement, not a blocker for the core WordPress-to-ChatGPT connection.

= 0.5.20 =
* Added a support-only credential rotation control that generates a new internal bridge credential without exposing the secret.
* Rotation queues hosted re-verification in the background so ChatGPT access can recover after credential rotation.
* Split support credential actions into replace, rotate and clear paths.

= 0.5.19 =
* Reduced manual ChatGPT link verification wait time and continued hosted verification in the background when the Controller is slow.
* Added an informational connection notice so slow hosted verification does not look like a broken install.

= 0.5.18 =
* Fixed the active control-plane setup panel so the live dashboard shows a primary Refresh ChatGPT Link action in the ChatGPT connection row.
* Targeted `render_setup_control_panel()`, the active dashboard path shown in the installed WordPress UI.
* Added responsive styling for the active ChatGPT link action.

= 0.5.17 =
* Superseded dashboard attempt. This version changed a legacy setup block, not the active control-plane setup panel used by the installed dashboard.
* Do not use 0.5.17 as the checked ChatGPT link UI package.

= 0.5.16 =
* Renamed the WordPress connection action to Refresh ChatGPT Link so the launch dashboard matches the actual ChatGPT authorization workflow.
* Promoted the connection refresh action from a vague secondary recheck into a clear primary setup step.
* Clarified setup copy for connecting a new ChatGPT app/account after WordPress verification.

= 0.5.15 =
* Added scan-first registry behavior for generic customer installs.
* Materializes customer-specific managed pages from the latest Takeover Scan when Capture or Singularity mode is approved.
* Replaced hardcoded fallback social metadata with site-derived WordPress values.
* Removed unnecessary transient duplication of newly generated bridge credentials.
* Moved automatic first-load hosted verification to a non-blocking background request.

= 0.5.14 =
* Restored the Settings > Singularity SEO admin entry as an alias to the redesigned control plane.

= 0.5.13 =
* Removed the legacy top hero so the redesigned control plane is the first screen.
* Resized the Singularity bug and Agency689 footer mark to match the dashboard layout.
* Replaced the ChatGPT callout image with a CSS-rendered bug mark so the callout cannot show a broken image.

= 0.5.12 =
* Rebuilt the WordPress dashboard as a launch-ready control plane.
* Added persisted Orbit, Capture and Singularity mode state with mode-switch logging.
* Added Capture page selection persistence and dashboard REST contracts under singularity/v1.
* Added summary-first health, coverage, visibility and setup contracts for faster dashboard rendering.
* Moved the product surface to a top-level Singularity SEO admin menu.

= 0.5.11 =
* Added SEO Takeover Scan v1 for onboarding audits before Singularity SEO takes control.
* Stores current rendered SEO baseline fields, detected SEO plugin signals, readiness summary and recommendations.
* Added REST endpoints and WordPress dashboard reporting for takeover scan data.

= 0.5.10 =
* Preserved rank-depth, keyword status, checked-result count and ranking-provider messages in visibility snapshots.
* Added Rank Depth and latest ranking check reporting to the WordPress visibility dashboard.

= 0.5.9 =
* Added a ranking target domain setting so staging sites can track the public production domain in search results.
* Exposed the configured ranking domain in visibility provider status and dashboard reporting.

= 0.5.8 =
* Kept heavyweight health audits out of automatic dashboard rendering so admin pages stay responsive.
* Shortened the automatic hosted verification timeout so a slow controller cannot stall the dashboard.
* Hardened Search Console and ranking URL sanitization to accept only absolute HTTP/HTTPS URLs.
* Removed unused dashboard renderers and legacy styles left behind by earlier onboarding iterations.
* Expanded uninstall cleanup to remove stored bridge credentials, hosted connection state, proposals, changes and operating manual data.

= 0.5.7 =
* Reworked the dashboard around the real customer flow: automatic WordPress verification, ChatGPT site ID, and Search Data setup.
* Converted the manual connection button from the happy path into a repair/recheck action.
* Added first-class Search Data setup for Google Search Console property, rank provider and tracked keywords.
* Collapsed diagnostics, manual overrides, system status, support credentials and reset controls into advanced drawers.
* Removed redundant hero actions and status cards so the first screen leads with the setup path.

= 0.5.6 =
* Reworked the WordPress dashboard into a launch console with a branded GO connection action.
* Added SEO Brain positioning so administrators can see how the operating manual guides WordPress and ChatGPT.
* Moved connection URLs, REST endpoints and setup packet details behind a support drawer.
* Improved dashboard navigation, launch status, baseline health and visibility sections for a more polished customer experience.

= 0.5.5 =
* Removed internal private bridge-key language from the launch connection details shown in the WordPress dashboard.

= 0.5.4 =
* Restored the launch-quality one-click connection flow: WordPress verifies the site, then ChatGPT connects by customer/site ID without exposing private keys in the normal customer path.
* Updated setup copy to present bridge credentials as support infrastructure, not customer onboarding steps.

= 0.5.3 =
* Added a clear ChatGPT connection packet after hosted verification, including the customer/site ID for the connect_seo_customer tool.
* Clarified the WordPress setup copy so administrators can link a verified WordPress site to a ChatGPT account without hunting for a transient setup key.

= 0.5.2 =
* Added Visibility v1 configuration, ingested visibility snapshots, baseline deltas and dashboard reporting.
* Added REST endpoints for visibility provider setup and controlled visibility snapshot ingestion.

= 0.5.1 =
* Marked original change records as no longer rollback-available after a rollback succeeds.

= 0.5.0 =
* Added Visibility Metrics foundation for Google Search Console and rank tracking.
* Added daily visibility snapshot scheduling, provider status, and REST visibility endpoints.
* Standard plan cadence is once daily; enterprise cadence is modeled for twice daily.

= 0.4.9 =
* Added daily automated SEO Health snapshots through WordPress cron.
* Metrics payload now reports automation status, next run, last run and last error.

= 0.4.8 =
* Connect Site now creates the first SEO Health baseline snapshot automatically after hosted verification succeeds.
* Connection setup and metrics panels now show the last health snapshot time.

= 0.4.7 =
* Added SEO Health Metrics snapshots with baseline, current score, trend history, score delta and top issue tracking.
* Added REST metrics endpoints for Controller and ChatGPT reporting.
* Running a live audit now stores a health snapshot automatically.

= 0.4.6 =
* Connect Site is now one-click/idempotent: it reuses an existing bridge credential or creates one, then immediately verifies hosted onboarding.

= 0.4.5 =
* Connection status now reflects hosted verification instead of local key presence.
* Stores the latest hosted onboarding response for clearer troubleshooting.

= 0.4.4 =
* Added hosted onboarding submission from the Connect This Site panel.
* Connect Site now asks the hosted Controller to verify and store the customer-site record.
* Keeps the setup packet available as a support fallback instead of the primary customer workflow.

= 0.4.3 =
* Reworked onboarding around a customer-safe setup packet.
* Removed customer-facing Render/token plumbing from the primary connection flow.
* Moved bridge credentials toward support-only setup handling.

= 0.4.2 =
* Added Customer Setup panel for repeatable WordPress onboarding.
* Added Controller URL and customer/site ID storage.
* Added one-click bridge token generation.
* Added connection readiness fields to REST status.

= 0.4.1 =
* Branded the product shell as Singularity SEO.
* Added Singularity SEO logo asset and updated admin product positioning.
* Kept the Sunset Marquis registry as the flagship site-specific implementation.

= 0.4.0 =
* Added /wp-json/smseo/v1/site-pages for authenticated current-install page discovery.
* Site page discovery reports published WordPress pages, resolved URLs, managed status, and managed registry keys where applicable.

= 0.3.3 =
* Removed the campaign expiration date from the dashboard header KPI cards so campaign timing is not confused with SEO system expiration.

= 0.3.2 =
* Made live audits environment-aware: registry entries absent from the current WordPress environment are skipped instead of treated as SEO failures.
* Added skipped counts to REST and admin audit summaries.

= 0.3.1 =
* Removed transitional third-party SEO plugin references, notices, audit flags, and legacy sitemap URL behavior from the product surface.

= 0.3.0 =
* Added operating manual, proposal packet, change history, pending decision summary, proposal apply, proposal expiration, and rollback REST endpoints for the SEO control plane.

= 0.2.1 =
* Hardened canonical URL overrides to require absolute HTTP(S) URLs without embedded credentials in both REST and admin workflows.
* Validates campaign expiration dates as real calendar dates and fails closed to evergreen copy for non-empty malformed legacy expiry values.
* Centralized live head audit execution through the shared audit service and reduced audit fetch timeout from 25 seconds to 10 seconds per page.
* Admin override saves now reject invalid canonical/date fields with visible validation messages instead of silently dropping them.

= 0.2.0 =
* Added authenticated REST API endpoints under /wp-json/smseo/v1 for status, managed page listing, page details, per-page updates, per-page reset, and live audit execution.
* Added per-page override reset support for external bridge workflows.
* Added API response payloads for MCP read/write tooling and diagnostics.

= 0.1.5 =
* Prevent managed SEO metadata, social tags and schema from rendering on true 404 responses.
* Keeps configured-but-missing dev or campaign pages from receiving normal indexable SEO output on a 404 template.

= 0.1.4 =
* Added live front-end head audit in Settings > Singularity SEO.
* Audit fetches the actual rendered front-end HTML and checks titles, meta descriptions, canonicals, robots, social tags, and JSON-LD validity.

= 0.1.2 =
* Added alternate URL-path aliases for the active dev-site slug structure while preserving the approved production-path registry.
* Registry path matching now recognizes configured aliases.
* Post-ID resolution now checks approved aliases to improve staging diagnostics and sitemap eligibility reporting.
* Diagnostics display configured aliases where present so path mapping is visible during QA.

= 0.1.1 =
* Synced approved admin title and description overrides into matching managed schema text.
* Added taxonomy sitemap exclusion support for managed noindex category archives such as Offers.
* Prevented sitemap appending to robots.txt when the WordPress site is set to discourage search engines.

= 0.1.0 =
* Initial plugin build.
